<?php
    if ( !defined('ABSPATH') ){ die(); }
    
    global $invio_config;

    $style                 = $invio_config['box_class'];
    $responsive            = invio_get_option('responsive_active') != "disabled" ? "responsive" : "fixed_layout";
    $blank                 = isset($invio_config['template']) ? $invio_config['template'] : "";    
    $invio_lightbox        = invio_get_option('lightbox_active') != "disabled" ? 'invio-default-lightbox' : 'invio-custom-lightbox';
    $preloader            = invio_get_option('preloader') == "preloader" ? 'invio-preloader-active invio-preloader-enabled' : 'invio-preloader-disabled';
    $sidebar_styling     = invio_get_option('sidebar_styling');
    $filterable_classes = invio_header_class_filter( invio_header_class_string() );

    
?><!DOCTYPE html>
<html <?php language_attributes(); ?> class="<?php echo "html_{$style} ".$responsive." ".$preloader." ".$invio_lightbox." ".$filterable_classes ?> ">
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>" />
<?php
/*
 * outputs a rel=follow or nofollow tag to circumvent google duplicate content for archives
 * located in framework/php/function-set-invio-frontend.php
 */
 if (function_exists('invio_set_follow')) { echo invio_set_follow(); }

?>


<!-- mobile setting -->
<?php

if( strpos($responsive, 'responsive') !== false ) echo '<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">';
?>


<!-- Scripts/CSS and wp_head hook -->
<?php
/* Always have wp_head() just before the closing </head>
 * tag of your theme, or you will break many plugins, which
 * generally use this hook to add elements to <head> such
 * as styles, scripts, and meta tags.
 */

wp_head();

?>

</head>




<body id="top" <?php body_class($style." ".$invio_config['font_stack']." ".$blank." ".$sidebar_styling); invio_markup_helper(array('context' => 'body')); ?>>

    <?php 
        
    if("invio-preloader-active invio-preloader-enabled" === $preloader)
    {
        echo invio_preload_screen(); 
    }
        
    ?>

    <div id='wrap_all'>

    <?php 
    if(!$blank) //blank templates dont display header nor footer
    { 
         //fetch the template file that holds the main menu, located in includes/helper-menu-main.php
         get_template_part( 'includes/helper', 'main-menu' );

    } ?>
        
    <div id='main' class='all_colors' data-scroll-offset='<?php echo invio_header_setting('header_scroll_offset'); ?>'>

    <?php 
        
        if(isset($invio_config['temp_logo_container'])) echo $invio_config['temp_logo_container'];
        do_action('infio_action_after_main_container'); 
        
    ?>
