<?php

if(class_exists('GFForms') )
{
    add_action('wp_enqueue_scripts', 'invio_add_gravity_scripts');
}


function invio_add_gravity_scripts()
{
    wp_register_style( 'invio-gravity' ,   get_template_directory_uri()."/config-gravityforms/gravity-mod.css", array(), '1', 'screen' );
    wp_enqueue_style( 'invio-gravity');
}

add_filter('infio_filter_ajax_form_class', 'invio_change_ajax_form_class', 10, 3);
function invio_change_ajax_form_class($class, $formID, $form_params)
{
    return 'invio_ajax_form';
}


/*add the gravityforms button to the ajax popup editor*/
add_filter('gform_display_add_form_button', 'invio_add_gf_button_to_editor', 10, 1);
function invio_add_gf_button_to_editor($is_post_edit_page)
{
    if(!empty($_POST['ajax_fetch']))
    {
        $is_post_edit_page = true;
    }
    
    return $is_post_edit_page;
}