<?php
    if ( !defined('ABSPATH') ){ die(); }
    
    global $invio_config, $more;

    /*
     * get_header is a basic wordpress function, used to retrieve the header.php file in your theme directory.
     */
     get_header();
    
        
        $showheader = true;
        if(invio_get_option('frontpage') && $blogpage_id = invio_get_option('blogpage'))
        {
            if(get_post_meta($blogpage_id, 'header', true) == 'no') $showheader = false;
        }
        
         if($showheader)
         {
            echo invio_title(array('title' => invio_which_archive()));
        }
        
        do_action( 'infio_action_after_main_title' );
    ?>

        <div class='container_wrap container_wrap_first main_color <?php invio_layout_class( 'main' ); ?>'>

            <div class='container template-blog '>

                <main class='content <?php invio_layout_class( 'content' ); ?> units' <?php invio_markup_helper(array('context' => 'content','post_type'=>'post'));?>>
                    
                    <?php 
                        
                        $tds =  term_description(); 
                        if($tds)
                        {
                            echo "<div class='category-term-description'>{$tds}</div>";
                        }
                    ?>
                    

                    <?php
                    $invio_config['blog_style'] = apply_filters('infio_filter_blog_style', invio_get_option('blog_style','multi-big'), 'archive');
                    if($invio_config['blog_style'] == 'blog-grid')
                    {
                        global $posts;
                        $post_ids = array();
                        foreach($posts as $post) $post_ids[] = $post->ID;

                        if(!empty($post_ids))
                        {
                            $atts   = array(
                                'type' => 'grid',
                                'items' => get_option('posts_per_page'),
                                'columns' => 3,
                                'class' => 'invio-builder-el-no-sibling',
                                'paginate' => 'yes',
                                'use_main_query_pagination' => 'yes',
                                'custom_query' => array( 'post__in'=>$post_ids, 'post_type'=>get_post_types() )
                            );

                            $blog = new invio_post_slider($atts);
                            $blog->query_entries();
                            echo "<div class='entry-content-wrapper'>".$blog->html()."</div>";
                        }
                        else
                        {
                            get_template_part( 'includes/loop', 'index' );
                        }
                    }
                    else
                    {
                        /* Run the loop to output the posts.
                        * If you want to overload this in a child theme then include a file
                        * called loop-index.php and that will be used instead.
                        */

                        $more = 0;
                        get_template_part( 'includes/loop', 'index' );
                    }
                    ?>

                <!--end content-->
                </main>

                <?php

                //get the sidebar
                $invio_config['currently_viewing'] = 'blog';
                get_sidebar();

                ?>

            </div><!--end container-->

        </div><!-- close default .container_wrap element -->




<?php get_footer(); ?>
