<?php
if(!is_admin())
{
    add_action('init', 'invio_woocommerce_bookings_register_assets');
}    
    
function invio_woocommerce_bookings_register_assets()
{
    wp_enqueue_style( 'invio-woocommerce-bookings-css', INVIO_BASE_URL.'config-woocommerce/config-woocommerce-bookings/woocommerce-booking-mod.css');
}