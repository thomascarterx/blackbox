<?php
/*function that checks if the invio builder was already included*/
function invio_builder_plugin_enabled()
{
    if (class_exists( 'InvioBuilder' )) { return true; }
    return false;
}


//set the folder that contains the shortcodes
function add_shortcode_folder($paths)
{
    $paths = array(dirname(__FILE__) ."/invio-shortcodes/");
    return $paths;
}

add_filter('invio_load_shortcodes','add_shortcode_folder');



//set the folder that contains assets like js and imgs
function invio_builder_plugins_url($url)
{
    $url = get_template_directory_uri()."/config-templatebuilder/invio-template-builder/";
    return $url;
}


add_filter('invio_builder_plugins_url','invio_builder_plugins_url');


//check if the builder was included via plugin. if not include it now via theme
if(!invio_builder_plugin_enabled())
{
    require_once( dirname(__FILE__) . '/invio-template-builder/php/template-builder.class.php' );
    
    //define( 'INVIO_BUILDER_TEXTDOMAIN',  'invio_framework' );
    
    $builder = new InvioBuilder();
    
    //activates the builder safe mode. this hides the shortcodes that are built with the content builder from the default wordpress content editor. 
    //can also be set to "debug", to show shortcode content and extra shortcode container field
    $builder->setMode( 'safe' ); 
    
    //set all elements that are fullwidth and need to interact with the section shortcode. invio_section is included automatically
    $builder->setFullwidthElements( array('invio_revolutionslider', 'invio_layerslider' ,'invio_slideshow_full', 'invio_fullscreen', 'invio_masonry_entries','invio_masonry_gallery', 'invio_google_map', 'invio_slideshow_accordion', 'invio_image_hotspot', 'invio_portfolio', 'invio_submenu', 'invio_layout_row', 'invio_button_big','invio_feature_image_slider') ); 
}



