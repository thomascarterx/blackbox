<?php
/**
* Central Class for creating and saving template snippets via ajax
*/

// Don't load directly
if ( !defined('ABSPATH') ) { die('-1'); }

if ( !class_exists( 'invioSaveBuilderTemplate' ) ) {

    class invioSaveBuilderTemplate
    {
       var $builder;
    
        function __construct($builder)
        {
            $this->builder = $builder;
            
            if($this->builder->disable_drag_drop == true) return;
            
            $this->actions_and_filters();
            
        }
        
        /** 
        * filter and action hooks
        */
        protected function actions_and_filters()
        {
            $ver = InvioBuilder::VERSION;
        
            #js
            wp_enqueue_script('invio_template_save_js' , InvioBuilder::$path['assetsURL'].'js/invio-template-saving.js' , array('invio_element_js'), $ver, TRUE );
            
            #ajax
            add_action('wp_ajax_invio_ajax_save_builder_template', array($this,'save_builder_template'), 10);
            add_action('wp_ajax_invio_ajax_delete_builder_template', array($this,'delete_builder_template'), 10);
            add_action('wp_ajax_invio_ajax_fetch_builder_template', array($this,'fetch_builder_template'), 10);
            
            
        }
        
        
        /** 
        * save button html
        */
        public function create_save_button()
        {
            $names = $this->template_names();
            $list = "";
            if(empty($names))
            {
                $list = "<li class='invio-no-template'>" .__('No Templates saved yet','invio_framework' ) ."</li>\n";
            }
            else
            {
                foreach($names as $name)
                {
                    $list .= "<li><a href='#'>{$name}</a><span class='invio-delete-template'></span></li>\n";
                }
            }
            
            $output  = "";
            $output .= "<div class='invio-template-save-button-container invio-attach-template-save invio-hidden-dropdown'>";
            $output .= "    <a class='open-template-button button' href='#open'>".__('Templates','invio_framework' )."</a>";
            $output .= "    <div class='invio-template-save-button-inner'> <span class='invio-arrow'></span>";
            $output .= "        <a class='save-template-button button button-primary button-large' href='#save'>".__('Save Entry as Template','invio_framework' )."</a>";
            $output .= "        <div class='invio-template-list-wrap'>";
            $output .= "            <span class='invio-tempaltes-miniheader'>".__('Load Template','invio_framework' ).":</span>";
            $output .= "            <ul>";
            $output .=                 $list;
            $output .= "            </ul>";
            $output .= "        </div>";
            $output .= "    </div>";
            $output .= "</div>";
            
            return $output;
        }

        
        /**
         * Helper function that fetches all template names
         *
         */
        protected function template_names()
        {
            $templates  = $this->get_meta_values();
            $names      = array();
            
            foreach($templates as $template)
            {
                $name = explode("}}}", $template);
                $names[] = str_replace('{{{', "", $name[0]);
            }
            
            natcasesort($names);
            return $names;
        }
        
        
         /**
         * Ajax Function that checks if template can be saved
         *
         */
        public function save_builder_template($name = "%", $value = "")
        {   

            check_ajax_referer('invio_nonce_save','invio-save-nonce');
            
            $name   = isset($_POST['templateName'])     ? $_POST['templateName']    : $name;
            $value  = isset($_POST['templateValue'])    ? $_POST['templateValue']   : $value;
            $id     = InvioStoragePost::get_custom_post('template_builder_snippets');
            
            $key = $this->generate_key($name);
            $old = $this->get_meta_values($key);

            
            if(!empty($old))
            {
                echo __('Template name already in use. Please delete the template with this name first or choose a different name', 'invio_framework' );
            }
            else
            {
                $value = ShortcodeHelper::clean_up_shortcode($value);
                $result = update_post_meta($id, $key, '{{{'.$name.'}}}'.$value);
                echo 'invio_template_saved';
            }
            
            die();
        }
        
        /**
         * Ajax Function that deletes a template
         *
         */
        public function delete_builder_template($name = "%")
        {
            check_ajax_referer('invio_nonce_save','invio-save-nonce');
        
            $name   = isset($_POST['templateName'])     ? $_POST['templateName']    : $name;
            $id     = InvioStoragePost::get_custom_post('template_builder_snippets');

            
            $key = $this->generate_key($name);
            $result = delete_post_meta($id, $key);
            echo 'invio_template_deleted';
            die();
        }
        
        /**
         * Retrieve a saved template via ajax. The JS will then insert it into the canvas area
         *
         */
        public function fetch_builder_template()
        {
            $error  = false;
            $name   = isset($_POST['templateName']) ? $_POST['templateName'] : false;
            if(empty($name)) 
                $error = true;
            
            $key = $this->generate_key($name);
            $template = $this->get_meta_values($key);
            
            if(empty($template)) $error = true;
            
            
            if($error)
            {
                echo "invio_fetching_error";
            }
            else
            {
                $text = str_replace('{{{'.$name.'}}}','',$template[0]);
                $return = $this->builder->text_to_interface($text);
                
                echo $return;
            }
            
            die();
        }
        
        
        /**
         * Helper function that creates the post meta key
         *
         */
        protected function generate_key($name)
        {
            return "_invio_builder_template_".str_replace(" ", "_", strtolower($name));
        }
        
        
        /**
         * Helper function that fetches all meta values with a specific key (cross post)
         *
         */
        protected function get_meta_values( $key = '_invio_builder_template_%' ) 
        {
            global $wpdb;
            if( empty( $key ) ) return;
            
            $compare_by = strpos($key, '%') !== false ? "LIKE" : "=";
            $id     = InvioStoragePost::get_custom_post('template_builder_snippets');
    
            $r = $wpdb->get_col( $wpdb->prepare( "
                SELECT meta_value FROM {$wpdb->postmeta}
                WHERE  meta_key {$compare_by} '%s'
                AND post_id = '%s'
            ", $key, $id) );

            return $r;
        }
        
        
        
        
        
                
    } // end class

} // end if !class_exists