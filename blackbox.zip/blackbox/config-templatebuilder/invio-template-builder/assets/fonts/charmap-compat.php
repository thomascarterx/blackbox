<?php //a manually generated charmap to map the deprecated font to the new version. lets hope i never have to do this again :P
$chars = array(); 
$chars['entypo-fontello'][] = 'ue854';
$chars['entypo-fontello'][] = 'ue8ac';
$chars['entypo-fontello'][] = 'ue8ba';
$chars['entypo-fontello'][] = 'ue841';
$chars['entypo-fontello'][] = 'ue805';
$chars['entypo-fontello'][] = 'ue836';
$chars['entypo-fontello'][] = 'ue837';
$chars['entypo-fontello'][] = 'ue823';
$chars['entypo-fontello'][] = 'ue8af';
$chars['entypo-fontello'][] = 'ue830';
$chars['entypo-fontello'][] = 'ue831';
$chars['entypo-fontello'][] = 'ue832';
$chars['entypo-fontello'][] = 'ue80a';
$chars['entypo-fontello'][] = 'ue80b';
$chars['entypo-fontello'][] = 'ue80c';
$chars['entypo-fontello'][] = 'ue840';
$chars['entypo-fontello'][] = 'ue835';
$chars['entypo-fontello'][] = 'ue842';
$chars['entypo-fontello'][] = 'ue843';
$chars['entypo-fontello'][] = 'ue845';
$chars['entypo-fontello'][] = 'ue844';
$chars['entypo-fontello'][] = 'ue8a3';
$chars['entypo-fontello'][] = 'ue857';
$chars['entypo-fontello'][] = 'ue858';
$chars['entypo-fontello'][] = 'ue806';
$chars['entypo-fontello'][] = 'ue807';
$chars['entypo-fontello'][] = 'ue808';
$chars['entypo-fontello'][] = 'ue809';
$chars['entypo-fontello'][] = 'ue82b';
$chars['entypo-fontello'][] = 'ue82c';
$chars['entypo-fontello'][] = 'ue83c';
$chars['entypo-fontello'][] = 'ue83b';
$chars['entypo-fontello'][] = 'ue833';
$chars['entypo-fontello'][] = 'ue821';
$chars['entypo-fontello'][] = 'ue86b';
$chars['entypo-fontello'][] = 'ue803';
$chars['entypo-fontello'][] = 'ue804';
$chars['entypo-fontello'][] = 'ue838';
$chars['entypo-fontello'][] = 'ue83d';
$chars['entypo-fontello'][] = 'ue822';
$chars['entypo-fontello'][] = 'ue82a';
$chars['entypo-fontello'][] = 'ue855';
$chars['entypo-fontello'][] = 'ue856';
$chars['entypo-fontello'][] = 'ue8a8';
$chars['entypo-fontello'][] = 'ue827';
$chars['entypo-fontello'][] = 'ue80f';
$chars['entypo-fontello'][] = 'ue8d2';
$chars['entypo-fontello'][] = 'ue8b5';
$chars['entypo-fontello'][] = 'ue8a4';
$chars['entypo-fontello'][] = 'ue8b8';
$chars['entypo-fontello'][] = 'ue800';
$chars['entypo-fontello'][] = 'ue801';
$chars['entypo-fontello'][] = 'ue83f';
$chars['entypo-fontello'][] = 'ue8c9';
$chars['entypo-fontello'][] = 'ue84f';
$chars['entypo-fontello'][] = 'ue84d';
$chars['entypo-fontello'][] = 'ue85a';
$chars['entypo-fontello'][] = 'ue8b6';
$chars['entypo-fontello'][] = 'ue8b9';
$chars['entypo-fontello'][] = 'ue826';
$chars['entypo-fontello'][] = 'ue862';
$chars['entypo-fontello'][] = 'ue85e';
$chars['entypo-fontello'][] = 'ue85b';
$chars['entypo-fontello'][] = 'ue8b4';
$chars['entypo-fontello'][] = 'ue8b3';
$chars['entypo-fontello'][] = 'ue8cd';
$chars['entypo-fontello'][] = 'ue8ae';
$chars['entypo-fontello'][] = 'ue8bb';
$chars['entypo-fontello'][] = 'ue863';
$chars['entypo-fontello'][] = 'ue8ad';
$chars['entypo-fontello'][] = 'ue8d7';
$chars['entypo-fontello'][] = 'ue8a9';
$chars['entypo-fontello'][] = 'ue8c1';
$chars['entypo-fontello'][] = 'ue846';
$chars['entypo-fontello'][] = 'ue8dd';
$chars['entypo-fontello'][] = 'ue8c0';
$chars['entypo-fontello'][] = 'ue8b1';
$chars['entypo-fontello'][] = 'ue83a';
$chars['entypo-fontello'][] = 'ue86d';
$chars['entypo-fontello'][] = 'ue86c';
$chars['entypo-fontello'][] = 'ue8a2';
$chars['entypo-fontello'][] = 'ue8a1';
$chars['entypo-fontello'][] = 'ue8a0';
$chars['entypo-fontello'][] = 'ue89f';
$chars['entypo-fontello'][] = 'ue865';
$chars['entypo-fontello'][] = 'ue866';
$chars['entypo-fontello'][] = 'ue867';
$chars['entypo-fontello'][] = 'ue834';
$chars['entypo-fontello'][] = 'ue8ab';
$chars['entypo-fontello'][] = 'ue8c2';
$chars['entypo-fontello'][] = 'ue864';
$chars['entypo-fontello'][] = 'ue8cf';
$chars['entypo-fontello'][] = 'ue8c8';
$chars['entypo-fontello'][] = 'ue8d1';
$chars['entypo-fontello'][] = 'ue859';
$chars['entypo-fontello'][] = 'ue852';
$chars['entypo-fontello'][] = 'ue8cb';
$chars['entypo-fontello'][] = 'ue853';
$chars['entypo-fontello'][] = 'ue8a7';
$chars['entypo-fontello'][] = 'ue8cc';
$chars['entypo-fontello'][] = 'ue919';
$chars['entypo-fontello'][] = 'ue8c5';
$chars['entypo-fontello'][] = 'ue8c6';
$chars['entypo-fontello'][] = 'ue8c7';
$chars['entypo-fontello'][] = 'ue824';
$chars['entypo-fontello'][] = 'ue825';
$chars['entypo-fontello'][] = 'ue85d';
$chars['entypo-fontello'][] = 'ue85c';
$chars['entypo-fontello'][] = 'ue812';
$chars['entypo-fontello'][] = 'ue81b';
$chars['entypo-fontello'][] = 'ue818';
$chars['entypo-fontello'][] = 'ue815';
$chars['entypo-fontello'][] = 'ue819';
$chars['entypo-fontello'][] = 'ue816';
$chars['entypo-fontello'][] = 'ue814';
$chars['entypo-fontello'][] = 'ue81a';
$chars['entypo-fontello'][] = 'ue817';
$chars['entypo-fontello'][] = 'ue8c3';
$chars['entypo-fontello'][] = 'ue868';
$chars['entypo-fontello'][] = 'ue81e';
$chars['entypo-fontello'][] = 'ue81f';
$chars['entypo-fontello'][] = 'ue81c';
$chars['entypo-fontello'][] = 'ue81d';
$chars['entypo-fontello'][] = 'ue83e';
$chars['entypo-fontello'][] = 'ue891';
$chars['entypo-fontello'][] = 'ue890';
$chars['entypo-fontello'][] = 'ue88f';
$chars['entypo-fontello'][] = 'ue894';
$chars['entypo-fontello'][] = 'ue820';
$chars['entypo-fontello'][] = 'ue892';
$chars['entypo-fontello'][] = 'ue839';
$chars['entypo-fontello'][] = 'ue895';
$chars['entypo-fontello'][] = 'ue8aa';
$chars['entypo-fontello'][] = 'ue893';
$chars['entypo-fontello'][] = 'ue896';
$chars['entypo-fontello'][] = 'ue8a5';
$chars['entypo-fontello'][] = 'ue8a6';
$chars['entypo-fontello'][] = 'ue810';
$chars['entypo-fontello'][] = 'ue811';
$chars['entypo-fontello'][] = 'ue84b';
$chars['entypo-fontello'][] = 'ue84c';
$chars['entypo-fontello'][] = 'ue848';
$chars['entypo-fontello'][] = 'ue849';
$chars['entypo-fontello'][] = 'ue84a';
$chars['entypo-fontello'][] = 'ue80e';
$chars['entypo-fontello'][] = 'ue80d';
$chars['entypo-fontello'][] = 'ue802';
$chars['entypo-fontello'][] = 'ue850';
$chars['entypo-fontello'][] = 'ue847';
$chars['entypo-fontello'][] = 'ue82e';
$chars['entypo-fontello'][] = 'ue82d';
$chars['entypo-fontello'][] = 'ue8d0';
$chars['entypo-fontello'][] = 'ue8b0';
$chars['entypo-fontello'][] = 'ue8b2';
$chars['entypo-fontello'][] = 'ue82f';
$chars['entypo-fontello'][] = 'ue828';
$chars['entypo-fontello'][] = 'ue829';
$chars['entypo-fontello'][] = 'ue84e';
$chars['entypo-fontello'][] = 'ue897';
$chars['entypo-fontello'][] = 'ue899';
$chars['entypo-fontello'][] = 'ue89a';
$chars['entypo-fontello'][] = 'ue898';
$chars['entypo-fontello'][] = 'ue89d';
$chars['entypo-fontello'][] = 'ue89e';
$chars['entypo-fontello'][] = 'ue89c';
$chars['entypo-fontello'][] = 'ue89b';
$chars['entypo-fontello'][] = 'ue869';
$chars['entypo-fontello'][] = 'ue86a';
$chars['entypo-fontello'][] = 'ue860';
$chars['entypo-fontello'][] = 'ue85f';
$chars['entypo-fontello'][] = 'ue888';
$chars['entypo-fontello'][] = 'ue887';
$chars['entypo-fontello'][] = 'ue88a';
$chars['entypo-fontello'][] = 'ue889';
$chars['entypo-fontello'][] = 'ue880';
$chars['entypo-fontello'][] = 'ue87f';
$chars['entypo-fontello'][] = 'ue882';
$chars['entypo-fontello'][] = 'ue881';
$chars['entypo-fontello'][] = 'ue870';
$chars['entypo-fontello'][] = 'ue86f';
$chars['entypo-fontello'][] = 'ue872';
$chars['entypo-fontello'][] = 'ue871';
$chars['entypo-fontello'][] = 'ue884';
$chars['entypo-fontello'][] = 'ue883';
$chars['entypo-fontello'][] = 'ue886';
$chars['entypo-fontello'][] = 'ue885';
$chars['entypo-fontello'][] = 'ue874';
$chars['entypo-fontello'][] = 'ue873';
$chars['entypo-fontello'][] = 'ue876';
$chars['entypo-fontello'][] = 'ue875';
$chars['entypo-fontello'][] = 'ue878';
$chars['entypo-fontello'][] = 'ue877';
$chars['entypo-fontello'][] = 'ue87a';
$chars['entypo-fontello'][] = 'ue879';
$chars['entypo-fontello'][] = 'ue87c';
$chars['entypo-fontello'][] = 'ue87b';
$chars['entypo-fontello'][] = 'ue87e';
$chars['entypo-fontello'][] = 'ue87d';
$chars['entypo-fontello'][] = 'ue88c';
$chars['entypo-fontello'][] = 'ue88b';
$chars['entypo-fontello'][] = 'ue88e';
$chars['entypo-fontello'][] = 'ue88d';
$chars['entypo-fontello'][] = 'ue86e';
$chars['entypo-fontello'][] = 'ue8eb';
$chars['entypo-fontello'][] = 'ue8ec';
$chars['entypo-fontello'][] = 'ue8ed';
$chars['entypo-fontello'][] = 'ue8ee';
$chars['entypo-fontello'][] = 'ue8ef';
$chars['entypo-fontello'][] = 'ue8f0';
$chars['entypo-fontello'][] = 'ue8f1';
$chars['entypo-fontello'][] = 'ue8f2';
$chars['entypo-fontello'][] = 'ue8f3';
$chars['entypo-fontello'][] = 'ue8f4';
$chars['entypo-fontello'][] = 'ue8f5';
$chars['entypo-fontello'][] = 'ue8f6';
$chars['entypo-fontello'][] = 'ue8f7';
$chars['entypo-fontello'][] = 'ue8f8';
$chars['entypo-fontello'][] = 'ue8f9';
$chars['entypo-fontello'][] = 'ue8fa';
$chars['entypo-fontello'][] = 'ue8fb';
$chars['entypo-fontello'][] = 'ue8fc';
$chars['entypo-fontello'][] = 'ue8fd';
$chars['entypo-fontello'][] = 'ue8fe';
$chars['entypo-fontello'][] = 'ue8ff';
$chars['entypo-fontello'][] = 'ue900';
$chars['entypo-fontello'][] = 'ue901';
$chars['entypo-fontello'][] = 'ue902';
$chars['entypo-fontello'][] = 'ue903';
$chars['entypo-fontello'][] = 'ue904';
$chars['entypo-fontello'][] = 'ue905';
$chars['entypo-fontello'][] = 'ue906';
$chars['entypo-fontello'][] = 'ue907';
$chars['entypo-fontello'][] = 'ue908';
$chars['entypo-fontello'][] = 'ue909';
$chars['entypo-fontello'][] = 'ue90a';
$chars['entypo-fontello'][] = 'ue90b';
$chars['entypo-fontello'][] = 'ue90c';
$chars['entypo-fontello'][] = 'ue90d';
$chars['entypo-fontello'][] = 'ue90e';
$chars['entypo-fontello'][] = 'ue90f';
$chars['entypo-fontello'][] = 'ue910';
$chars['entypo-fontello'][] = 'ue911';
$chars['entypo-fontello'][] = 'ue912';
$chars['entypo-fontello'][] = 'ue913';
$chars['entypo-fontello'][] = 'ue914';
$chars['entypo-fontello'][] = 'ue915';
$chars['entypo-fontello'][] = 'ue916';
$chars['entypo-fontello'][] = 'ue917';
$chars['entypo-fontello'][] = 'ue918';


































































































































































































































