(function($) {
    "use strict";
    $.InvioModal.register_callback = $.InvioModal.register_callback || {};

    $.InvioModal.register_callback.modal_load_tablebuilder = function(passed_scope) {
        var scope = passed_scope || this.modal,
            $scope = $(scope),
            $table = $(scope).find('.invio-table'),
            open = false,

            methods = {

                init: function() {
                    methods.attachEvents();
                    methods.on_load();
                },

                attachEvents: function() {
                    scope.on('change', '.invio-table-data-container', methods.update_textfield);
                    scope.on('click', '.invio-table-cell:not(.invio-delete-row .invio-table-cell, .invio-table-col-style .invio-table-cell, .invio-button-row .invio-table-cell)', methods.show_editor);
                    scope.on('click', '.invio-button-row .invio-table-cell', methods.add_button);
                    scope.on('click', '.invio-attach-table-row', methods.add_row);
                    scope.on('click', '.invio-attach-table-col', methods.add_col);
                    scope.on('click', '.invio-delete-row .invio-table-cell', methods.remove_col);
                    scope.on('click', '.invio-attach-delete-table-row', methods.remove_row);
                    scope.on('click', '.invio_sorthandle .invio-delete', methods.remove_element);
                    scope.on('click', '.invio-table-pos-button', methods.change_order)
                    scope.on('change', 'select[name=column_style]', methods.change_col_class);
                    scope.on('change', 'select[name=row_style]', methods.change_row_class);
                    scope.on('click', methods.close_editor);
                    scope.on('keyup', methods.cell_tab);
                    scope.find('.invio-delete-row .invio-table-cell, .invio-table-builder-add-buttons a').disableSelection();
                },

                on_load: function() {
                    $table.find('textarea').attr('name', 'content');
                },

                cell_tab: function(e) {
                    if (e.keyCode == 9 && open) {
                        var elements = $table.find('.invio-table-cell:not(.invio-table-cell-delete, .invio-delete-row .invio-table-cell, .invio-template-row .invio-table-cell, .invio-table-cell-style, .invio-table-col-style .invio-table-cell)'),
                            index = elements.index(open),
                            direction = e.shiftKey ? -1 : 1,
                            next = elements.filter(':eq(' + (index + direction) + ')');

                        if (!next.length) {
                            next = direction == 1 ? elements.filter(':eq(0)') : elements.filter(':last');
                        }

                        e.preventDefault();
                        e.stopPropagation();
                        next.trigger('click');
                    }
                },

                show_editor: function(e) {
                    e.stopPropagation();
                    if (open != this) methods.close_editor();

                    this.className += " invio-show-editor ";
                    $(this).parents('.invio-table-cell:eq(0)').add(this).find('.invio-table-data-container').focus();

                    open = this;
                },

                close_editor: function() {
                    $scope.find('.invio-show-editor').removeClass('invio-show-editor').find('.invio-table-data-container').trigger('change');
                },

                update_textfield: function() {
                    var value = this.value,
                        field = $(this).prev('.invio-table-content').html(invio_nl2br(value));
                },

                add_row: function() {
                    var template = $scope.find('.invio-template-row'),
                        clone = template.clone().removeClass('invio-template-row').insertBefore(template);
                },

                add_col: function() {
                    var columns = $scope.find('.invio-template-row .invio-table-cell');

                    if (columns.length <= 21) {
                        var template = $scope.find('.invio-template-row .invio-table-cell:eq(1)'),
                            insert = $scope.find('.invio-table-row .invio-table-cell-delete'),
                            clone = template.clone().attr('class', 'invio-table-cell').insertBefore(insert),
                            dropdown = $scope.find('.invio-table-cell:eq(1)').html(),
                            insert2 = $scope.find('.invio-table-col-style .invio-table-cell:not(.invio-table-cell-delete):last');

                        insert2.html(dropdown).find('select').val('').trigger('change');
                    }


                },
                remove_row: function() {
                    var elements = $table.find('.invio-table-row'),
                        row = $(this).parents('.invio-table-row:eq(0)');

                    if (elements.length > 4) {
                        row.remove();
                    } else {
                        row.find('.invio-table-data-container').val('').trigger('change');
                    }
                },
                remove_col: function(e) {
                    var elements = $(this).parents('.invio-table-row:eq(0)').find('.invio-table-cell'),
                        index = elements.index(this);

                    if (elements.length > 3) {
                        $table.find('.invio-table-row .invio-table-cell:nth-child(' + (index + 1) + ')').remove();
                    }
                },

                change_row_class: function() {
                    var select = $(this),
                        current = select.parents('.invio-table-cell:eq(0)'),
                        elements = select.parents('.invio-table-row:eq(0)').find('.invio-table-cell'),
                        index = elements.index(current),
                        row = select.parents('.invio-table-row:eq(0)'),
                        classNames = select.find('option').map(function() {
                            return this.value }).get().join(" "),
                        newClass = select.val();

                    row.removeClass(classNames).addClass(newClass);

                    if (newClass == 'invio-button-row') {
                        row.find('textarea').val("").trigger('change');
                    } else {
                        /* old version: removes the content of the table when class is changed. doesnt need vars: current, elements, index
                        var template = $scope.find('.invio-template-row .invio-table-cell:eq(1)');
                        row.find('.invio-table-cell:not(.invio-table-cell-style.invio-table-cell, .invio-table-cell-delete.invio-table-cell)').html(template.html());
                        */

                        $table.find('.invio-table-row .invio-table-cell:not(.invio-delete-row .invio-table-cell):nth-child(' + (index + 1) + ')').removeClass(classNames).addClass(newClass);
                    }
                },

                change_col_class: function() {
                    var select = $(this),
                        current = select.parents('.invio-table-cell:eq(0)'),
                        elements = select.parents('.invio-table-row:eq(0)').find('.invio-table-cell'),
                        index = elements.index(current),
                        classNames = select.find('option').map(function() {
                            return this.value }).get().join(" "),
                        newClass = select.val();

                    $table.find('.invio-table-row .invio-table-cell:not(.invio-delete-row .invio-table-cell):nth-child(' + (index + 1) + ')').removeClass(classNames).addClass(newClass);

                },

                add_button: function() {
                    var template = $("#invio-tmpl-invio_sc_button").html(),
                        current = $(this);

                    if (!current.is('.invio-table-cell')) current = current.parents('.invio-table-cell:eq(0)');

                    if (current.find('.invio-edit-element, select').length == 0) {
                        current.html(template);
                        current.find('textarea').attr('name', 'content').trigger('click');
                    }

                },

                remove_element: function(e) {
                    var select = $(this),
                        template = $scope.find('.invio-template-row .invio-table-cell:eq(1)'),
                        current = select.parents('.invio-table-cell:eq(0)').html(template.html());
                    e.stopImmediatePropagation();
                },

                change_order: function(e) {
                    var button = $(this),
                        direction = button.data('direction');


                    if (direction == 'up' || direction == 'down') {
                        methods.change_row_order(button, direction);
                    } else {
                        methods.change_col_order(button, direction);
                    }
                    return false;
                },

                change_row_order: function(button, direction) {
                    var row = button.parents('.invio-table-row').eq(0),
                        moveTo = direction === "up" ? row.prev() : row.next();

                    //if its the first or last visible row dont move it
                    if (moveTo.is('.invio-template-row') || moveTo.is('.invio-attach-table-col-style')) return;

                    if (direction === "up") {
                        row.insertBefore(moveTo);
                    } else {
                        row.insertAfter(moveTo);
                    }

                },

                change_col_order: function(button, direction) {
                    var current = button.parents('.invio-table-cell:eq(0)'),
                        elements = button.parents('.invio-table-row:eq(0)').find('.invio-table-cell'),
                        index = elements.index(current),
                        move_els = $table.find('.invio-table-row .invio-table-cell:nth-child(' + (index + 1) + ')');

                    if ((index === 1 && direction === "left") || (index === elements.length - 2 && direction === "right")) return;

                    move_els.each(function() {
                        var col = $(this);

                        if (direction === "left") {
                            col.insertBefore(col.prev());
                        } else {
                            col.insertAfter(col.next());
                        }

                    });
                },


            };


        methods.init();
    }


    //table shortcode constructor
    $.InvioModal.register_callback.before_table_save = function(values, save_param) {
        if (values.column_style.length == "") values.column_style = [""];
        if (typeof values.column_style === 'string') values.column_style = [values.column_style];

        var columns = values.column_style.length,
            rows = values.row_style.length - 3,
            output = "",
            index = 0;

        output += "[invio_table";

        for (var y in values) {
            if (y.indexOf('invioTB') != -1) {
                output += " " + y.replace(/invioTB/g, "") + "='" + values[y] + "'";
            }
        }

        output += "]\n"

        for (var i = 0; i < rows; i++) {
            output += "[invio_row row_style='" + values.row_style[i + 1] + "']";
            for (var j = 0; j < columns; j++) {
                output += "[invio_cell col_style='" + values.column_style[j] + "']";
                output += values.content[index];
                output += "[/invio_cell]"
                index++;
            }
            output += "[/invio_row]\n"
        }

        output += "[/invio_table]\n\n";

        return output;
    }




})(jQuery);
