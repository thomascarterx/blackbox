(function($) {
    "use strict";

    $.InvioElementBehavior = $.InvioElementBehavior || {};
    $.InvioElementBehavior.wp_save_template = function() {
        this.container = $('.invio-template-save-button-container');
        this.toggle = this.container.find('.open-template-button');
        this.dropdown = this.container.find('.invio-template-save-button-inner');
        this.list = this.dropdown.find('ul');
        this.save_btn = this.container.find('.save-template-button');
        this.save_single_container = this.container.parents('.postbox');
        this.savebox = false;
        this.bind_events();
        this.template_val = "";
    }


    $.InvioElementBehavior.wp_save_template.prototype = {
        bind_events: function() {
            var obj = this;

            this.list.on('click', 'span:not(.preloading)', function(e) { obj.delete_template(e); });
            this.list.on('click', 'a', function(e) { obj.fetch_template(e); });
            this.toggle.on('click', function() { obj.toggle_dropdown(); });
            this.save_btn.on('click', function() { obj.open_modal(); });
            this.save_single_container.on('click', '.invio-save-element', function(e) { obj.open_modal(e); });


            $('body').on('click', function(e) { obj.close_check(e); })
        },

        toggle_dropdown: function() {
            if (this.container.is('.invio-hidden-dropdown')) {
                this.container.removeClass('invio-hidden-dropdown');
                this.toggle.removeClass('invio-template-added-highlight');
            } else {
                this.container.addClass('invio-hidden-dropdown');
            }

            return false;
        },

        close_check: function(event) {
            if (!this.container.is('.invio-hidden-dropdown') && $(event.target).parents('.invio-template-save-button-container:eq(0), .invio-modal:eq(0)').length == 0) {
                this.toggle_dropdown();
            }
        },

        open_modal: function(e) {
            $.invio_builder.updateTextarea(); // make sure the content is converted to invio shortcodes            

            this.textarea_value(e);

            if (this.template_val.indexOf('[') === -1) {
                this.toggle_dropdown();
                new $.InvioModalNotification({ mode: 'attention', msg: invio_template_save_L10n.no_content });
            } else {
                var title = invio_template_save_L10n.chose_name,
                    msg = "<input name = 'invio-builder-template' type='text' class='invio-template-name-ajax' value='' maxlength='40' />" +
                    "<span class='invio-template-save-msg'>" + invio_template_save_L10n.save_msg + "</span>" +
                    "<span class='invio-template-save-chars'>" + invio_template_save_L10n.chars + ", A-Z, 0-9, -_</span>";

                if (typeof e != "undefined") {
                    title = invio_template_save_L10n.chose_save;
                }

                this.savebox = new $.InvioModalNotification({
                    mode: 'attention',
                    msg: msg,
                    modal_title: title,
                    button: 'save',
                    scope: this,
                    on_save: this.try_save,
                    save_param: { event: e }
                });
            }

            return false
        },

        textarea_value: function(e) {
            this.template_val = "";

            /* fetchign the value like this returns code with p + br tags which we dont want
            if(typeof window.tinyMCE == 'undefined' || typeof window.tinyMCE.get('content') == 'undefined')
            {
                value = $.trim($('#content.wp-editor-area').val());
            }
            else
            {
                value = $.trim(window.tinyMCE.get('content').getContent({format:'raw'}));
            }
            */


            //store only a single el?
            if (typeof e != "undefined" && e.currentTarget.className == "invio-save-element") {
                this.template_val = $.trim($(e.currentTarget).parent('div').next('.invio_inner_shortcode').find('textarea').val());
            } else {
                this.template_val = $.trim($('#content.wp-editor-area').val());
            }
            return this.template_val;
        },

        update_entry_list: function(name) {
            var obj = this;

            //remove the empty list
            this.list.find('.invio-no-template').slideUp(200, function() {
                $(this).remove();
            })

            //attach the new element, sort the list then show the item
            var newItem = $("<li><a href='#'>" + name + "</a><span class='invio-delete-template'></span></li>").css('display', 'none').appendTo(this.list),
                listitems = this.list.children('li').get();

            listitems.sort(function(a, b) {
                return $(a).text().toUpperCase().localeCompare($(b).text().toUpperCase());
            });

            $.each(listitems, function(idx, itm) { obj.list.append(itm); });

            newItem.slideDown();
        },

        insert_template: function(template) {
            $.invio_builder.sendToAdvancedEditor(template);
            $.invio_builder.updateTextarea();
            $.invio_builder.do_history_snapshot();
        },

        fetch_template: function(e) {
            e.preventDefault();

            var obj = this,
                template = $(e.target),
                list = template.parent(),
                del_btn = list.find('span'),
                name = template.text();

            $.ajax({

                type: "POST",
                url: ajaxurl,
                data: {
                    action: 'invio_ajax_fetch_builder_template',
                    templateName: name,
                    invio_request: true
                },
                beforeSend: function() {
                    del_btn.addClass('preloading');
                },
                error: function() // no connection
                    {
                        new $.InvioModalNotification({ mode: 'error', msg: invio_modal_L10n.ajax_error });
                    },
                success: function(response) {
                    del_btn.removeClass('preloading');

                    if (response == 0) // not logged in
                    {
                        new $.InvioModalNotification({ mode: 'error', msg: invio_modal_L10n.login_error });
                    } else if (response == "-1") // nonce timeout
                    {
                        new $.InvioModalNotification({ mode: 'error', msg: invio_modal_L10n.timeout });
                    } else {
                        if (response.indexOf('invio_fetching_error') !== -1) //template not found
                        {
                            new $.InvioModalNotification({ mode: 'error', msg: invio_template_save_L10n.not_found });
                        } else {
                            obj.insert_template(response);
                        }
                    }
                }
            });

        },

        delete_template: function(e) {
            e.preventDefault();

            var current = $(e.target),
                template = current.prev('a'),
                list = template.parent(),
                name = template.text();

            $.ajax({
                type: "POST",
                url: ajaxurl,
                data: {
                    action: 'invio_ajax_delete_builder_template',
                    post_id: invio_globals.post_id,
                    templateName: name,
                    invio_request: true,
                    'invio-save-nonce': $('#invio-save-nonce').val()
                },
                beforeSend: function() {
                    current.addClass('preloading');
                },
                error: function() // no connection
                    {
                        new $.InvioModalNotification({ mode: 'error', msg: invio_modal_L10n.ajax_error });
                    },
                success: function(response) {
                    if (response == 0) // not logged in
                    {
                        new $.InvioModalNotification({ mode: 'error', msg: invio_modal_L10n.login_error });
                        current.removeClass('preloading');
                    } else if (response == "-1") // nonce timeout
                    {
                        new $.InvioModalNotification({ mode: 'error', msg: invio_modal_L10n.timeout });
                        current.removeClass('preloading');
                    } else {
                        if (response.indexOf('invio_template_deleted') !== -1) //template already in use
                        {
                            list.slideUp(300, function() {
                                list.remove();
                            });
                        }
                    }
                }
            });

        },


        try_save: function(values, event) {
            var obj = this,
                name = values['invio-builder-template'],
                disallowed_chars = name.match(/[^a-zA-Z0-9-_ ]/),
                error = false,
                save_msg_wrap = this.savebox.modal.find('.invio-template-save-msg').text(invio_template_save_L10n.save_msg),
                footer = this.savebox.modal.find('.invio-modal-inner-footer');

            this.savebox.modal.find('.invio-template-save-error').removeClass('invio-template-save-error');

            if (name.length < 3) {
                save_msg_wrap.addClass('invio-template-save-error');
                error = true;
            }

            if (disallowed_chars != null) {
                this.savebox.modal.find('.invio-template-save-chars').addClass('invio-template-save-error');
                error = true;
            }

            if (!error) {
                $.ajax({
                    type: "POST",
                    url: ajaxurl,
                    data: {
                        action: 'invio_ajax_save_builder_template',
                        post_id: invio_globals.post_id,
                        templateName: name,
                        invio_request: true,
                        templateValue: obj.template_val,
                        'invio-save-nonce': $('#invio-save-nonce').val()
                    },
                    beforeSend: function() {
                        footer.addClass('preloading');
                    },
                    error: function() // no connection
                        {
                            $.InvioModal.openInstance[0].close();
                            new $.InvioModalNotification({ mode: 'error', msg: invio_modal_L10n.ajax_error });
                        },
                    success: function(response) {
                        footer.removeClass('preloading');

                        if (response == 0) // not logged in
                        {
                            $.InvioModal.openInstance[0].close();
                            new $.InvioModalNotification({ mode: 'error', msg: invio_modal_L10n.login_error });
                        } else if (response == "-1") // nonce timeout
                        {
                            $.InvioModal.openInstance[0].close();
                            new $.InvioModalNotification({ mode: 'error', msg: invio_modal_L10n.timeout });
                        } else {
                            if (response.indexOf('invio_template_saved') === -1) //template already in use
                            {
                                save_msg_wrap.addClass('invio-template-save-error').text(response);
                            } else //save success!
                            {
                                obj.update_entry_list(name);
                                obj.savebox.close();

                                //mark the template button if a single element was saved
                                if (typeof event != "undefined") {
                                    obj.toggle.addClass('invio-template-added-highlight');
                                }
                            }
                        }
                    }
                });
            }
            return false;
        }
    }


})(jQuery);
