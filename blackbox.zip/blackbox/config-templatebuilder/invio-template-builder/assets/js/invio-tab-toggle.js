(function($) {
    "use strict";
    $.InvioModal.register_callback = $.InvioModal.register_callback || {};

    $.InvioModal.register_callback.modal_start_sorting = function(passed_scope) {
        var scope = passed_scope || this.modal,
            target = scope.find('.invio-modal-group'),
            params = {
                handle: '.invio-attach-modal-element-move',
                items: '.invio-modal-group-element',
                placeholder: "invio-modal-group-element-highlight",
                tolerance: "pointer",
                forcePlaceholderSize: true,
                start: function(event, ui) {
                    $('.invio-modal-group-element-highlight').height(ui.item.outerHeight()).width(ui.item.outerWidth());
                },
                update: function(event, ui) {
                    //obj.updateTextarea();
                    ui.item.parents('.invio-modal-group:eq(0)').trigger('invio-item-moved', [ui.item]);
                },
                stop: function(event, ui) {
                    //obj.canvas.removeClass('invio-start-sorting');
                }
            };

        target.find('.invio-modal-group-element, .invio-insert-area').disableSelection();
        target.sortable(params);
    }


    $.InvioModal.register_callback.modal_tab_functions = function(passed_scope) {
        var scope = passed_scope || this.modal,
            is_tabs = scope.find('.invio-tab-container').length;

        if (!is_tabs) return;

        var wrap = scope.find('.invio-modal-group-wrapper'),
            fakeContent = $('<div id="fakeTabContent" class="invio_textblock_style"></div>').appendTo(wrap),
            methods = {

                bind_events: function() {
                    wrap.on('update mouseenter', '.invio-modal-group-element', methods.update_fake);
                    fakeContent.on('click', methods.route_fakeContent_click);
                },

                update_fake: function() {
                    wrap.find('.invio-active').removeClass('invio-active');
                    fakeContent.html($(this).addClass('invio-active').find('.invio_content_container').html());
                },

                route_fakeContent_click: function() {
                    wrap.find('.invio-active .invio_title_container').trigger('click');
                    return false;
                }

            };


        methods.bind_events();
        wrap.find('.invio-modal-group-element:first').trigger('update');
    }







})(jQuery);
