<?php
global $builder;

$invio_default_title = __('Invio Layout Builder','invio_framework' );
if($builder->disable_drag_drop == true)
{
    $invio_default_title = __('Page Layout','invio_framework' );
}

$boxes = array(
    array( 'title' =>$invio_default_title, 'id'=>'invio_builder', 'page'=>array('post','portfolio','page','product'), 'context'=>'normal', 'priority'=>'high', 'expandable'=>true ),
    array( 'title' =>__('Layout','invio_framework' ), 'id'=>'layout', 'page'=>array('portfolio', 'page' , 'post'), 'context'=>'side', 'priority'=>'low'),
    array( 'title' =>__('Additional Portfolio Settings','invio_framework' ), 'id'=>'preview', 'page'=>array('portfolio'), 'context'=>'normal', 'priority'=>'high' ),
    array( 'title' =>__('Breadcrumb Hierarchy','invio_framework' ), 'id'=>'hierarchy', 'page'=>array('portfolio'), 'context'=>'side', 'priority'=>'low'),
);

$boxes = apply_filters('infio_filter_builder_boxes', $boxes);


$elements = array(
array(
        "slug"          => "invio_builder",
        "name"          => __("Visual layout editor",'invio_framework'),
        "id"            => "layout_editor",
        "type"          => array($builder,'visual_editor'),
        "tab_order"     => array(__('Layout Elements','invio_framework' ), __('Content Elements','invio_framework' ) , __('Media Elements','invio_framework' )),
        "desc"          =>  '<h4>'.__('Quick Info & Hotkeys', 'invio_framework' )."</h4>".
                            '<strong>'.__('General Info', 'invio_framework' ).'</strong>'.
                            "<ul>".
                            '   <li>'.__('To insert an Element either click the insert button for that element or drag the button onto the canvas', 'invio_framework' ).'</li>'.
                            '   <li>'.__('If you place your mouse above the insert button a short info tooltip will appear', 'invio_framework' ).'</li>'.
                            '   <li>'.__('To sort and arrange your elements just drag them to a position of your choice and release them', 'invio_framework' ).'</li>'.
                            '   <li>'.__('Valid drop targets will be highlighted. Some elements like fullwidth sliders and color section can not be dropped onto other elements', 'invio_framework' ).'</li>'.
                            "</ul>".
                            '<strong>'.__('Edit Elements in Popup Window:', 'invio_framework' ).'</strong>'.
                            "<ul>".
                            '   <li>'.__('Most elements open a popup window if you click them', 'invio_framework' ).'</li>'.
                            '   <li>'.__('Press TAB to navigate trough the various form fields of a popup window.', 'invio_framework' ).'</li>'.
                            '   <li>'.__('Press ESC on your keyboard or the Close Button to close popup window.', 'invio_framework' ).'</li>'.
                            '   <li>'.__('Press ENTER on your keyboard or the Save Button to save current state of a popup window', 'invio_framework' ).'</li>'.
                            "</ul>"
    ),

    array(
        "container_class" => "invio_2columns invio_col_1 invio-style",
        "slug"  => "preview",
        "name"  => __("Overwrite Portfolio Link setting",'invio_framework'),
        "desc"  => __("If this entry is displayed in a portfolio grid, it will use the grids link settings (open either in lightbox, or open link url). You may overwrite this setting here",'invio_framework'),
        "id"    => "_portfolio_custom_link",
        "type"  => "select",
        "std"   => "",
        "subtype" => array( "Use default setting"   => '',
                            "Define custom link" => 'custom',

        )),

    array(
        "slug"  => "preview",
        "name"  => __("Link portfolio item to external URL",'invio_framework' ),
        "desc"  => __("You can add a link to any (external) page here. ",'invio_framework' ).
        "<br/>".__("If you add a link to a video that video will open in a lightbox ",'invio_framework' ),
        "id"    => "_portfolio_custom_link_url",
        "type"  => "input",
        "required"  => array('_portfolio_custom_link','equals','custom'),
        "container_class" => "invio-style invio_2columns invio_col_2",
        "std"   => "http://"),

    array(
        "slug"  => "preview",
        "id"    => "_portfolio_hr",
        "type"  => "hr",
        "std"   => ""),


    array(
        "slug"  => "preview",
        "name"  => __("Ajax Portfolio Preview Settings",'invio_framework' ),
        "desc"  => __("If you have selected to display your portfolio grid as an 'Ajax Portfolio' please choose preview images here and write some preview text. Once the user clicks on the portfolio item a preview element with those images and info will open.",'invio_framework' ),
        "id"    => "_preview_heading",
        "type"  => "heading",
        "std"   => ""),


    array(
        "slug"  => "preview",
        "container_class" => "invio_2columns invio_col_1",
        "name"  => __("Add Preview Images",'invio_framework' ),
        "desc"  => __("Create a new Preview Gallery or Slideshow by selecting existing or uploading new images",'invio_framework' ),
        "id"    => "_preview_ids",
        "type"  => "gallery",
        "title" => __("Add Preview Images",'invio_framework' ),
        "delete" => __("Remove Images",'invio_framework' ),
        "button" => __("Insert Images",'invio_framework' ),
        "std"   => ""),

        array(
        "container_class" => "invio_2columns invio_col_2",
        "slug"  => "preview",
        "name"  => __("Display Preview Images",'invio_framework'),
        "desc"  => __("Display Images as either gallery, slideshow or as a list below each other",'invio_framework'),
        "id"    => "_preview_display",
        "type"  => "select",
        "std"   => "gallery",
        "class" => "invio-style",
        "subtype" => array( __("Gallery",'invio_framework')      => 'gallery',
                            __("Slideshow",'invio_framework')    => 'slideshow',
                            __("Image List",'invio_framework')   => 'list',
                            __("Don't show the images at all and display the preview text only",'invio_framework')  => 'no'

        ),
        ),

        array(
        "container_class" => "invio_2columns invio_col_2",
        "slug"  => "preview",
        "name"  => __("Autorotation",'invio_framework'),
        "desc"  => __("Slideshow autorotation Settings in Seconds",'invio_framework'),
        "id"    => "_preview_autorotation",
        "type"  => "select",
        "std"   => "disabled",
        "class" => "invio-style",
        "required"  => array('_preview_display','equals','slideshow'),
        "subtype" => array(
                            __("Disabled",'invio_framework')  => 'disabled',
                            "3"   => '3',
                            "4"   => '4',
                            "5"   => '5',
                            "6"   => '6',
                            "7"   => '7',
                            "8"   => '8',
                            "9"   => '9',
                            "10"   => '10',
                            "15"   => '15',
                            "20"   => '20',

        ),
        ),

                array(
        "container_class" => "invio_2columns invio_col_2",
        "slug"  => "preview",
        "name"  => __("Gallery Thumbnail Columns",'invio_framework'),
        "desc"  => __("How many Thumbnails should be displayed beside each other",'invio_framework'),
        "id"    => "_preview_columns",
        "type"  => "select",
        "std"   => "6",
        "class" => "invio-style",
        "required"  => array('_preview_display','equals','gallery'),
        "subtype" => array(
                            "2"   => '2',
                            "3"   => '3',
                            "4"   => '4',
                            "5"   => '5',
                            "6"   => '6',
                            "7"   => '7',
                            "8"   => '8',
                            "9"   => '9',
                            "10"   => '10',
                            "11"   => '11',
                            "12"   => '12',

        ),
        ),



    array(
        "slug"  => "preview",
        "container_class" => "invio_clear",
        "name"  => __("Add Preview Text",'invio_framework' ),
        "desc"  => __("The text will appear beside your gallery/slideshow",'invio_framework' ),
        "id"    => "_preview_text",
        "type"  => "tiny_mce",
        "std"   => ""),


    array(

        "slug"  => "layout",
        "name"  => __("Sidebar Settings",'invio_framework'),
        "desc"  => __("Select the desired Page layout",'invio_framework'),
        "id"    => "layout",
        "type"  => "select",
        "std"   => "",
        "class" => "invio-style",
        "subtype" => array( __("Default Layout - set in",'invio_framework')." ".THEMENAME." > " . __('Sidebar','invio_framework') => '',
                            __("No Sidebar",'invio_framework')       => 'fullsize',
                            __("Left Sidebar",'invio_framework')     => 'sidebar_left',
                            __("Right Sidebar",'invio_framework')    => 'sidebar_right',

        ),
        ),


    array(

        "slug"  => "layout",
        "name"  => __("Sidebar Setting",'invio_framework'),
        "desc"  => __("Choose a custom sidebar for this entry",'invio_framework'),
        "id"    => "sidebar",
        "type"  => "select",
        "std"   => "",
        "class" => "invio-style",
        "required" => array('layout','not','fullsize'),
        "subtype" => InvioHelper::get_registered_sidebars(array('Default Sidebars' => ""), array('Displayed Everywhere'))

        ),
        
        array(

        "slug"  => "layout",
        "name"  => __("Footer Settings",'invio_framework'),
        "desc"  => __("Display the footer widgets?",'invio_framework'),
        "id"    => "footer",
        "type"  => "select",
        "std"   => "",
        "class" => "invio-style",
        "subtype" => array(
                        __("Default Layout - set in",'invio_framework')." ".THEMENAME." > ". __('Footer','invio_framework') => '',
                        __('Display the footer widgets & socket','invio_framework')=>'all',
                        __('Display only the footer widgets (no socket)','invio_framework')=>'nosocket',
                        __('Display only the socket (no footer widgets)','invio_framework')=>'nofooterwidgets',
                        __('Don\'t display the socket & footer widgets','invio_framework')=>'nofooterarea'
                    ),

    ),
        
        
        array(
        "slug"  => "layout",
        "notice"  => __("These settings are only available for layouts with a main menu placed at the top",'invio_framework')." - <a href='".admin_url('admin.php?page=invio#goto_layout')."'>".__("Change layout",'invio_framework')."</a>",
        "id"    => "conditional_header",
        "type"  => "condition",
        "class" => "invio-style", 
        "condition" => array('option' => 'header_position', 'compare' => "equal_or_empty", "value"=>"header_top"),
        "nodescription" => true
        ),
        
        
        array(

        "slug"  => "layout",
        "name"  => __("Title Bar Settings",'invio_framework'),
        "desc"  => __("Display the Title Bar with Page Title and Breadcrumb Navigation?",'invio_framework'),
        "id"    => "header_title_bar",
        "type"  => "select",
        "std"   => "",
        "class" => "invio-style",
        "subtype" => array( __("Default Layout - set in",'invio_framework')." ".THEMENAME." > ". __('Header','invio_framework') => '',
                            __('Display title and breadcrumbs','invio_framework')    =>'title_bar_breadcrumb',
                            __('Display only title'           ,'invio_framework')    =>'title_bar',
                            __('Display only breadcrumbs', 'invio_framework')        =>'breadcrumbs_only',
                            __('Hide both'                    ,'invio_framework')    =>'hidden_title_bar',

                    )
        ),
        
        
        
        array(
        "slug"  => "layout",
        "notice"  => __("Only available if the logo is not",'invio_framework')." <a href='".admin_url('admin.php?page=invio#goto_header')."'>".__("below the menu",'invio_framework').".</a>",
        "id"    => "conditional_header2",
        "type"  => "condition",
        "class" => "invio-style", 
        "condition" => array('option' => 'header_layout', 'compare' => "contains", "value"=>"top_nav_header"),
        "nodescription" => true
        ),
        
        array(

        "slug"  => "layout",
        "name"  => __("Header visibility and transparency",'invio_framework'),
        "desc"  => __("Several options to change the header transparency and visibility on this page.",'invio_framework'),
        "id"    => "header_transparency",
        "type"  => "select",
        "std"   => "",
        "class" => "invio-style",
        "subtype" => array( __("No transparency",'invio_framework') => '',
                            __('Transparent Header','invio_framework') =>'header_transparent',
                            __('Transparent & Glassy Header','invio_framework') =>'header_transparent header_glassy ',
                            __('Header is invisible and appears once the users scrolls down ','invio_framework') =>'header_transparent header_scrolldown ',
                            __('Hide Header on this page ','invio_framework') =>'header_transparent header_hidden ',

                    )
        ),
        
        array(
        "slug"  => "layout",
        "id"    => "conditional_header_end",
        "type"  => "condition_end", 
        "nodescription" => true
        ),
        
        array(
        "slug"  => "layout",
        "id"    => "conditional_header_end",
        "type"  => "condition_end", 
        "nodescription" => true
        
        ),

        
    

    array(
        "slug"  => "hierarchy",
        "name"  => __("Breadcrumb parent page",'invio_framework'),
        "desc"  => __("Select a parent page for this entry. If no page is selected the them will use session data to build the breadcrumb.",'invio_framework'),
        "id"    => "breadcrumb_parent",
        "type"  => "select",
        "subtype" => 'page',
        "with_first" => true,
        "std"   => "",
        "class" => "invio-style",
    ),


);





$elements = apply_filters('infio_filter_builder_elements', $elements);




/*
array(

        "slug"  => "invio_builder",
        "name"  => "Layout",
        "desc"  => "Select the desired Page layout",
        "id"    => "layout",
        "type"  => "radio",
        "class" => "image_radio image_radio_layout",
        "std"   => "fullwidth",
        "options" => array( 'default'       => "Default layout",
                            'sidebar_left'  => "Left Sidebar",
                            'sidebar_right' => "Right Sidebar",
                            'fullwidth'     => "No Sidebar"
        ),

        "images" => array(  'default'       => InvioBuilder::$path['imagesURL']."layout-slideshow.png",
                            'sidebar_left'  => InvioBuilder::$path['imagesURL']."layout-left.png",
                            'sidebar_right' => InvioBuilder::$path['imagesURL']."layout-right.png",
                            'fullwidth'     => InvioBuilder::$path['imagesURL']."layout-fullwidth.png",
        ),
    ),
*/
