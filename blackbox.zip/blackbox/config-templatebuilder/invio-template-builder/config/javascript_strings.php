<?php

            
$strings['invio_modal_js']  = array(
                'ajax_error'     => __( 'Error fetching content - please reload the page and try again', 'invio_framework' ),
                'login_error'     => __( 'It seems your are no longer logged in. Please reload the page and try again', 'invio_framework' ),
                'timeout'         => __( 'Your session timed out. Simply reload the page and try again', 'invio_framework' ),
                'error'         => __( 'An error occured', 'invio_framework' ),
                'attention'     => __( 'Attention!', 'invio_framework' ),
                'success'         => __( 'All right!', 'invio_framework' ),
                'save'             => __( 'Save', 'invio_framework' ),
                'close'         => __( 'Close', 'invio_framework' ),
                
                /*shortcode specific*/
                'select_layout'  => __( 'Select a cell layout', 'invio_framework' ),
                'no_layout'  => __( 'The current number of cells does not allow any layout variations', 'invio_framework' ),
                'add_one_cell'  => __( 'You need to add at least one cell', 'invio_framework' ),
                'remove_one_cell'  => __( 'You need to remove at least one cell', 'invio_framework' ),
                
                'gmap_api_text' => __( 'Google changed the way google maps work. You now need to enter a valid Google Maps API Key', 'invio_framework' )."<br/><br/>".
                                   __( 'You can read a description on how to create and enter that key here:', 'invio_framework' )." ".
                                   "<a target='_blank' href='".admin_url( "admin.php?page=invio#goto_google" )."'>".__( 'Blackbox Google Settings', 'invio_framework' )."</a>",
                
                'gmap_api_wrong' => __( 'It seems that your Google API key is not configured correctly', 'invio_framework' )."<br/><br/>".
                                   __( 'The key is probably either restricted to the wrong domain or the domain syntax you entered is wrong.', 'invio_framework' )." <br><br>".
                                   __( 'Please check your API key', 'invio_framework' )." <a target='_blank' href='https://console.developers.google.com/apis/credentials'>".__( 'here', 'invio_framework' )."</a><br><br>".
                                   
                                   __( 'The domain that should be allowed is:', 'invio_framework' )." <br><strong>". trailingslashit(get_site_url()) ."*</strong>",
                                   
                'toomanyrequests'    => __("Too many requests at once, please wait a few seconds before requesting coordinates again",'invio_framework'),
                'notfound'            => __("Address couldn't be found by Google, please add it manually",'invio_framework'),
                'insertaddress'     => __("Please insert a valid address in the fields above",'invio_framework')                   
            
            );
            
            
$strings['invio_history_js']  = array(
                'undo_label' => __( 'Undo', 'invio_framework' ),
                'redo_label' => __( 'Redo', 'invio_framework' ),
            );            


$strings['invio_template_save_js']  = array(
                'no_content' => __( 'You need to add at least one element to the canvas to save this entry as a template', 'invio_framework' ),
                'chose_name' => __( 'Choose Template Name', 'invio_framework' ),
                'chose_save' => __( 'Save Element as Template: Choose a Name', 'invio_framework' ),
                'chars'      => __( 'Allowed Characters: Whitespace', 'invio_framework' ),
                'save_msg'   => __( 'Template Name must have at least 3 characters', 'invio_framework' ),
                'not_found'  => __( 'Could not load the template. You might want to try and reload the page', 'invio_framework' ),
            );    
