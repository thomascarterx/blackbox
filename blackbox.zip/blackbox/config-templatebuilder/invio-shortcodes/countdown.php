<?php
/**
 * Display Numbers that count from 0 to the number you entered
 */
 
if ( !class_exists( 'invio_sc_countdown' ) ) 
{
    
    class invio_sc_countdown extends invioShortcodeTemplate
    {
            /**
             * Create the config array for the shortcode button
             */
            function shortcode_insert_button()
            {
                $this->config['name']        = __('Animated Countdown', 'invio_framework' );
                $this->config['tab']        = __('Content Elements', 'invio_framework' );
                $this->config['icon']        = InvioBuilder::$path['imagesURL']."sc-countdown.png";
                $this->config['order']        = 14;
                $this->config['target']        = 'invio-target-insert';
                $this->config['shortcode']     = 'invio_countdown';
                $this->config['tooltip']     = __('Display a countdown to a specific date', 'invio_framework' );
                
                $this->time_array = array(
                                __('Second',      'invio_framework' )     =>'1',
                                __('Minute',      'invio_framework' )     =>'2',    
                                __('Hour',      'invio_framework' )     =>'3',
                                __('Day',          'invio_framework' )     =>'4',
                                __('Week',      'invio_framework' )     =>'5',
                                /*
                                __('Month',      'invio_framework' )     =>'6',
                                __('Year',      'invio_framework' )     =>'7'
                                */
                            );
            }
        
        
            /**
             * Popup Elements
             *
             * If this function is defined in a child class the element automatically gets an edit button, that, when pressed
             * opens a modal window that allows to edit the element properties
             *
             * @return void
             */
            function popup_elements()
            {
                $this->elements = array(
                    array(
                            "type"     => "tab_container", 'nodescription' => true
                        ),
                        
                    array(
                            "type"     => "tab",
                            "name"  => __("Content" , 'invio_framework'),
                            'nodescription' => true
                        ),
                        
                                                    
                    array(    
                            "name"     => __("Date",'invio_framework' ),
                            "desc"     => __("Pick a date in the future.",'invio_framework' ),
                            "id"     => "date",
                            "type"     => "datepicker",
                            "container_class" => 'invio_third invio_third_first',
                            "std"     => ""),
                    
                    array(    
                            "name"     => __("Hour", 'invio_framework' ),
                            "desc"     => __("Pick the hour of the day", 'invio_framework' ),
                            "id"     => "hour",
                            "type"     => "select",
                            "std"     => "12",
                            "container_class" => 'invio_third',
                            "subtype" => InvioHtmlHelper::number_array(0,23,1,array(),' h')),
                    
                    array(    
                            "name"     => __("Minute", 'invio_framework' ),
                            "desc"     => __("Pick the minute of the hour", 'invio_framework' ),
                            "id"     => "minute",
                            "type"     => "select",
                            "std"     => "0",
                            "container_class" => 'invio_third',
                            "subtype" => InvioHtmlHelper::number_array(0,59,1,array(),' min')),
                                
                    
                    array(    
                            "name"     => __("Smallest time unit", 'invio_framework' ),
                            "desc"     => __("The smallest unit that will be displayed", 'invio_framework' ),
                            "id"     => "min",
                            "type"     => "select",
                            "std"     => "1",
                            "subtype" => $this->time_array),
                    
                    
                    array(    
                            "name"     => __("Largest time unit", 'invio_framework' ),
                            "desc"     => __("The largest unit that will be displayed", 'invio_framework' ),
                            "id"     => "max",
                            "type"     => "select",
                            "std"     => "5",
                            "subtype" => $this->time_array),
                    
                    
                    
                            
                    array(
                            "name"     => __("Text Alignment", 'invio_framework' ),
                            "desc"     => __("Choose here, how to align your text", 'invio_framework' ),
                            "id"     => "align",
                            "type"     => "select",
                            "std"     => "center",
                            "subtype" => array(
                                                __('Center',  'invio_framework' ) =>'invio-align-center',
                                                __('Right',  'invio_framework' ) =>'invio-align-right',
                                                __('Left',  'invio_framework' ) =>'invio-align-left',
                                                )
                            ),
                            
                    array(    "name"     => __("Number Font Size", 'invio_framework' ),
                            "desc"     => __("Size of your numbers in Pixel", 'invio_framework' ),
                            "id"     => "size",
                            "type"     => "select",
                            "subtype" => InvioHtmlHelper::number_array(20,90,1, array( __("Default Size", 'invio_framework' )=>'')),
                            "std" => ""),
                            
                   array(
                            "type"     => "close_div",
                            'nodescription' => true
                        ),
                    
                    array(
                            "type"     => "tab",
                            "name"    => __("Colors",'invio_framework' ),
                            'nodescription' => true
                        ),
                                 
                   array(
                            "name"     => __("Colors", 'invio_framework' ),
                            "desc"     => __("Choose the colors here", 'invio_framework' ),
                            "id"     => "style",
                            "type"     => "select",
                            "std"     => "center",
                            "subtype" => array(
                                                __('Default',    'invio_framework' )     =>'invio-default-style',
                                                __('Theme colors',    'invio_framework' )     =>'invio-colored-style',
                                                __('Transparent Light', 'invio_framework' )     =>'invio-trans-light-style',
                                                __('Transparent Dark',  'invio_framework' )  =>'invio-trans-dark-style',
                                                )
                            ),
                    array(
                            "type"     => "close_div",
                            'nodescription' => true
                        ),
                        
                    array(
                            "type"     => "close_div",
                            'nodescription' => true
                        ),
                );

            }
            
            /**
             * Frontend Shortcode Handler
             *
             * @param array $atts array of attributes
             * @param string $content text within enclosing form of shortcode element 
             * @param string $shortcodename the shortcode found, when == callback name
             * @return string $output returns the modified html string 
             */
            function shortcode_handler($atts, $content = "", $shortcodename = "", $meta = "")
            {
                extract(shortcode_atts(array(    'date'         => '', 
                                                 'hour'         => '12', 
                                                 'minute'     => '0', 
                                                 'min'         => '1', 
                                                 'max'         => '5',
                                                 'align'        => 'center',
                                                 'size'        => '', 
                                                 'style'        => 'invio-default-style', 
                                                 'link'        => '', 
                                                 'title'        => ''
                                                 )
                                             , $atts));
                
                $this->full_time_array = array(
                
                    1 => array("interval" => 1000        , 'class'=>'seconds',     'label' => __('Second', 'invio_framework' ),    'label_multi' => __('Seconds',  'invio_framework')),
                    2 => array("interval" => 60000        , 'class'=>'minutes',     'label' => __('Minute', 'invio_framework' ),    'label_multi' => __('Minutes',  'invio_framework')),
                    3 => array("interval" => 3600000    , 'class'=>'hours',     'label' => __('Hour',      'invio_framework'),    'label_multi' => __('Hours',      'invio_framework')),
                    4 => array("interval" => 86400000    , 'class'=>'days',         'label' => __('Day',      'invio_framework' ), 'label_multi' => __('Days',      'invio_framework')),
                    5 => array("interval" => 604800000    , 'class'=>'weeks',     'label' => __('Week',      'invio_framework' ),    'label_multi' => __('Weeks',      'invio_framework')),
                    6 => array("interval" => 2678400000    , 'class'=>'months',     'label' => __('Month',  'invio_framework' ),    'label_multi' => __('Months',      'invio_framework')),
                    7 => array("interval" => 31536000000, 'class'=>'years',     'label' => __('Year',      'invio_framework' ),    'label_multi' => __('Years',      'invio_framework'))
                
                );
                

                $interval     = $this->full_time_array[$min]['interval'];
                $final_time = "";
                $output      = "";
                $digit_style= "";
                $el = isset($meta['el_class']) ? $meta['el_class'] : "";
                
                if(!empty($date))
                {
                    $date = explode("/", $date);
                
                    $final_time .= " data-year='".$date[2]."'";
                    $final_time .= " data-month='".((int) $date[0] - 1)."'";
                    $final_time .= " data-day='".$date[1]."'";
                    $final_time .= " data-hour='".$hour."'";
                    $final_time .= " data-minute='".$minute."'";
                    
                    if(!empty($size)) $digit_style = "font-size:{$size}px; ";
                    $tags = !empty($link) ? array( "a href='{$link}' ", "a") : array('span', 'span');
                    
                    
                    
                    $output .= "<div class='invio-countdown-timer {$align} {$style} {$el}' {$final_time} data-interval='{$interval}' data-maximum='{$max}' >";
                    
                    if( is_array( $title ) && isset( $title['top'] ) )
                    {
                        $output .= "<h3><{$tags[0]} class='invio-countdown-timer-title invio-countdown-timer-title-top'>".$title['top']."</{$tags[1]}></h3>";
                    }
                    
                    
                    $output .=         "<{$tags[0]} class='invio-countdown-timer-inner'>";
                    
                    foreach(array_reverse($this->time_array) as $key => $number)
                    {
                        if($number >= $min && $number <= $max)
                        {
                            $class   = $this->full_time_array[$number]['class'];
                            $single  = $this->full_time_array[$number]['label'];
                            $multi   = $this->full_time_array[$number]['label_multi'];
                            
                            $output .= "<span class='invio-countdown-cell invio-countdown-". $class ."'>";
                                $output .= "<span class='invio-countdown-cell-inner'>";
                                
                                    $output .= "<span class='invio-countdown-time' data-upate-width='{$class}' style='{$digit_style}'>0</span>";
                                    $output .= "<span class='invio-countdown-time-label' data-label='{$single}' data-label-multi='{$multi}'>".$multi."</span>";
                                    
                                $output .= "</span>";
                            $output .= "</span>";
                        }
                    }
                    
                    $output .=         "</{$tags[1]}>";
                    
                    if( is_array( $title ) && isset( $title['bottom'] ) )
                    {
                        $output .= "<h3><{$tags[0]} class='invio-countdown-timer-title invio-countdown-timer-title-bottom'>".$title['bottom']."</{$tags[1]}></h3>";
                    }
                    
                    
                    $output .= "</div>";
                }
                
                return $output;
            }
    }
}





