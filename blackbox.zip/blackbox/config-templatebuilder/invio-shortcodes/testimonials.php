<?php
/**
 * Sidebar
 * Displays one of the registered Widget Areas of the theme
 */

if ( !class_exists( 'invio_sc_testimonial' ) )
{
    class invio_sc_testimonial extends invioShortcodeTemplate
    {
            static $columnClass;
            static $rows;
            static $counter;
            static $columns;
            static $style;

            /**
             * Create the config array for the shortcode button
             */
            function shortcode_insert_button()
            {
                $this->config['name']        = __('Testimonials', 'invio_framework' );
                $this->config['tab']        = __('Content Elements', 'invio_framework' );
                $this->config['icon']        = InvioBuilder::$path['imagesURL']."sc-testimonials.png";
                $this->config['order']        = 20;
                $this->config['target']        = 'invio-target-insert';
                $this->config['shortcode']     = 'invio_testimonials';
                $this->config['shortcode_nested'] = array('invio_testimonial_single');
                $this->config['tooltip']     = __('Creates a Testimonial Grid', 'invio_framework' );
            }

            /**
             * Popup Elements
             *
             * If this function is defined in a child class the element automatically gets an edit button, that, when pressed
             * opens a modal window that allows to edit the element properties
             *
             * @return void
             */
            function popup_elements()
            {
                $this->elements = array(
                        
                        array(
                            "type"     => "tab_container", 'nodescription' => true
                        ),
                        
                        array(
                            "type"     => "tab",
                            "name"  => __("Content" , 'invio_framework'),
                            'nodescription' => true
                        ),
                        
                        array(
                            "name" => __("Add/Edit Testimonial", 'invio_framework' ),
                            "desc" => __("Here you can add, remove and edit your Testimonials.", 'invio_framework' ),
                            "type"             => "modal_group",
                            "id"             => "content",
                            "modal_title"     => __("Edit Testimonial", 'invio_framework' ),
                            "std"            => array(

                                                    array('name'=>__('Name', 'invio_framework' ), 'Subtitle'=>'', 'check'=>'is_empty'),

                                                    ),


                            'subelements'     => array(

                                    array(
                                    "name"     => __("Image",'invio_framework' ),
                                    "desc"     => __("Either upload a new, or choose an existing image from your media library",'invio_framework' ),
                                    "id"     => "src",
                                    "type"     => "image",
                                    "fetch" => "id",
                                    "title" =>  __("Insert Image",'invio_framework' ),
                                    "button" => __("Insert",'invio_framework' ),
                                    "std"     => ""),

                                    array(
                                    "name"     => __("Name", 'invio_framework' ),
                                    "desc"     => __("Enter the Name of the Person to quote", 'invio_framework' ),
                                    "id"     => "name",
                                    "std"     => "",
                                    "type"     => "input"),

                                    array(
                                    "name"     => __("Subtitle below name", 'invio_framework' ),
                                    "desc"     => __("Can be used for a job description", 'invio_framework' ),
                                    "id"     => "subtitle",
                                    "std"     => "",
                                    "type"     => "input"),

                                    array(
                                    "name"     => __("Quote", 'invio_framework' ),
                                    "desc"     => __("Enter the testimonial here", 'invio_framework' ),
                                    "id"     => "content",
                                    "std"     => "",
                                    "type"     => "tiny_mce"
                                    ),

                                    array(
                                    "name"     => __("Website Link", 'invio_framework' ),
                                    "desc"     => __("Link to the Persons website", 'invio_framework' ),
                                    "id"     => "link",
                                    "std"     => "http://",
                                    "type"     => "input"),

                                    array(
                                    "name"     => __("Website Name", 'invio_framework' ),
                                    "desc"     => __("Linktext for the above Link", 'invio_framework' ),
                                    "id"     => "linktext",
                                    "std"     => "",
                                    "type"     => "input"),

                        )
                    ),


array(
                            "name"     => __("Testimonial Style", 'invio_framework' ),
                            "desc"     => __("Here you can select how to display the testimonials. You can either create a testimonial slider or a testimonial grid with multiple columns", 'invio_framework' ) ,
                            "id"     => "style",
                            "type"     => "select",
                            "std"     => "grid",
                            "subtype" => array(    __('Testimonial Grid', 'invio_framework' ) =>'grid',
                                                __('Testimonial Slider (Compact)', 'invio_framework' ) =>'slider',
                                                __('Testimonial Slider (Large)', 'invio_framework' ) =>'slider_large',
                            )
                        ),


                        array(
                            "name"     => __("Testimonial Grid Columns", 'invio_framework' ),
                            "desc"     => __("How many columns do you want to display", 'invio_framework' ) ,
                            "id"     => "columns",
                            "required"     => array('style', 'equals', 'grid'),
                            "type"     => "select",
                            "std"     => "2",
                            "subtype" => InvioHtmlHelper::number_array(1,4,1)
                            ),

                        array(
                        "name"     => __("Slideshow autorotation duration",'invio_framework' ),
                        "desc"     => __("Slideshow will rotate every X seconds",'invio_framework' ),
                        "id"     => "interval",
                        "type"     => "select",
                        "std"     => "5",
                        "required"     => array('style','contains','slider'),
                        "subtype" => array('3'=>'3','4'=>'4','5'=>'5','6'=>'6','7'=>'7','8'=>'8','9'=>'9','10'=>'10','15'=>'15','20'=>'20','30'=>'30','40'=>'40','60'=>'60','100'=>'100')),
                        
                        array(
                            "type"     => "close_div",
                            'nodescription' => true
                                    ),
                                
                                array(
                                        "type"     => "tab",
                                        "name"    => __("Colors",'invio_framework' ),
                                        'nodescription' => true
                                    ),
                                
                                
                                array(
                                        "name"     => __("Font Colors", 'invio_framework' ),
                                        "desc"     => __("Either use the themes default colors or apply some custom ones", 'invio_framework' ),
                                        "id"     => "font_color",
                                        "type"     => "select",
                                        "std"     => "",
                                        "subtype" => array( __('Default', 'invio_framework' )=>'',
                                                            __('Define Custom Colors', 'invio_framework' )=>'custom'),
                                ),
                                
                                array(    
                                    "name"     => __("Name Font Color", 'invio_framework' ),
                                    "desc"     => __("Select a custom font color. Leave empty to use the default", 'invio_framework' ),
                                    "id"     => "custom_title",
                                    "type"     => "colorpicker",
                                    "std"     => "",
                                    "container_class" => 'invio_half invio_half_first',
                                    "required" => array('font_color','equals','custom')
                                        ),    
                                        
                                    array(    
                                            "name"     => __("Custom Content Font Color", 'invio_framework' ),
                                            "desc"     => __("Select a custom font color. Leave empty to use the default", 'invio_framework' ),
                                            "id"     => "custom_content",
                                            "type"     => "colorpicker",
                                            "std"     => "",
                                            "container_class" => 'invio_half',
                                            "required" => array('font_color','equals','custom')
                                    
                                    ),    
                                    
                                array(
                                        "type"     => "close_div",
                                        'nodescription' => true
                                    ),
                                    
                                array(
                                        "type"     => "close_div",
                                        'nodescription' => true
                                    ),


                );


            }

            /**
             * Editor Sub Element - this function defines the visual appearance of an element that is displayed within a modal window and on click opens its own modal window
             * Works in the same way as Editor Element
             * @param array $params this array holds the default values for $content and $args.
             * @return $params the return array usually holds an innerHtml key that holds item specific markup.
             */
            function editor_sub_element($params)
            {
                $template = $this->update_template("name", __("Testimonial by", 'invio_framework' ). ": {{name}}");

                $params['innerHtml']  = "";
                $params['innerHtml'] .= "<div class='invio_title_container' {$template}>".__("Testimonial by", 'invio_framework' ).": ".$params['args']['name']."</div>";

                return $params;
            }



            /**
             * Frontend Shortcode Handler
             *
             * @param array $atts array of attributes
             * @param string $content text within enclosing form of shortcode element
             * @param string $shortcodename the shortcode found, when == callback name
             * @return string $output returns the modified html string
             */
            function shortcode_handler($atts, $content = "", $shortcodename = "", $meta = "")
            {
                $atts =  shortcode_atts(array(
                    
                    'style'=> "grid",  
                    'columns'=> "2", 
                    "autoplay"=>true, 
                    "interval"=>5,
                    'font_color'=>'', 
                    'custom_title'=>'', 
                    'custom_content'=>'',
                
                
                ), $atts, $this->config['shortcode']);
                
                
                $custom_class = !empty($meta['custom_class']) ? $meta['custom_class'] : "";
                extract($atts);
                
                $this->title_styling         = "";
                $this->content_styling         = "";
                $this->content_class         = "";
                $this->subtitle_class         = "";
                
                if($font_color == "custom")
                {
                    $this->title_styling         .= !empty($custom_title) ? "color:{$custom_title}; " : "";
                    $this->content_styling         .= !empty($custom_content) ? "color:{$custom_content}; " : "";
                    
                    if($this->title_styling)     
                    {
                        $this->title_styling = " style='{$this->title_styling}'" ;
                        $this->subtitle_class = "invio_opacity_variation";    
                    }
                    
                    if($this->content_styling)     
                    {
                        $this->content_class = "invio_inherit_color";
                        $this->content_styling = " style='{$this->content_styling}'" ;
                    }
                }
                
                $output = "";

                switch($columns)
                {
                    case 1: $columnClass = "invio_one_full flex_column no_margin"; break;
                    case 2: $columnClass = "invio_one_half flex_column no_margin"; break;
                    case 3: $columnClass = "invio_one_third flex_column no_margin"; break;
                    case 4: $columnClass = "invio_one_fourth flex_column no_margin"; break;
                }

                $data = InvioHelper::create_data_string(array('autoplay'=>$autoplay, 'interval'=>$interval, 'animation' => 'fade', 'hoverpause' => true));
                $controls = false;
                
                if($style == "slider_large")
                {
                    $style = "slider";
                    $custom_class .= " invio-large-testimonial-slider";
                    $controls = true;
                }
                
                
                $output .= "<div {$data} class='invio-testimonial-wrapper invio-{$style}-testimonials invio-{$style}-{$columns}-testimonials invio_animate_when_almost_visible {$custom_class}'>";

                invio_sc_testimonial::$counter = 1;
                invio_sc_testimonial::$rows = 1;
                invio_sc_testimonial::$columnClass = $columnClass;
                invio_sc_testimonial::$columns = $columns;
                invio_sc_testimonial::$style = $style;

                //if we got a slider we only need a single row wrpper
                if($style != "grid") invio_sc_testimonial::$columns = 100000;

                $output .= ShortcodeHelper::invio_remove_autop($content, true);

                //close unclosed wrapper containers
                if(invio_sc_testimonial::$counter != 1){
                $output .= "</section>";
                }
                
                if($controls)
                {
                    $output .= $this->slide_navigation_arrows();
                }
                
                
                $output .= "</div>";

                return $output;
            }
            
            function slide_navigation_arrows()
            {
                $html  = "";
                $html .= "<div class='invio-slideshow-arrows invio-slideshow-controls' {$this->content_styling}>";
                $html .=     "<a href='#prev' class='prev-slide' ".invio_icon_string('prev_big').">".__('Previous','invio_framework' )."</a>";
                $html .=     "<a href='#next' class='next-slide' ".invio_icon_string('next_big').">".__('Next','invio_framework' )."</a>";
                $html .= "</div>";
    
                return $html;
            }
            

            function invio_testimonial_single($atts, $content = "", $shortcodename = "")
            {
                extract(shortcode_atts(array('src'=> "",  'name'=> "",  'subtitle'=> "",  'link'=> "", 'linktext'=>"", 'custom_markup' =>'' ), $atts, 'invio_testimonial_single'));

                $output = "";
                $avatar = "";
                $grid = invio_sc_testimonial::$style == 'grid' ? true :false;
                $class = invio_sc_testimonial::$columnClass." invio-testimonial-row-".invio_sc_testimonial::$rows." ";
                //if(count($testimonials) <= $rows * $columns) $class.= " invio-testimonial-row-last ";
                if(invio_sc_testimonial::$counter == 1) $class .= "invio-first-testimonial";
                if(invio_sc_testimonial::$counter == invio_sc_testimonial::$columns) $class .= "invio-last-testimonial";
                if($link && !$linktext) $linktext = $link;
                if($link == 'http://') $link = "";
                $linktext = htmlentities($linktext);

                if(invio_sc_testimonial::$counter == 1)
                {
                    $output .= "<section class ='invio-testimonial-row'>";
                }


    //avatar size filter
    $avatar_size = apply_filters('infio_filter_testimonials_avatar_size', 'square', $src, $class);

    //avatar
                $markup = invio_markup_helper(array('context' => 'single_image','echo'=>false, 'custom_markup'=>$custom_markup));
    if($src)    $avatar  = "<div class='invio-testimonial-image' $markup>".wp_get_attachment_image( $src , $avatar_size , false, array('alt'=>esc_attr(strip_tags($name))))."</div>";

    //meta
                $markup_text = invio_markup_helper(array('context' => 'entry','echo'=>false, 'custom_markup'=>$custom_markup));
                $markup_name = invio_markup_helper(array('context' => 'name','echo'=>false, 'custom_markup'=>$custom_markup));
                $markup_job = invio_markup_helper(array('context' => 'job','echo'=>false, 'custom_markup'=>$custom_markup));
                if(strstr($link, '@'))
                {
                    $markup_url = invio_markup_helper(array('context' => 'email','echo'=>false, 'custom_markup'=>$custom_markup));
                }
                else
                {
                    $markup_url = invio_markup_helper(array('context' => 'url','echo'=>false, 'custom_markup'=>$custom_markup));
                }

    //final output
                
                $markup = invio_markup_helper(array('context' => 'person','echo'=>false, 'custom_markup'=>$custom_markup));
                
                $output .= "<div class='invio-testimonial {$class}' $markup>";
                $output .= "<div class='invio-testimonial_inner'>";
    if($grid)   $output .= $avatar;
                $output .=         "<div class='invio-testimonial-content {$this->content_class}'  {$this->content_styling} {$markup_text}>";
                $output .=         ShortcodeHelper::invio_apply_autop(ShortcodeHelper::invio_remove_autop($content));
                $output .=         "</div>";
                $output .=             "<div class='invio-testimonial-meta'><div class='invio-testimonial-arrow-wrap'><div class='invio-arrow'></div></div>";
    if(!$grid)  $output .=  $avatar;
                $output .=                 "<div class='invio-testimonial-meta-mini'>";
    if($name)    $output .=                     "<strong  class='invio-testimonial-name'  {$this->title_styling} {$markup_name}>{$name}</strong>";
if($subtitle)    $output .=                     "<span  class='invio-testimonial-subtitle {$this->subtitle_class}' {$this->title_styling}  {$markup_job}>{$subtitle}</span>";
    if($link)    $output .=                     "<span class='hidden invio-testimonial-markup-link'  {$markup_url}>{$link}</span>";
    if($link)    $output .=                     " &ndash; <a class='invioblank invio-testimonial-link' href='{$link}' >{$linktext}</a>";
                $output .=                 "</div>";
                $output .=             "</div>";
                $output .= "</div>";
                $output .= "</div>";



                if(invio_sc_testimonial::$counter == invio_sc_testimonial::$columns)
                {
                    $output .= "</section>";
                }

                invio_sc_testimonial::$counter++;
                if(invio_sc_testimonial::$counter > invio_sc_testimonial::$columns) { invio_sc_testimonial::$counter = 1; invio_sc_testimonial::$rows++; }


                return $output;
            }

    }
}






