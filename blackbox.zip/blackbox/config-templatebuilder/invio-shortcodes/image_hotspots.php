<?php
/**
 * Textblock
 * Shortcode which creates a text element wrapped in a div
 */

if ( !class_exists( 'invio_sc_image_hotspots' ) )
{
    class invio_sc_image_hotspots extends invioShortcodeTemplate
    {
            /**
             * Create the config array for the shortcode button
             */
            function shortcode_insert_button()
            {
                $this->config['name']            = __('Image with Hotspots', 'invio_framework' );
                $this->config['tab']            = __('Media Elements', 'invio_framework' );
                $this->config['icon']            = InvioBuilder::$path['imagesURL']."sc-image-hotspot.png";
                $this->config['order']            = 95;
                $this->config['target']            = 'invio-target-insert';
                $this->config['shortcode']         = 'invio_image_hotspot';
                $this->config['shortcode_nested'] = array('invio_image_spot');
                $this->config['modal_data']     = array('modal_class' => 'bigscreen');
                $this->config['tooltip']         = __('Inserts an image with one or many hotspots that show tooltips', 'invio_framework' );
            }

            /**
             * Popup Elements
             *
             * If this function is defined in a child class the element automatically gets an edit button, that, when pressed
             * opens a modal window that allows to edit the element properties
             *
             * @return void
             */
            function popup_elements()
            {
                $this->elements = array(
                    
                    array(
                            "name"     => __("Choose Image",'invio_framework' ),
                            "desc"     => __("Either upload a new, or choose an existing image from your media library. Once an Image has been selected you can add your Hotspots",'invio_framework' ),
                            "id"     => "src",
                            "type"     => "image",
                            "container_class" => "invio-hotspot-container",
                            "title" => __("Insert Image",'invio_framework' ),
                            "button" => __("Insert",'invio_framework' ),
                            "std"     => InvioBuilder::$path['imagesURL']."placeholder-full.jpg"),
                    
                    array(
                            "name" => __("Add/Edit your hotspots.", 'invio_framework' ),
                            "desc" => __("Here you can add, remove and edit the map locations for your Google Map.", 'invio_framework' )."<br/>",
                            "type"             => "modal_group",
                            "id"             => "content",
                            "modal_title"     => __("Edit Hotspot Tooltip", 'invio_framework' ),
                            "add_label"        => __("Add Hotspot", 'invio_framework' ),
                            "std"            => array(  ),
                            "special_modal"    => array(
                                "type" => "hotspot",
                                "image_container_class" => "invio-hotspot-container"
                            ),
                            'subelements'     => array(
                                    
                                    array(
                                            "type"     => "tab_container", 'nodescription' => true
                                        ),
                                        
                                    array(
                                            "type"     => "tab",
                                            "name"  => __("Tooltip" , 'invio_framework'),
                                            'nodescription' => true
                                        ),
                                    
                                    array(
                                    "name"     => __("Tooltip Position", 'invio_framework' ),
                                    "desc"     => __("Select where to display the tooltip in relation to the hotspot", 'invio_framework' ),
                                    "id"     => "tooltip_pos",
                                    "type"     => "select",
                                    "std"     => "above",
                                    "container_class" => 'invio_half invio_half_first',
                                    "subtype" => array(
                                                        'Above'=> array(
                                                            __('Top Left',      'invio_framework' ) =>'invio-tt-pos-above invio-tt-align-left',
                                                            __('Top Right',      'invio_framework' ) =>'invio-tt-pos-above invio-tt-align-right',
                                                            __('Top Centered',  'invio_framework' ) =>'invio-tt-pos-above invio-tt-align-centered',
                                                        ),
                                                        'Below'=> array(
                                                            __('Bottom Left',          'invio_framework' ) =>'invio-tt-pos-below invio-tt-align-left',
                                                            __('Bottom Right',      'invio_framework' ) =>'invio-tt-pos-below invio-tt-align-right',
                                                            __('Bottom Centered',     'invio_framework' ) =>'invio-tt-pos-below invio-tt-align-centered',
                                                        ),
                                                        'Left'=> array(
                                                            __('Left Top',      'invio_framework' ) =>'invio-tt-pos-left invio-tt-align-top',
                                                            __('Left Bottom',      'invio_framework' ) =>'invio-tt-pos-left invio-tt-align-bottom',
                                                            __('Left Centered', 'invio_framework' ) =>'invio-tt-pos-left invio-tt-align-centered',
                                                        ),
                                                        'Right'=> array(
                                                            __('Right Top',      'invio_framework' ) =>'invio-tt-pos-right invio-tt-align-top',
                                                            __('Right Bottom',  'invio_framework' ) =>'invio-tt-pos-right invio-tt-align-bottom',
                                                            __('Right Centered','invio_framework' ) =>'invio-tt-pos-right invio-tt-align-centered',
                                                        ),
                                                        
                                                        
                                                        )
                                    ),
                                    
                                    array(
                                    "name"     => __("Tooltip Width", 'invio_framework' ),
                                    "desc"     => __("Select the width of the tooltip. Height is based on the content", 'invio_framework' ),
                                    "id"     => "tooltip_width",
                                    "type"     => "select",
                                    "std"     => "invio-tt-default-width",
                                    "container_class" => 'invio_half',
                                    "subtype" => array(
                                                        __('Default',          'invio_framework' ) =>'invio-tt-default-width',
                                                        __('Large',          'invio_framework' ) =>'invio-tt-large-width',
                                                        __('Extra Large',      'invio_framework' ) =>'invio-tt-xlarge-width',
                                                    ),
                                    ),
                                    
                                    array(    
                                    "name"     => __("Tooltip", 'invio_framework' ),
                                    "desc"     => __("Enter a short descriptive text that appears if the user places his mouse above the hotspot", 'invio_framework' ) ,
                                    "id"     => "content",
                                    "type"     => "tiny_mce",
                                    "std"     => "",
                                    ),
                                    
                                    array(    
                                    "name"     => __("Tooltip Style", 'invio_framework' ),
                                    "desc"     => __("Chose the style of your tooltip", 'invio_framework' ) ,
                                    "id"     => "tooltip_style",
                                    "type"     => "select",
                                    "std"     => "main_color",
                                    "subtype" => array(
                                                        __('Default',  'invio_framework' ) =>'main_color',
                                                        __('Default with drop shadow',  'invio_framework' ) =>'main_color invio-tooltip-shadow',
                                                        __('Transparent Dark',  'invio_framework' ) =>'transparent_dark',
                                                        
                                                        )
                                            ),
                                            
                                            
                                    array(
                                    "name"     => __("Hotspot Link?", 'invio_framework' ),
                                    "desc"     => __("Where should your hotspot link to?", 'invio_framework' ),
                                    "id"     => "link",
                                    "type"     => "linkpicker",
                                    "fetchTMPL"    => true,
                                    "subtype" => array(
                                                        __('No Link', 'invio_framework' ) =>'',
                                                        __('Set Manually', 'invio_framework' ) =>'manually',
                                                        __('Single Entry', 'invio_framework' ) =>'single',
                                                        __('Taxonomy Overview Page',  'invio_framework' )=>'taxonomy',
                                                        ),
                                    "std"     => ""),        
                                    
                                    array(    
                                    "name"     => __("Open Link in new Window?", 'invio_framework' ),
                                    "desc"     => __("Select here if you want to open the linked page in a new window", 'invio_framework' ),
                                    "id"     => "link_target",
                                    "required"     => array('link', 'not', ''),
                                    "type"     => "select",
                                    "std"     => "",
                                    "subtype" => InvioHtmlHelper::linking_options()),
                                    
                                    array(
                                    "type"     => "close_div",
                                            'nodescription' => true
                                        ),
                                    
                                    array(
                                            "type"     => "tab",
                                            "name"    => __("Hotspot Colors",'invio_framework' ),
                                            'nodescription' => true
                                        ),
                                    array(
                                    "name"     => __("Hotspot Color", 'invio_framework' ),
                                    "desc"     => __("Set the colors of your hotspot", 'invio_framework' ),
                                    "id"     => "hotspot_color",
                                    "type"     => "select",
                                    "std"     => "",
                                    "subtype" => array(
                                                        __('Default',          'invio_framework' ) =>'',
                                                        __('Custom',          'invio_framework' ) =>'custom',
                                                    ),
                                    ),
                                    array(    
                                            "name"     => __("Custom Background Color", 'invio_framework' ),
                                            "desc"     => __("Select a custom background color here", 'invio_framework' ),
                                            "id"     => "custom_bg",
                                            "type"     => "colorpicker",
                                            "std"     => "#ffffff",
                                            "required" => array('hotspot_color','equals','custom')
                                        ),    
                                        
                                    array(    
                                            "name"     => __("Custom Font Color", 'invio_framework' ),
                                            "desc"     => __("Select a custom font color here", 'invio_framework' ),
                                            "id"     => "custom_font",
                                            "type"     => "colorpicker",
                                            "std"     => "#888888",
                                            "required" => array('hotspot_color','equals','custom')
                                        ),
                                    
                                    array(    
                                            "name"     => __("Custom Pulse Color", 'invio_framework' ),
                                            "desc"     => __("Select a custom pulse color here", 'invio_framework' ),
                                            "id"     => "custom_pulse",
                                            "type"     => "colorpicker",
                                            "std"     => "#ffffff",
                                            "required" => array('hotspot_color','equals','custom')
                                        ),
                                    
                                    
                                    array(
                                    "id"     => "hotspot_pos",
                                    "std"     => "",
                                    "type"     => "hidden"),
                                    
                                    array(
                                            "type"     => "close_div",
                                            'nodescription' => true
                                        ),
                                        
                                    array(
                                            "type"     => "close_div",
                                            'nodescription' => true
                                        ),
                                    
                                    
                                ),
                        
                        ),

                    array(
                            "name"     => __("Image Fade in Animation", 'invio_framework' ),
                            "desc"     => __("Add a small animation to the image when the user first scrolls to the image position. This is only to add some 'spice' to the site and only works in modern browsers", 'invio_framework' ),
                            "id"     => "animation",
                            "type"     => "select",
                            "std"     => "no-animation",
                            "subtype" => array(
                                                __('None',  'invio_framework' ) =>'no-animation',
                                                __('Simple Fade in',  'invio_framework' ) =>'fade-in',
                                                __('Pop up',  'invio_framework' ) =>'pop-up',
                                                __('Top to Bottom',  'invio_framework' ) =>'top-to-bottom',
                                                __('Bottom to Top',  'invio_framework' ) =>'bottom-to-top',
                                                __('Left to Right',  'invio_framework' ) =>'left-to-right',
                                                __('Right to Left',  'invio_framework' ) =>'right-to-left',
                                                )
                            ),
                            
                    array(
                            "name"     => __("Hotspot Layout", 'invio_framework' ),
                            "desc"     => __("Select the hotspot layout", 'invio_framework' ),
                            "id"     => "hotspot_layout",
                            "type"     => "select",
                            "std"     => "numbered",
                            "subtype" => array(
                                                __('Numbered Hotspot',    'invio_framework' )     =>'numbered',
                                                __('Blank Hotspot',        'invio_framework' )     =>'blank',
                                                )
                            ),
                    
                    array(
                            "name"     => __("Show Tooltips", 'invio_framework' ),
                            "desc"     => __("Select when to display the tooltips", 'invio_framework' ),
                            "id"     => "hotspot_tooltip_display",
                            "type"     => "select",
                            "std"     => "",
                            "subtype" => array(
                                                __('On Mouse Hover', 'invio_framework' ) =>'',
                                                __('Always',         'invio_framework' ) =>'invio-permanent-tooltip',
                                                )
                            ),
                            
                    array(    
                                    "name"     => __("Hotspot on mobile devices", 'invio_framework' ),
                                    "desc"     => __("Check if you always want to show the tooltips on mobile phones below the image. Recommended if your tooltips contain a lot of text", 'invio_framework' ) ,
                                    "id"     => "hotspot_mobile",
                                    "std"     => "true",
                                    "type"     => "checkbox"),
                                    
                                    
                        );
                        
                        
                        
                        
            }

            /**
             * Editor Element - this function defines the visual appearance of an element on the InvioBuilder Canvas
             * Most common usage is to define some markup in the $params['innerHtml'] which is then inserted into the drag and drop container
             * Less often used: $params['data'] to add data attributes, $params['class'] to modify the className
             *
             *
             * @param array $params this array holds the default values for $content and $args.
             * @return $params the return array usually holds an innerHtml key that holds item specific markup.
             */
            function editor_element($params)
            {
                $img = "";
                $template = $this->update_template("src", "<img src='{{src}}' alt=''/>");
                
                if(!empty($params['args']['attachment']) && !empty($params['args']['attachment_size']))
                {
                    $img = wp_get_attachment_image($params['args']['attachment'],$params['args']['attachment_size']);
                }
                else if(isset($params['args']['src']) && is_numeric($params['args']['src']))
                {
                    $img = wp_get_attachment_image($params['args']['src'],'large');
                }
                else if(!empty($params['args']['src']))
                {
                    $img = "<img src='".$params['args']['src']."' alt=''  />";
                }


                $params['innerHtml']  = "<div class='invio_image invio_hotspot_image invio_image_style '>";
                
                $params['innerHtml'] .= "<div class='invio_image_container invio-align-center ' {$template}>{$img}</div>";
                
                $params['innerHtml'].= "<div class='invio-flex-element'>"; 
                
                $params['innerHtml'].=         __('This element will stretch across the whole screen by default.','invio_framework')."<br/>";
                $params['innerHtml'].=         __('If you put it inside a color section or column it will only take up the available space','invio_framework');
                $params['innerHtml'].= "    <div class='invio-flex-element-2nd'>".__('Currently:','invio_framework');
                $params['innerHtml'].= "    <span class='invio-flex-element-stretched'>&laquo; ".__('Stretch fullwidth','invio_framework')." &raquo;</span>";
                $params['innerHtml'].= "    <span class='invio-flex-element-content'>| ".__('Adjust to content width','invio_framework')." |</span>";
                $params['innerHtml'].= "    </div>";
                $params['innerHtml'].= "    <span class='invio_hotspot_image_caption button button-primary button-large'>".__('Image with Hotspots - Click to insert image and hotspots','invio_framework')."</span>";
                
                $params['innerHtml'].= "</div>";
                
                
                
                $params['innerHtml'] .= "</div>";
                $params['class'] = "";

                return $params;
            }
            
            /**
             * Editor Sub Element - this function defines the visual appearance of an element that is displayed within a modal window and on click opens its own modal window
             * Works in the same way as Editor Element
             * @param array $params this array holds the default values for $content and $args. 
             * @return $params the return array usually holds an innerHtml key that holds item specific markup.
             */
            function editor_sub_element($params)
            {
                $params['innerHtml']  = "";
                $params['innerHtml'] .= "<div class='invio_title_container' data-hotspot_pos='".$params['args']['hotspot_pos']."'>".__("Hotspot", 'invio_framework' )." </div>";

                return $params;
            }

            /**
             * Frontend Shortcode Handler
             *
             * @param array $atts array of attributes
             * @param string $content text within enclosing form of shortcode element
             * @param string $shortcodename the shortcode found, when == callback name
             * @return string $output returns the modified html string
             */
            function shortcode_handler($atts, $content = "", $shortcodename = "", $meta = "")
            {    
                $output     = "";
                $class      = "";
                $alt         = "";
                $title         = "";
                $src           = "";
                $markup     = invio_markup_helper(array('context' => 'image','echo'=>false, 'custom_markup'=>$meta['custom_markup']));
                $markup_url = invio_markup_helper(array('context' => 'image_url','echo'=>false, 'custom_markup'=>$meta['custom_markup']));
                $hotspots     = ShortcodeHelper::shortcode2array($content, 1);
                
                extract(shortcode_atts(array('animation'=>'no-animation', 'attachment'=>'', 'attachment_size' =>'', 'hotspot_layout'=>'numbered', 'hotspot_mobile'=>'', 'hotspot_tooltip_display' => ''), $atts, $this->config['shortcode']));
                
                if(!empty($attachment))
                {
                    $attachment_entry = get_post( $attachment );
                    
                    if(!empty($attachment_entry))
                    {
                        $alt = get_post_meta($attachment_entry->ID, '_wp_attachment_image_alt', true);
                        $alt = !empty($alt) ? esc_attr($alt) : '';
                        $title = trim($attachment_entry->post_title) ? esc_attr($attachment_entry->post_title) : "";
                        
                        if(!empty($attachment_size))
                        {
                            $src = wp_get_attachment_image_src($attachment_entry->ID, $attachment_size);
                            $src = !empty($src[0]) ? $src[0] : "";
                        }
                    }
                }
                
                
                //no src? return
                if(!empty($src))
                {
                    if(!ShortcodeHelper::is_top_level()) $meta['el_class'] .= " invio-non-fullwidth-hotspot-image";
                    
                    $hotspot_html     = "";
                    $tooltip_html     = "";
                    $counter         = 1;
                    
                    foreach($hotspots as $hotspot)
                    { 
                        if(!empty($hotspot_mobile)) $tooltip_html .= $this->add_fallback_tooltip($hotspot, $counter);
                        $extraClass  = !empty($hotspot_mobile) ? " invio-mobile-fallback-active " : "";
                        $extraClass .= !empty($hotspot_tooltip_display) ? " {$hotspot_tooltip_display}-single " : "";
                        
                        $hotspot_html .= $this->add_hotspot($hotspot, $counter, $extraClass);
                        $counter ++; 
                    }
                    
                    //some custom classes
                    $class .= $animation == "no-animation" ? "" :" invio_animated_image invio_animate_when_almost_visible ".$animation;
                    $class .= " invio-hotspot-".$hotspot_layout;
                    $class .= !empty($hotspot_mobile) ? " invio-mobile-fallback-active " : "";
                    $class .= " ".$hotspot_tooltip_display;
                    
                    
                    $output .= "<div class='invio-hotspot-image-container invio_animate_when_almost_visible {$class} ".$meta['el_class']." ' $markup >";
                    $output .=         "<div class='invio-hotspot-container'>";
                    $output .=             "<div class='invio-hotspot-container-inner-cell'>";
                    $output .=                 "<div class='invio-hotspot-container-inner-wrap'>";
                    $output .=                     $hotspot_html;
                    $output .=                     "<img class='invio_image ' src='{$src}' alt='{$alt}' title='{$title}'  $markup_url />";
                    $output .=                 "</div>";
                    $output .=             "</div>";
                    $output .=         "</div>";
                    $output .=        $tooltip_html;
                    $output .= "</div>";                
                }
                
                
                
                
                if(!ShortcodeHelper::is_top_level()) return $output;
                
                $skipSecond = false;
                $params['class'] = "main_color invio-fullwidth-hotspots ".$meta['el_class'];
                $params['open_structure'] = false;
                $params['id'] = !empty($atts['id']) ? InvioHelper::save_string($atts['id'],'-') : "";
                $params['custom_markup'] = $meta['custom_markup'];
                
                //we dont need a closing structure if the element is the first one or if a previous fullwidth element was displayed before
                if($meta['index'] == 0) $params['close'] = false;
                if(!empty($meta['siblings']['prev']['tag']) && in_array($meta['siblings']['prev']['tag'], InvioBuilder::$full_el_no_section )) $params['close'] = false;
                
                $image = $output;
                
                $output  =  invio_new_section($params);
                $output .= $image;
                $output .= "</div>"; //close section
                
                
                //if the next tag is a section dont create a new section from this shortcode
                if(!empty($meta['siblings']['next']['tag']) && in_array($meta['siblings']['next']['tag'], InvioBuilder::$full_el ))
                {
                    $skipSecond = true;
                }

                //if there is no next element dont create a new section.
                if(empty($meta['siblings']['next']['tag']))
                {
                    $skipSecond = true;
                }
                
                if(empty($skipSecond)) {
                
                $output .= invio_new_section(array('close'=>false, 'id' => "after_image_hotspots"));
                
                }
                
                return $output;
            }
            
            function add_hotspot($hotspot, $counter, $extraClass = "")
            {
                extract(shortcode_atts(array('tooltip_width' => 'invio-tt-default-width', 'tooltip_pos'=>'invio-tt-pos-above invio-tt-align-left', 'hotspot_pos'=>'50,50', 'output'=>'', 'hotspot_color'=>'', 'custom_bg'=>'', 'custom_font'=>'', 'custom_pulse'=>'', 'tooltip_style'=>'main_color', 'link' => '', 'link_target'=>''), $hotspot['attr']));
                $content = ShortcodeHelper::invio_remove_autop($hotspot['content']);
                
                $tags = array('div', 'div');
                if(!empty($link)) 
                {
                    $blank  = strpos($link_target, '_blank') !== false ? ' target="_blank" ' : "";
                    $blank .= strpos($link_target, 'nofollow') !== false ? ' rel="nofollow" ' : "";
                    
                    $link = invioHelper::get_url($link, false);
                    $tags = array("a href={$link} {$blank}", 'a');
                }
                
                if(empty($hotspot_pos)) $hotspot_pos = '50,50';
                
                $layout         = explode(' ', $tooltip_pos);
                $hotspot_pos     = explode(',', $hotspot_pos);
                $top             = $hotspot_pos[0];
                $left            = $hotspot_pos[1];
                $position        = $layout[0];
                $align            = isset($layout[1]) ? str_replace('invio-tt-align-', '', $layout[1]) : "centered";
                $pos_string     = "top: {$top}%; left: {$left}%; ";
                $data_pos        = "";
                
                if(strpos($position, 'above') !== false) $data_pos     = "top";
                if(strpos($position, 'below') !== false) $data_pos     = "bottom";
                if(strpos($position, 'left') !== false) $data_pos     = "left";
                if(strpos($position, 'right') !== false) $data_pos     = "right";
                
                
                if($hotspot_color == "custom")
                {
                    if($custom_bg) $custom_bg = "background-color: {$custom_bg};";
                    if($custom_font) $custom_font = "color: {$custom_font};";
                    if($custom_pulse) $custom_pulse = "style='background-color:{$custom_pulse};'";
                }
                else
                {
                    $custom_bg = $custom_font = $custom_pulse = "";
                }
                
                
                $output .= "<div class='invio-image-hotspot' data-invio-tooltip-position='{$data_pos}' data-invio-tooltip-alignment='{$align}' data-invio-tooltip-class='{$tooltip_width} {$tooltip_pos} {$extraClass} {$tooltip_style} invio-tt-hotspot' data-invio-tooltip='".esc_attr(ShortcodeHelper::invio_apply_autop($content))."' style='{$pos_string}'>";
                $output .= "<".$tags[0]." class='invio-image-hotspot_inner' style='{$custom_bg} {$custom_font}'>{$counter}</".$tags[1].">";
                $output .= "<div class='invio-image-hotspot-pulse' {$custom_pulse}></div>";
                $output .= "</div>";
                
                
                return $output;
            }
            
            function add_fallback_tooltip($hotspot, $counter)
            {
                $content = $hotspot['content'];
                
                if(empty($content)) return;
                
                $output  = "";
                $output .= "<div class='invio-hotspot-fallback-tooltip'>";
                $output .= "<div class='invio-hotspot-fallback-tooltip-count'>";
                $output .= $counter;
                $output .= "<div class='invio-arrow'></div></div>";
                $output .= "<div class='invio-hotspot-fallback-tooltip-inner clearfix'>";
                $output .= ShortcodeHelper::invio_apply_autop($content);
                $output .= "</div>";
                $output .= "</div>";
                
                return $output;
            }


    }
}








