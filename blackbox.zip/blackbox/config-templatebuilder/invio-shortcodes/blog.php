<?php
/**
 * Sidebar
 * Displays one of the registered Widget Areas of the theme
 */

if ( !class_exists( 'invio_sc_blog' ) )
{
    class invio_sc_blog extends invioShortcodeTemplate
    {
            /**
             * Create the config array for the shortcode button
             */
            function shortcode_insert_button()
            {
                $this->config['name']        = __('Blog Posts', 'invio_framework' );
                $this->config['tab']        = __('Content Elements', 'invio_framework' );
                $this->config['icon']        = InvioBuilder::$path['imagesURL']."sc-blog.png";
                $this->config['order']        = 40;
                $this->config['target']        = 'invio-target-insert';
                $this->config['shortcode']     = 'invio_blog';
                $this->config['tooltip']     = __('Displays Posts from your Blog', 'invio_framework' );
            }

            /**
             * Popup Elements
             *
             * If this function is defined in a child class the element automatically gets an edit button, that, when pressed
             * opens a modal window that allows to edit the element properties
             *
             * @return void
             */
            function popup_elements()
            {
                $this->elements = array(

                    array(    "name"         => __("Do you want to display blog posts?", 'invio_framework' ),
                        "desc"         => __("Do you want to display blog posts or entries from a custom taxonomy?", 'invio_framework' ),
                        "id"         => "blog_type",
                        "type"         => "select",
                        "std"     => "posts",
                        "subtype" => array( __('Display blog posts', 'invio_framework') =>'posts',
                                            __('Display entries from a custom taxonomy', 'invio_framework') =>'taxonomy')),
                                            
                                            

                    array(    "name"         => __("Which categories should be used for the blog?", 'invio_framework' ),
                            "desc"         => __("You can select multiple categories here. The Page will then show posts from only those categories.", 'invio_framework' ),
                            "id"         => "categories",
                            "type"         => "select",
                            "multiple"    => 6,
                            "required"     => array('blog_type', 'equals', 'posts'),
                            "subtype"     => "cat"),

                    array(
                        "name"     => __("Which Entries?", 'invio_framework' ),
                        "desc"     => __("Select which entries should be displayed by selecting a taxonomy", 'invio_framework' ),
                        "id"     => "link",
                        "fetchTMPL"    => true,
                        "type"     => "linkpicker",
                        "subtype"  => array( __('Display Entries from:',  'invio_framework' )=>'taxonomy'),
                        "multiple"    => 6,
                        "required"     => array('blog_type', 'equals', 'taxonomy'),
                        "std"     => "category"
                    ),

                    array(
                            "name"     => __("Blog Style", 'invio_framework' ),
                            "desc"     => __("Choose the default blog layout here.", 'invio_framework' ),
                            "id"     => "blog_style",
                            "type"     => "select",
                            "std"     => "single-big",
                            "no_first"=>true,
                            "subtype" => array( __('Multi Author Blog (displays Gravatar of the article author beside the entry and feature images above)', 'invio_framework') =>'multi-big',
                                                __('Single Author, small preview Pic (no author picture is displayed, feature image is small)', 'invio_framework') =>'single-small',
                                                __('Single Author, big preview Pic (no author picture is displayed, feature image is big)', 'invio_framework') =>'single-big',
                                                __('Grid Layout', 'invio_framework') =>'blog-grid',
                                                /* 'no sidebar'=>'fullsize' */
                                        )),
                                        
                    array(
                            "name"     => __("Blog Grid Columns", 'invio_framework' ),
                            "desc"     => __("How many columns do you want to display?", 'invio_framework' ),
                            "id"     => "columns",
                            "type"     => "select",
                            "std"     => "3",
                            "required"     => array('blog_style', 'equals', 'blog-grid'),
                            "subtype" => InvioHtmlHelper::number_array(1,5,1)),

                    array(
                            "name"     => __("Define Blog Grid layout", 'invio_framework' ),
                            "desc"     => __("Do you want to display a read more link?", 'invio_framework' ),
                            "id"     => "contents",
                            "type"     => "select",
                            "std"     => "excerpt",
                            "required"     => array('blog_style', 'equals', 'blog-grid'),
                            "subtype" =>   array(
                                    __('Title and Excerpt',  'invio_framework' ) =>'excerpt',
                                    __('Title and Excerpt + Read More Link',  'invio_framework' ) =>'excerpt_read_more',
                                    __('Only Title',  'invio_framework' ) =>'title',
                                    __('Only Title + Read More Link',  'invio_framework' ) =>'title_read_more',
                                    __('Only excerpt',  'invio_framework' ) =>'only_excerpt',
                                    __('Only excerpt + Read More Link',  'invio_framework' ) =>'only_excerpt_read_more',
                                    __('No Title and no excerpt',  'invio_framework' ) =>'no')
                            ),


                    array(
                            "name"     => __("Blog Content length", 'invio_framework' ),
                            "desc"     => __("Should the full entry be displayed or just a small excerpt?", 'invio_framework' ),
                            "id"     => "content_length",
                            "type"     => "select",
                            "std"     => "content",
                            "required"     => array('blog_style', 'not', 'blog-grid'),
                            "subtype" => array(
                                __('Full Content',  'invio_framework' ) =>'content',
                                __('Excerpt',  'invio_framework' ) =>'excerpt',
                                __('Excerpt With Read More Link',  'invio_framework' ) =>'excerpt_read_more')),

                    array(
                            "name"     => __("Preview Image Size", 'invio_framework' ),
                            "desc"     => __("Set the image size of the preview images", 'invio_framework' ),
                            "id"     => "preview_mode",
                            "type"     => "select",
                            "std"     => "auto",
                            "subtype" => array(__('Set the preview image size automatically based on column or layout width','invio_framework' ) =>'auto',__('Choose the preview image size manually (select thumbnail size)','invio_framework' ) =>'custom')),

                    array(
                            "name"     => __("Select custom preview image size", 'invio_framework' ),
                            "desc"     => __("Choose image size for Preview Image", 'invio_framework' ),
                            "id"     => "image_size",
                            "type"     => "select",
                            "required"     => array('preview_mode','equals','custom'),
                            "std"     => "portfolio",
                            "subtype" =>  InvioHelper::get_registered_image_sizes(array('logo'))
                            ),


                    array(
                            "name"     => __("Post Number", 'invio_framework' ),
                            "desc"     => __("How many items should be displayed per page?", 'invio_framework' ),
                            "id"     => "items",
                            "type"     => "select",
                            "std"     => "3",
                            "subtype" => InvioHtmlHelper::number_array(1,100,1, array('All'=>'-1'))),

                    array(
                        "name"     => __("Offset Number", 'invio_framework' ),
                        "desc"     => __("The offset determines where the query begins pulling posts. Useful if you want to remove a certain number of posts because you already query them with another blog or magazine element.", 'invio_framework' ),
                        "id"     => "offset",
                        "type"     => "select",
                        "std"     => "0",
                        "subtype" => InvioHtmlHelper::number_array(1,100,1, array(__('Deactivate offset','invio_framework')=>'0', __('Do not allow duplicate posts on the entire page (set offset automatically)', 'invio_framework' ) =>'no_duplicates'))),


                    array(
                            "name"     => __("Pagination", 'invio_framework' ),
                            "desc"     => __("Should a pagination be displayed?", 'invio_framework' ),
                            "id"     => "paginate",
                            "type"     => "select",
                            "std"     => "yes",
                            "subtype" => array(
                                __('yes',  'invio_framework' ) =>'yes',
                                __('no',  'invio_framework' ) =>'no')),
                                
                                
                    array(
                            "name"     => __("Conditional display", 'invio_framework' ),
                            "desc"     => __("When should the element be displayed?", 'invio_framework' ),
                            "id"     => "conditional",
                            "type"     => "select",
                            "std"     => "yes",
                            "subtype" => array(
                                __('Always display the element',  'invio_framework' ) =>'',
                                __('Remove element if the user navigated away from page 1 to page 2,3,4 etc ',  'invio_framework' ) =>'is_subpage')),

                );
                
                
                


                if(current_theme_supports('add_invio_builder_post_type_option'))
                {
                    $element = array(
                        "name"     => __("Select Post Type", 'invio_framework' ),
                        "desc"     => __("Select which post types should be used. Note that your taxonomy will be ignored if you do not select an assign post type.
                                      If yo don't select post type all registered post types will be used", 'invio_framework' ),
                        "id"     => "post_type",
                        "type"     => "select",
                        "required"     => array('blog_type', 'equals', 'taxonomy'),
                        "multiple"    => 6,
                        "std"     => "",
                        "subtype" => InvioHtmlHelper::get_registered_post_type_array()
                    );

                    array_splice($this->elements, 2, 0, array($element));
                }

            }



            /**
             * Editor Element - this function defines the visual appearance of an element on the InvioBuilder Canvas
             * Most common usage is to define some markup in the $params['innerHtml'] which is then inserted into the drag and drop container
             * Less often used: $params['data'] to add data attributes, $params['class'] to modify the className
             *
             *
             * @param array $params this array holds the default values for $content and $args.
             * @return $params the return array usually holds an innerHtml key that holds item specific markup.
             */
            function editor_element($params)
            {
                $params['innerHtml'] = "<img src='".$this->config['icon']."' title='".$this->config['name']."' />";
                $params['innerHtml'].= "<div class='invio-element-label'>".$this->config['name']."</div>";
                $params['content']      = NULL; //remove to allow content elements

                return $params;
            }



            /**
             * Frontend Shortcode Handler
             *
             * @param array $atts array of attributes
             * @param string $content text within enclosing form of shortcode element
             * @param string $shortcodename the shortcode found, when == callback name
             * @return string $output returns the modified html string
             */
            function shortcode_handler($atts, $content = "", $shortcodename = "", $meta = "")
            {
                global $invio_config, $more;

                if(empty($atts['categories'])) $atts['categories'] = "";
                if(isset($atts['link']) && isset($atts['blog_type']) && $atts['blog_type'] == 'taxonomy')
                {
                    $atts['link'] = explode(',', $atts['link'], 2 );
                    $atts['taxonomy'] = $atts['link'][0];

                    if(!empty($atts['link'][1]))
                    {
                        $atts['categories'] = $atts['link'][1];
                    }
                    else if(!empty($atts['taxonomy']))
                    {
                        $taxonomy_terms_obj = get_terms($atts['taxonomy']);
                        foreach ($taxonomy_terms_obj as $taxonomy_term)
                        {
                            $atts['categories'] .= $taxonomy_term->term_id . ',';
                        }
                    }
                }

                $atts = shortcode_atts(array('blog_style'    => '',
                                             'columns'         => 3,
                                             'blog_type'    => 'posts',
                                             'items'         => '16',
                                             'paginate'     => 'yes',
                                             'categories'     => '',
                                             'preview_mode' => 'auto',
                                             'image_size' => 'portfolio',
                                             'taxonomy'        => 'category',
                                             'post_type'=> get_post_types(),
                                             'contents'     => 'excerpt',
                                             'content_length' => 'content',
                                             'offset' => '0',
                                             'conditional' => ''
                                             ), $atts, $this->config['shortcode']);
                
                $page = get_query_var( 'paged' ) ? get_query_var( 'paged' ) : get_query_var( 'page' );
                if(!$page) $page = 1;
                
                if($atts['blog_style'] == "blog-grid")
                {
                    $atts['class'] = $meta['el_class'];
                    $atts['type']  = 'grid';

                    //using the post slider with inactive js will result in displaying a nice post grid
                    $slider = new invio_post_slider($atts);
                    $slider->query_entries();
                    
                    if($atts['conditional'] && $page != 1) 
                    {
                        return;
                    }
                    else
                    {
                        return $slider->html();
                    }
                }

                $this->query_entries($atts);

                $invio_config['blog_style'] = $atts['blog_style'];
                $invio_config['preview_mode'] = $atts['preview_mode'];
                $invio_config['image_size'] = $atts['image_size'];
                $invio_config['blog_content'] = $atts['content_length'];
                $invio_config['remove_pagination'] = $atts['paginate'] === "yes" ? false :true;

                $more = 0;
                ob_start(); //start buffering the output instead of echoing it
                get_template_part( 'includes/loop', 'index' );
                $output = ob_get_clean();
                wp_reset_query();
                invio_set_layout_array();

                if($output)
                {
                    $extraclass = function_exists('invio_blog_class_string') ? invio_blog_class_string() : "";
                    $markup = invio_markup_helper(array('context' => 'blog','echo'=>false, 'custom_markup'=>$meta['custom_markup']));
                    $output = "<div class='template-blog {$extraclass}' {$markup}>{$output}</div>";
                }

                if($atts['conditional'] && $page != 1) 
                {
                    return;
                }
                else
                {
                    return $output;
                }
            }


            function query_entries($params)
            {
                global $invio_config;
                $query = array();

                if(!empty($params['categories']) && is_string($params['categories']))
                {
                    //get the categories
                    $terms     = explode(',', $params['categories']);
                }

                $page = get_query_var( 'paged' ) ? get_query_var( 'paged' ) : get_query_var( 'page' );
                if(!$page || $params['paginate'] == 'no') $page = 1;

                if($params['offset'] == 'no_duplicates')
                {
                    $params['offset'] = 0;
                    $no_duplicates = true;
                }

                if(empty($params['blog_type']) || $params['blog_type'] == 'posts') $params['post_type'] = 'post';
                if(empty($params['post_type'])) $params['post_type'] = get_post_types();
                if(is_string($params['post_type'])) $params['post_type'] = explode(',', $params['post_type']);
                
                //wordpress 4.4 offset fix
                if( $params['offset'] == 0 )
                {
                    $params['offset'] = false;
                }
                else
                {    
                    //if the offset is set the paged param is ignored. therefore we need to factor in the page number
                    $params['offset'] = $params['offset'] + ( ($page -1 ) * $params['items']);
                }
        
                //if we find categories perform complex query, otherwise simple one
                if(isset($terms[0]) && !empty($terms[0]) && !is_null($terms[0]) && $terms[0] != "null" && !empty($params['taxonomy']))
                {
                    $query = array(    'paged'     => $page,
                                    'posts_per_page' => $params['items'],
                                    'offset' => $params['offset'],
                                    'post__not_in' => (!empty($no_duplicates)) ? $invio_config['posts_on_current_page'] : array(),
                                    'post_type' => $params['post_type'],
                                    'tax_query' => array(     array(     'taxonomy'     => $params['taxonomy'],
                                                                    'field'     => 'id',
                                                                    'terms'     => $terms,
                                                                    'operator'     => 'IN'))
                                                                    );
                }
                else
                {
                    $query = array(    'paged'=> $page,
                                    'posts_per_page' => $params['items'],
                                    'offset' => $params['offset'],
                                    'post__not_in' => (!empty($no_duplicates)) ? $invio_config['posts_on_current_page'] : array(),
                                    'post_type' => $params['post_type']);
                }

                $query = apply_filters('invio_blog_post_query', $query, $params);

                $results = query_posts($query);

                // store the queried post ids in
                if( have_posts() )
                {
                    while( have_posts() )
                    {
                        the_post();
                        $invio_config['posts_on_current_page'][] = get_the_ID();
                    }
                }
            }




    }
}