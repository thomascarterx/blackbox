<?php
/**
 * DROPCAPS
 * Shortcode which creates dropcaps
 */
 
 // Don't load directly
if ( !defined('ABSPATH') ) { die('-1'); }



if ( !class_exists( 'invio_dropcap1' ) ) 
{
    class invio_dropcap1 extends invioShortcodeTemplate{
            
            /**
             * Create the config array for the shortcode button
             */
            function shortcode_insert_button()
            {
                $this->config['name']        = 'Dropcap 1 (Big Letter)';
                $this->config['order']        = 100;
                $this->config['shortcode']     = 'invio_dropcap1';
                $this->config['inline']     = true;
                $this->config['html_renderer']     = false;
                $this->config['tinyMCE']     = array('tiny_only'=>true, 'instantInsert' => "[invio_dropcap1]H[/invio_dropcap1]ello");
                
            }
            
            /**
             * Frontend Shortcode Handler
             *
             * @param array $atts array of attributes
             * @param string $content text within enclosing form of shortcode element 
             * @param string $shortcodename the shortcode found, when == callback name
             * @return string $output returns the modified html string 
             */
            function shortcode_handler($atts, $content = "", $shortcodename = "", $meta = "")
            {
                //this is a fix that solves the false paragraph removal by wordpress if the dropcaps shortcode is used at the beginning of the content of single posts/pages
                global $post, $invio_add_p;

                $atts =  shortcode_atts(array('color' => '','custom_bg' => '#444444'), $atts, $this->config['shortcode']);
                
                $add_p = "";
                $custom_class = !empty($meta['custom_class']) ? $meta['custom_class'] : "";
                if(isset($post->post_content) && strpos($post->post_content, '[dropcap') === 0 && $invio_add_p == false && is_singular())
                {
                    $add_p = "<p>";
                    $invio_add_p = true;
                }

                if(!empty($atts['color']))
                {
                    $color = ($atts['color'] == 'custom' && !empty($atts['custom_bg'])) ? $atts['custom_bg'] : $atts['color'];
                }

                $style = !empty($color) ? 'style="background-color:'.$color.'"' : '';
                
                //this is the actual shortcode
                $output  = $add_p.'<span class="'.$shortcodename." ".$custom_class.'" '.$style.'>';
                $output .= $content;
                $output .= '</span>';    
                
            
                return $output;
            }
    }
}


if ( !class_exists( 'invio_dropcap2' ) ) 
{
    class invio_dropcap2 extends invio_dropcap1{
            
            /**
             * Create the config array for the shortcode button
             */
            function shortcode_insert_button()
            {
                $this->config['name']        = 'Dropcap 2 (Colored Background)';
                $this->config['order']        = 90;
                $this->config['shortcode']     = 'invio_dropcap2';
                $this->config['html_renderer']     = false;
                $this->config['inline']     = true;
                $this->config['tinyMCE']     = array('tiny_only'=>true, 'templateInsert'=>'[invio_dropcap2 color="{{color}}" custom_bg="{{custom_bg}}"]H[/invio_dropcap2]ello');
                //$this->config['modal_data'] = array('modal_class' => 'smallscreen');
            }
            
            /**
             * Popup Elements
             *
             * If this function is defined in a child class the element automatically gets an edit button, that, when pressed
             * opens a modal window that allows to edit the element properties
             *
             * @return void
             */
            function popup_elements()
            {
                $this->elements = array(
                    
                    array(    
                            "name"     => __("Dropcap Styling", 'invio_framework' ),
                            "desc"     => __("Here you can set the background color of your Dropcap", 'invio_framework' ),
                            "id"     => "color",
                            "type"     => "select",
                            "std"     => "default",
                            "subtype" => array(    __('Theme Color', 'invio_framework' ) =>'default',
                                                __('Custom Color', 'invio_framework') => 'custom',
                                                __('Blue', 'invio_framework' )=>'blue',
                                                __('Red',  'invio_framework' )=>'red',
                                                __('Green', 'invio_framework' )=>'green',
                                                __('Orange', 'invio_framework' )=>'orange',
                                                __('Aqua', 'invio_framework' )=>'aqua',
                                                __('Teal', 'invio_framework' )=>'teal',
                                                __('Purple', 'invio_framework' )=>'purple',
                                                __('Pink', 'invio_framework' )=>'pink',
                                                __('Silver', 'invio_framework' )=>'silver',
                                                __('Grey', 'invio_framework' )=>'grey',
                                                __('Black', 'invio_framework' )=>'black',
                                                )),

                    array(    
                            "name"     => __("Custom Background Color", 'invio_framework' ),
                            "desc"     => __("Select a custom background color for your dropcap here", 'invio_framework' ),
                            "id"     => "custom_bg",
                            "type"     => "colorpicker",
                            "std"     => "#444444",
                            "required" => array('color','equals','custom')
                        ),

                );

            }
    }
}



