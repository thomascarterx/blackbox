<?php
/**
 * Slider
 * Shortcode that allows to display a simple slideshow
 */

if ( !class_exists( 'invio_sc_submenu' ) ) 
{
    class invio_sc_submenu extends invioShortcodeTemplate
    {
            static $count = 0;
            static $custom_items = 0;
    
            /**
             * Create the config array for the shortcode button
             */
            function shortcode_insert_button()
            {
                $this->config['name']            = __('Fullwidth Sub Menu', 'invio_framework' );
                $this->config['tab']            = __('Content Elements', 'invio_framework' );
                $this->config['icon']            = InvioBuilder::$path['imagesURL']."sc-submenu.png";
                $this->config['order']            = 30;
                $this->config['target']            = 'invio-target-insert';
                $this->config['shortcode']         = 'invio_submenu';
                $this->config['shortcode_nested'] = array('invio_submenu_item');
                $this->config['tooltip']         = __('Display a sub menu', 'invio_framework' );
                $this->config['tinyMCE']         = array('disable' => "true");
                $this->config['drag-level']     = 1;
            }

            /**
             * Popup Elements
             *
             * If this function is defined in a child class the element automatically gets an edit button, that, when pressed
             * opens a modal window that allows to edit the element properties
             *
             * @return void
             */
            function popup_elements()
            {
                global $invio_config;
                
                $menus = array();
                if(!empty($_POST) && !empty($_POST['action']) && $_POST['action'] == "invio_ajax_invio_submenu")
                {
                    $menus = InvioHelper::list_menus();
                }
                
                $this->elements = array(
                    
                    array(    
                        "name"     => __("Which kind of menu do you want to display",'invio_framework' ),
                        "name"     => __("Either use an existing menu, built in Appearance -> Menus or create a simple custom menu here",'invio_framework' ),
                        "id"     => "which_menu",
                        "type"     => "select",
                        "std"     => "center",
                        "subtype" => array(   __('Use existing menu','invio_framework' ) =>'',
                                              __('Build simple custom menu','invio_framework' ) =>'custom',
                                              )
                    ),
                    
                    
                    array(    
                            "name"     => __("Select menu to display", 'invio_framework' ),
                            "desc"     => __("You can create new menus in ", 'invio_framework' )."<a target='_blank' href='".admin_url('nav-menus.php?action=edit&menu=0')."'>".__('Appearance -> Menus', 'invio_framework' )."</a><br/>".__("Please note that Mega Menus are not supported for this element ", 'invio_framework' ),
                            "id"     => "menu",
                            "type"     => "select",
                            "std"     => "",
                            "required"     => array('which_menu', 'not', 'custom'),
                            "subtype" =>  $menus        
                            ),
                            
                    array(
                            "name" => __("Add/Edit rotating text", 'invio_framework' ),
                            "desc" => __("Here you can add, remove and edit the rotating text", 'invio_framework' ),
                            "type"             => "modal_group",
                            "id"             => "content",
                            "required"         => array('which_menu', 'equals', 'custom'),
                            "modal_title"     => __("Edit Text Element", 'invio_framework' ),
                            "std"            => array(

                                                    array('title'=>__('Menu Item 1', 'invio_framework' )),
                                                    array('title'=>__('Menu Item 2', 'invio_framework' )),

                                                    ),


                            'subelements'     => array(

                                    array(
                                    "name"     => __("Menu Text", 'invio_framework' ),
                                    "desc"     => __("Enter the menu text here", 'invio_framework' ) ,
                                    "id"     => "title",
                                    "std"     => "",
                                    "type"     => "input"),


                                array(
                                    "name"     => __("Text Link?", 'invio_framework' ),
                                    "desc"     => __("Apply  a link to the menu text?", 'invio_framework' ),
                                    "id"     => "link",
                                    "type"     => "linkpicker",
                                    "fetchTMPL"    => true,
                                    "std"    => "",
                                    "subtype" => array(
                                        __('Set Manually', 'invio_framework' ) =>'manually',
                                        __('Single Entry', 'invio_framework' ) =>'single',
                                        __('Taxonomy Overview Page',  'invio_framework' )=>'taxonomy',
                                    ),
                                    ),

                                array(
                                    "name"     => __("Open in new window", 'invio_framework' ),
                                    "desc"     => __("Do you want to open the link in a new window", 'invio_framework' ),
                                    "id"     => "linktarget",
                                    "required"     => array('link', 'not', ''),
                                    "type"     => "select",
                                    "std"     => "no",
                                    "subtype" => InvioHtmlHelper::linking_options()),
                                    
                                array(
                                    "name"     => __("Style", 'invio_framework' ),
                                    "desc"     => __("Select the styling of your menu item", 'invio_framework' ),
                                    "id"     => "button_style",
                                    "type"     => "select",
                                    "std"     => "",
                                    "subtype" => array(
                                        __('Default Style', 'invio_framework' )     =>'',
                                        __('Button Style (Colored)', 'invio_framework' )     =>'invio-menu-button invio-menu-button-colored',
                                        __('Button Style (Bordered)',  'invio_framework' )    =>'invio-menu-button invio-menu-button-bordered',
                                    ),
                            
                            ),),    


                        
                    ),
                    
                    array(    
                        "name"     => __("Menu Position",'invio_framework' ),
                        "name"     => __("Aligns the menu either to the left, the right or centers it",'invio_framework' ),
                        "id"     => "position",
                        "type"     => "select",
                        "std"     => "center",
                        "subtype" => array(   __('Left','invio_framework' )       =>'left',
                                              __('Center','invio_framework' )     =>'center',
                                              __('Right','invio_framework' )      =>'right', 
                                              )
                    ),
                    
                     array(
                        "name"     => __("Menu Colors",'invio_framework' ),
                        "id"     => "color",
                        "desc"  => __("The menu will use the color scheme you select. Color schemes are defined on your styling page",'invio_framework' ) .
                                   '<br/><a target="_blank" href="'.admin_url('admin.php?page=invio#goto_styling').'">'.__("(Show Styling Page)",'invio_framework' )."</a>",
                        "type"     => "select",
                        "std"     => "main_color",
                        "subtype" =>  array_flip($invio_config['color_sets'])
                    ),
                    
                    array(    
                        "name"     => __("Sticky Submenu", 'invio_framework' ),
                        "desc"     => __("If checked the menu will stick at the top of the page once it touches it", 'invio_framework' ) ,
                        "id"     => "sticky",
                        "std"     => "true",
                        "type"     => "checkbox"),
                        
                       array(    
                        "name"     => __("Mobile Menu Display",'invio_framework' ),
                        "desc"     => __("How do you want to display the menu on mobile devices",'invio_framework' ),
                        "id"     => "mobile",
                        "type"     => "select",
                        "std"     => "disabled",
                        "subtype" => array(   __('Display full menu (works best if you only got a few menu items)','invio_framework' )                   =>'disabled',
                                              __('Display a button to open menu (works best for menus with a lot of menu items)','invio_framework' )     =>'active',
                                              )
                    ),
                    
                    array(    
                        "name"     => __("Hide Mobile Menu Submenu Items", 'invio_framework'),
                        "desc"     => __("By default all menu items of the mobile menu are visible. If you activate this option they will be hidden and a user needs to click on the parent menu item to display the submenus", 'invio_framework'),
                        "id"     => "mobile_submenu",
                        "required"     => array('mobile', 'equals', 'active'),
                        "type"     => "checkbox",
                        "std"     => ""
                    ),
                        
                    
                );

            }
            
            
            /**
             * Editor Sub Element - this function defines the visual appearance of an element that is displayed within a modal window and on click opens its own modal window
             * Works in the same way as Editor Element
             * @param array $params this array holds the default values for $content and $args.
             * @return $params the return array usually holds an innerHtml key that holds item specific markup.
             */
            function editor_sub_element($params)
            {
                $template = $this->update_template("title", "{{title}}");

                $params['innerHtml']  = "";
                $params['innerHtml'] .= "<div class='invio_title_container'>";
                $params['innerHtml'] .= "<span {$template} >".$params['args']['title']."</span></div>";

                return $params;
            }
            
            
            /**
             * Editor Element - this function defines the visual appearance of an element on the InvioBuilder Canvas
             * Most common usage is to define some markup in the $params['innerHtml'] which is then inserted into the drag and drop container
             * Less often used: $params['data'] to add data attributes, $params['class'] to modify the className
             *
             *
             * @param array $params this array holds the default values for $content and $args. 
             * @return $params the return array usually holds an innerHtml key that holds item specific markup.
             */
            function editor_element($params)
            {    
                $menus = get_terms( 'nav_menu', array( 'hide_empty' => false ) );
            
                $params['innerHtml'] = "<img src='".$this->config['icon']."' title='".$this->config['name']."' />";
                $params['innerHtml'].= "<div class='invio-element-label'>".$this->config['name']."</div>";
                return $params;
            }
            
            
            
            
            /**
             * Frontend Shortcode Handler
             *
             * @param array $atts array of attributes
             * @param string $content text within enclosing form of shortcode element 
             * @param string $shortcodename the shortcode found, when == callback name
             * @return string $output returns the modified html string 
             */
            function shortcode_handler($atts, $content = "", $shortcodename = "", $meta = "")
            {
                $atts = shortcode_atts(array(
                'style'            => '',
                'menu'            => '',
                'position'         => 'center',
                'sticky'        => '',
                'color'            => 'main_color',
                'mobile'        => 'disabled',
                'mobile_submenu'=> '',
                'which_menu'    => ''
                
                ), $atts, $this->config['shortcode']);
                
                extract($atts);
                $output      = "";
                $sticky_div = "";
                invio_sc_submenu::$count++;
                invio_sc_submenu::$custom_items = 0;
                
                
                $params['class'] = "invio-submenu-container {$color} ".$meta['el_class'];
                $params['open_structure'] = false; 
                $params['id'] = "sub_menu".invio_sc_submenu::$count;
                $params['custom_markup'] = $meta['custom_markup'];
                $params['style'] = "style='z-index:".(invio_sc_submenu::$count + 300)."'";
                
                if($sticky && $sticky != "disabled") 
                {
                    $params['class'] .= " invio-sticky-submenu";
                    $params['before_new'] = "<div class='clear'></div>";
                    $sticky_div = "<div class='sticky_placeholder'></div>";
                }
                
                //we dont need a closing structure if the element is the first one or if a previous fullwidth element was displayed before
                if(isset($meta['index']) && $meta['index'] == 0) $params['close'] = false;
                if(!empty($meta['siblings']['prev']['tag']) && in_array($meta['siblings']['prev']['tag'], InvioBuilder::$full_el_no_section )) $params['close'] = false;
                
                if(isset($meta['index']) && $meta['index'] != 0) $params['class'] .= " submenu-not-first";
                
                
                if($which_menu == "custom")
                {
                    $element = "";
                    $custom_menu = ShortcodeHelper::invio_remove_autop( $content, true );
                    if(!empty($custom_menu))
                    {
                        $element .= "<ul id='invio-custom-submenu-".invio_sc_submenu::$count."' class='invio-subnav-menu invio-submenu-pos-{$position}'>";
                        $element .= $custom_menu;
                        $element .= "</ul>";
                    }
                }
                else
                {
                    $element = wp_nav_menu(
                        array(
                            'menu'             => wp_get_nav_menu_object( $menu ),
                            'menu_class'     =>"invio-subnav-menu invio-submenu-pos-{$position}",
                            'fallback_cb'     => '',
                            'container'        =>false,
                            'echo'             =>false,
                            'walker'         => new invio_responsive_mega_menu(array('megamenu'=>'disabled'))
                        )
                    );
                }
                
                
                $submenu_hidden = ""; 
                $mobile_button = $mobile == "active" ? "<a href='#' class='mobile_menu_toggle' ".invio_icon_string('mobile_menu')."><span class='invio-current-placeholder'>".__('Menu', 'invio_framework')."</span></a>" : "";
                if(!empty($mobile_button) && !empty($mobile_submenu) && $mobile_submenu != "disabled")
                {
                    $submenu_hidden = "invio-submenu-hidden";
                }
                
                // if(!ShortcodeHelper::is_top_level()) return $element;
                $output .=  invio_new_section($params);
                $output .= "<div class='container invio-menu-mobile-{$mobile} {$submenu_hidden}'>{$mobile_button}".$element."</div>";
                $output .= invio_section_after_element_content( $meta , 'after_submenu', false, $sticky_div);
                return $output;

            }
            
            function invio_submenu_item($atts, $content = "", $shortcodename = "", $meta = "")
            {
                $output = "";
                $atts = shortcode_atts(
                array(    
                    'title'         => '',
                    'link'             => '',
                    'linktarget'     => '',
                    'button_style'     => '',
                ), 
                $atts, 'invio_rotator_item');
                
                extract($atts);
                
                if(!empty($title))
                {
                    invio_sc_submenu::$custom_items++;
                    $link = InvioHelper::get_url($link);
                    $blank = (strpos($linktarget, '_blank') !== false || $linktarget == 'yes') ? ' target="_blank" ' : "";
                    $blank .= strpos($linktarget, 'nofollow') !== false ? ' rel="nofollow" ' : "";
                    
                    $output .= "<li class='menu-item menu-item-top-level {$button_style} menu-item-top-level-".invio_sc_submenu::$custom_items."'>";
                    $output .= "<a href='{$link}' {$blank}><span class='invio-bullet'></span>";
                    $output .= "<span class='invio-menu-text'>".$title."</span>";
                    //$output .= "<span class='invio-menu-fx'><span class='invio-arrow-wrap'><span class='invio-arrow'></span></span></span>";
                    $output .= "</a>";
                    $output .= "</li>";
                    
                    
                }
                
                return $output;
                
            }
            
    }
}



