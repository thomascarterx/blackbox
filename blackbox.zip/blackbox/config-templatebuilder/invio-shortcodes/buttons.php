<?php
/**
 * Button
 * Displays a button that links to any url of your choice
 */
 
if ( !class_exists( 'invio_sc_button' ) ) 
{
    class invio_sc_button extends invioShortcodeTemplate
    {
            /**
             * Create the config array for the shortcode button
             */
            function shortcode_insert_button()
            {
                $this->config['name']        = __('Button', 'invio_framework' );
                $this->config['tab']        = __('Content Elements', 'invio_framework' );
                $this->config['icon']        = InvioBuilder::$path['imagesURL']."sc-button.png";
                $this->config['order']        = 85;
                $this->config['target']        = 'invio-target-insert';
                $this->config['shortcode']     = 'invio_button';
                $this->config['tooltip']     = __('Creates a colored button', 'invio_framework' );
                $this->config['tinyMCE']    = array('tiny_always'=>true);
            }
        
            /**
             * Popup Elements
             *
             * If this function is defined in a child class the element automatically gets an edit button, that, when pressed
             * opens a modal window that allows to edit the element properties
             *
             * @return void
             */
            function popup_elements()
            {
                $this->elements = array(
                    
                    array(
                            "type"     => "tab_container", 'nodescription' => true
                        ),
                        
                    array(
                            "type"     => "tab",
                            "name"  => __("Content" , 'invio_framework'),
                            'nodescription' => true
                        ),
                    
                    array(    "name"     => __("Button Label", 'invio_framework' ),
                            "desc"     => __("This is the text that appears on your button.", 'invio_framework' ),
                            "id"     => "label",
                            "type"     => "input",
                            "std" => __("Click me", 'invio_framework' )),
                    array(    
                            "name"     => __("Button Link?", 'invio_framework' ),
                            "desc"     => __("Where should your button link to?", 'invio_framework' ),
                            "id"     => "link",
                            "type"     => "linkpicker",
                            "fetchTMPL"    => true,
                            "subtype" => array(    
                                                __('Set Manually', 'invio_framework' ) =>'manually',
                                                __('Single Entry', 'invio_framework' ) =>'single',
                                                __('Taxonomy Overview Page',  'invio_framework' )=>'taxonomy',
                                                ),
                            "std"     => ""),
                            
                    array(    
                            "name"     => __("Open Link in new Window?", 'invio_framework' ),
                            "desc"     => __("Select here if you want to open the linked page in a new window", 'invio_framework' ),
                            "id"     => "link_target",
                            "type"     => "select",
                            "std"     => "",
                            "subtype" => InvioHtmlHelper::linking_options()),    
                                                                
                        
                    array(    
                            "name"     => __("Button Size", 'invio_framework' ),
                            "desc"     => __("Choose the size of your button here", 'invio_framework' ),
                            "id"     => "size",
                            "type"     => "select",
                            "std"     => "small",
                            "subtype" => array(
                                __('Small',   'invio_framework' ) =>'small',
                                __('Medium',  'invio_framework' ) =>'medium',
                                __('Large',   'invio_framework' ) =>'large',
                                __('X Large',   'invio_framework' ) =>'x-large',
                            )),
                            
                    array(    
                            "name"     => __("Button Position", 'invio_framework' ),
                            "desc"     => __("Choose the alignment of your button here", 'invio_framework' ),
                            "id"     => "position",
                            "type"     => "select",
                            "std"     => "center",
                            "subtype" => array(
                                __('Align Left',   'invio_framework' ) =>'left',
                                __('Align Center',  'invio_framework' ) =>'center',
                                __('Align Right',   'invio_framework' ) =>'right',
                            )),        
                    array(    
                            "name"     => __("Button Icon", 'invio_framework' ),
                            "desc"     => __("Should an icon be displayed at the left side of the button", 'invio_framework' ),
                            "id"     => "icon_select",
                            "type"     => "select",
                            "std"     => "yes",
                            "subtype" => array(
                                __('No Icon',  'invio_framework' ) =>'no',
                                __('Yes, display Icon to the left',  'invio_framework' ) => 'yes' ,    
                                __('Yes, display Icon to the right',  'invio_framework' ) =>'yes-right-icon',
                                )),
                    array(    
                            "name"     => __("Icon Visibility",'invio_framework' ),
                            "desc"     => __("Check to only display icon on hover",'invio_framework' ),
                            "id"     => "icon_hover",
                            "type"     => "checkbox",
                            "std"     => "",
                            "required" => array('icon_select','not_empty_and','no')
                            ),
                    array(    
                            "name"     => __("Button Icon",'invio_framework' ),
                            "desc"     => __("Select an icon for your Button below",'invio_framework' ),
                            "id"     => "icon",
                            "type"     => "iconfont",
                            "std"     => "",
                            "required" => array('icon_select','not_empty_and','no')
                            ),
                    array(
                            "type"     => "close_div",
                            'nodescription' => true
                        ),
                    
                    array(
                            "type"     => "tab",
                            "name"    => __("Colors",'invio_framework' ),
                            'nodescription' => true
                        ),
                    
                    array(    
                            "name"     => __("Button Color", 'invio_framework' ),
                            "desc"     => __("Choose a color for your button here", 'invio_framework' ),
                            "id"     => "color",
                            "type"     => "select",
                            "std"     => "theme-color",
                            "subtype" => array(    
                                                __('Translucent Buttons', 'invio_framework' ) => array(
                                                    __('Light Transparent', 'invio_framework' )=>'light',
                                                    __('Dark Transparent', 'invio_framework' )=>'dark',
                                                ),
                                                        
                                                __('Colored Buttons', 'invio_framework' ) => array(
                                                __('Theme Color', 'invio_framework' )=>'theme-color',
                                                __('Theme Color Subtle', 'invio_framework' )=>'theme-color-subtle',
                                                __('Blue', 'invio_framework' )=>'blue',
                                                __('Red',  'invio_framework' )=>'red',
                                                __('Green', 'invio_framework' )=>'green',
                                                __('Orange', 'invio_framework' )=>'orange',
                                                __('Aqua', 'invio_framework' )=>'aqua',
                                                __('Teal', 'invio_framework' )=>'teal',
                                                __('Purple', 'invio_framework' )=>'purple',
                                                __('Pink', 'invio_framework' )=>'pink',
                                                __('Silver', 'invio_framework' )=>'silver',
                                                __('Grey', 'invio_framework' )=>'grey',
                                                __('Black', 'invio_framework' )=>'black',
                                                __('Custom Color', 'invio_framework' )=>'custom',
                                                )),
                                ),

                            
                    array(    
                            "name"     => __("Custom Background Color", 'invio_framework' ),
                            "desc"     => __("Select a custom background color for your Button here", 'invio_framework' ),
                            "id"     => "custom_bg",
                            "type"     => "colorpicker",
                            "std"     => "#444444",
                            "required" => array('color','equals','custom')
                        ),    
                        
                    array(    
                            "name"     => __("Custom Font Color", 'invio_framework' ),
                            "desc"     => __("Select a custom font color for your Button here", 'invio_framework' ),
                            "id"     => "custom_font",
                            "type"     => "colorpicker",
                            "std"     => "#ffffff",
                            "required" => array('color','equals','custom')
                        ),    
                                            
                    array(
                            "type"     => "close_div",
                            'nodescription' => true
                        ),
                        
                    array(
                            "type"     => "close_div",
                            'nodescription' => true
                        ),
                        
                );

            }
            
            
            
            /**
             * Editor Element - this function defines the visual appearance of an element on the InvioBuilder Canvas
             * Most common usage is to define some markup in the $params['innerHtml'] which is then inserted into the drag and drop container
             * Less often used: $params['data'] to add data attributes, $params['class'] to modify the className
             *
             *
             * @param array $params this array holds the default values for $content and $args. 
             * @return $params the return array usually holds an innerHtml key that holds item specific markup.
             */
            function editor_element($params)
            {
                extract(invio_backend_icon($params)); // creates $font and $display_char if the icon was passed as param "icon" and the font as "font" 
                
                $inner  = "<div class='invio_button_box invio_hidden_bg_box invio_textblock invio_textblock_style'>";
                $inner .= "        <div ".$this->class_by_arguments('icon_select, color, size, position' ,$params['args']).">";
                $inner .= "            <span ".$this->class_by_arguments('font' ,$font).">";
                $inner .= "            <span data-update_with='icon_fakeArg' class='invio_button_icon invio_button_icon_left'>".$display_char."</span>";
                $inner .= "            </span>";
                $inner .= "            <span data-update_with='label' class='invio_iconbox_title' >".$params['args']['label']."</span>";
                $inner .= "            <span ".$this->class_by_arguments('font' ,$font).">";
                $inner .= "            <span data-update_with='icon_fakeArg' class='invio_button_icon invio_button_icon_right'>".$display_char."</span>";
                $inner .= "            </span>";
                $inner .= "        </div>";
                $inner .= "</div>";
                
                $params['innerHtml'] = $inner;
                $params['content'] = NULL;
                $params['class'] = "";
                
                return $params;
            }
            
            
            
            /**
             * Frontend Shortcode Handler
             *
             * @param array $atts array of attributes
             * @param string $content text within enclosing form of shortcode element 
             * @param string $shortcodename the shortcode found, when == callback name
             * @return string $output returns the modified html string 
             */
            function shortcode_handler($atts, $content = "", $shortcodename = "", $meta = "")
            {
            
               $atts =  shortcode_atts(array('label' => 'Click me', 
                                             'link' => '', 
                                             'link_target' => '',
                                             'color' => 'theme-color',
                                             'custom_bg' => '#444444',
                                             'custom_font' => '#ffffff',
                                             'size' => 'small',
                                             'position' => 'center',
                                             'icon_select' => 'yes',
                                             'icon' => '', 
                                             'font' =>'',
                                             'icon_hover' => '',
                                             ), $atts, $this->config['shortcode']);
            
                $display_char     = invio_icon($atts['icon'], $atts['font']);
                $extraClass     = $atts['icon_hover'] ? "invio-icon-on-hover" : "";
                
                if($atts['icon_select'] == "yes") $atts['icon_select'] = "yes-left-icon";
                
                $style = "";
                if($atts['color'] == "custom") 
                {
                    $style .= "style='background-color:".$atts['custom_bg']."; border-color:".$atts['custom_bg']."; color:".$atts['custom_font']."; '";
                }

                
                $blank = strpos($atts['link_target'], '_blank') !== false ? ' target="_blank" ' : "";
                $blank .= strpos($atts['link_target'], 'nofollow') !== false ? ' rel="nofollow" ' : "";

                $link  = InvioHelper::get_url($atts['link']);
                $link  = ( ( $link == "http://" ) || ( $link == "manually" ) ) ? "" : $link;
                
                $content_html = "";
                if('yes-left-icon' == $atts['icon_select']) $content_html .= "<span class='invio_button_icon invio_button_icon_left ' {$display_char}></span>";
                $content_html .= "<span class='invio_iconbox_title' >".$atts['label']."</span>";
                if('yes-right-icon' == $atts['icon_select']) $content_html .= "<span class='invio_button_icon invio_button_icon_right' {$display_char}></span>";
                
                $output  = "";
                $output .= "<a href='{$link}' class='invio-button {$extraClass} ".$this->class_by_arguments('icon_select, color, size, position' , $atts, true)."' {$blank} {$style} >";
                $output .= $content_html;
                $output .= "</a>";
                
                $output =  "<div class='invio-button-wrap invio-button-".$atts['position']." ".$meta['el_class']."'>".$output."</div>";
                
                return $output;
            }
            
            
            
    
    }
}
