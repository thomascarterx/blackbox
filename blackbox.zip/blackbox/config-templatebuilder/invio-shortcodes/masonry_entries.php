<?php
/**
 * Masonry
 * Shortcode that allows to display a fullwidth masonry of any post type
 */

if ( !class_exists( 'invio_sc_masonry_entries' ) ) 
{
    class invio_sc_masonry_entries extends invioShortcodeTemplate
    {    
            /**
             * Create the config array for the shortcode button
             */
            function shortcode_insert_button()
            {
                $this->config['name']            = __('Masonry', 'invio_framework' );
                $this->config['tab']            = __('Content Elements', 'invio_framework' );
                $this->config['icon']            = InvioBuilder::$path['imagesURL']."sc-masonry.png";
                $this->config['order']            = 38;
                $this->config['target']            = 'invio-target-insert';
                $this->config['shortcode']         = 'invio_masonry_entries';
                $this->config['tooltip']         = __('Display a fullwidth masonry/grid with blog entries', 'invio_framework' );
                $this->config['drag-level']     = 3;
            }
            
            
            function extra_assets()
            {
                add_action('wp_ajax_invio_ajax_masonry_more', array('invio_masonry','load_more'));
                add_action('wp_ajax_nopriv_invio_ajax_masonry_more', array('invio_masonry','load_more'));
                
                if(!is_admin() && !current_theme_supports('invio_no_session_support') && !session_id()) session_start();
            }
            

            /**
             * Popup Elements
             *
             * If this function is defined in a child class the element automatically gets an edit button, that, when pressed
             * opens a modal window that allows to edit the element properties
             *
             * @return void
             */
            function popup_elements()
            {
                $this->elements = array(

                array(
                            "type"     => "tab_container", 'nodescription' => true
                        ),
                        
                array(
                        "type"     => "tab",
                        "name"  => __("Masonry Content" , 'invio_framework'),
                        'nodescription' => true
                    ),
                    
                    
                   array(
                        "name"     => __("Which Entries?", 'invio_framework' ),
                        "desc"     => __("Select which entries should be displayed by selecting a taxonomy", 'invio_framework' ),
                        "id"     => "link",
                        "fetchTMPL"    => true,
                        "type"     => "linkpicker",
                        "subtype"  => array( __('Display Entries from:',  'invio_framework' )=>'taxonomy'),
                        "multiple"    => 6,
                        "std"     => "category"
                ),
                
                array(
                        "name"     => __("Sortable?", 'invio_framework' ),
                        "desc"     => __("Should sorting options based on the taxonomies above be displayed?", 'invio_framework' ),
                        "id"     => "sort",
                        "type"     => "select",
                        "std"     => "yes",
                        "subtype" => array(
                            __('Yes, display sort options',  'invio_framework' ) => 'yes',
                            __('Yes, display sort options and currently active taxonomy',  'invio_framework' ) => 'yes-tax',
                            __('No, do not display sort options',  'invio_framework' )  => 'no')),
                
                array(
                    "name"     => __("Post Number", 'invio_framework' ),
                    "desc"     => __("How many items should be displayed per page?", 'invio_framework' ),
                    "id"     => "items",
                    "type"     => "select",
                    "std"     => "12",
                    "subtype" => InvioHtmlHelper::number_array(1,100,1, array('All'=>'-1'))),
                
                array(
                    "name"     => __("Columns", 'invio_framework' ),
                    "desc"     => __("How many columns do you want to display?", 'invio_framework' ),
                    "id"     => "columns",
                    "type"     => "select",
                    "std"     => "flexible",
                    "subtype" => array(
                        __('Automatic, based on screen width',  'invio_framework' ) =>'flexible',
                        __('2 Columns',  'invio_framework' ) =>'2',
                        __('3 Columns',  'invio_framework' ) =>'3',
                        __('4 Columns',  'invio_framework' ) =>'4',
                        __('5 Columns',  'invio_framework' ) =>'5',
                        __('6 Columns',  'invio_framework' ) =>'6',
                        
                        )),
                
                
                
                array(
                    "name"     => __("Pagination", 'invio_framework' ),
                    "desc"     => __("Should a pagination or load more option be displayed to view additional entries?", 'invio_framework' ),
                    "id"     => "paginate",
                    "type"     => "select",
                    "std"     => "yes",
                    "required" => array('items','not','-1'),
                    "subtype" => array(
                        __('Display Pagination',  'invio_framework' ) =>'pagination',
                        __('Display "Load More" Button',  'invio_framework' ) =>'load_more',
                        __('No option to view additional entries',  'invio_framework' ) =>'none')),
                
                array(
                            "name" => __("Order by",'invio_framework' ),
                            "desc"     => __("You can order the result by various attributes like creation date, title, author etc", 'invio_framework' ),
                            "id"   => "query_orderby",
                            "type"     => "select",
                            "std"     => "date",
                            "subtype" => array(
                                __('Date',  'invio_framework' ) =>'date',
                                __('Title',  'invio_framework' ) =>'title',
                                __('Random',  'invio_framework' ) =>'rand',
                                __('Author',  'invio_framework' ) =>'author',
                                __('Name (Post Slug)',  'invio_framework' ) =>'name',
                                __('Last modified',  'invio_framework' ) =>'modified',
                                __('Comment Count',  'invio_framework' ) =>'comment_count',
                                __('Page Order',  'invio_framework' ) =>'menu_order')
                        ),
                        
                  array(
                    "name" => __("Display order",'invio_framework' ),
                    "desc"     => __("Display the results either in ascending or descending order", 'invio_framework' ),
                    "id"   => "query_order",
                    "type"     => "select",
                    "std"     => "DESC",
                    "subtype" => array(
                        __('Ascending Order',  'invio_framework' ) =>'ASC',
                        __('Descending Order',  'invio_framework' ) =>'DESC')
                  ),
                          
                              
                array(
                    "name"     => __("Size Settings", 'invio_framework' ),
                    "desc"     => __("Here you can select how the masonry should behave and handle all entries and the feature images of those entries", 'invio_framework' ),
                    "id"     => "size",
                    "type"     => "radio",
                    "std"     => "fixed masonry",
                    "options" => array(
                        'flex' => __('Flexible Masonry: All entries get the same width but Images of each entry are displayed with their original height and width ratio',  'invio_framework' ),
                        'fixed' => __('Perfect Grid: Display a perfect grid where each element has exactly the same size. Images get cropped/stretched if they don\'t fit',  'invio_framework' ),
                        'fixed masonry' => __('Perfect Automatic Masonry: Display a grid where most elements get the same size, only elements with very wide images get twice the width and elements with very high images get twice the height. To qualify for "very wide" or "very high" the image must have a aspect ratio of 16:9 or higher',  'invio_framework' ),
                        'fixed manually' => __('Perfect Manual Masonry: Manually control the height and width of entries by adding either a "landscape" or "portrait" tag when creating the entry. Elements with no such tag use a fixed default size, elements with both tags will display extra large',  'invio_framework' ),
                    )),
                    
                    
                array(
                    "name"     => __("Gap between elements", 'invio_framework' ),
                    "desc"     => __("Select the gap between the elements", 'invio_framework' ),
                    "id"     => "gap",
                    "type"     => "select",
                    "std"     => "1px",
                    "subtype" => array(
                        __('No Gap',  'invio_framework' ) =>'no',
                        __('1 Pixel Gap',  'invio_framework' ) =>'1px',
                        __('Large Gap',  'invio_framework' ) =>'large',
                    )),
                
                
                
                array(
                    "name"     => __("Image overlay effect", 'invio_framework' ),
                    "desc"     => __("Do you want to display the image overlay?", 'invio_framework' ),
                    "id"     => "overlay_fx",
                    "type"     => "select",
                    "std"     => "active",
                    "subtype" => array(
                        __('Overlay activated',  'invio_framework' ) =>'active',
                        __('Overlay deactivated',  'invio_framework' ) =>'',
                    )),
                
                array(    "name"     => __("For Developers: Section ID", 'invio_framework' ),
                        "desc"     => __("Apply a custom ID Attribute to the section, so you can apply a unique style via CSS. This option is also helpful if you want to use anchor links to scroll to a sections when a link is clicked", 'invio_framework' )."<br/><br/>".
                                   __("Use with caution and make sure to only use allowed characters. No special characters can be used.", 'invio_framework' ),
                        "id"     => "id",
                        "type"     => "input",
                        "std" => ""),
                
                array(
                            "type"     => "close_div",
                            'nodescription' => true
                        ),
                    
                    array(
                            "type"     => "tab",
                            "name"    => __("Element captions",'invio_framework' ),
                            'nodescription' => true
                        ),    
                
                array(
                    "name"     => __("Element Title and Excerpt", 'invio_framework' ),
                    "desc"     => __("You can choose if you want to display title and/or excerpt", 'invio_framework' ),
                    "id"     => "caption_elements",
                    "type"     => "select",
                    "std"     => "title excerpt",
                    "subtype" => array(
                        __('Display Title and Excerpt',  'invio_framework' ) =>'title excerpt',
                        __('Display Title',  'invio_framework' ) =>'title',
                        __('Display Excerpt',  'invio_framework' ) =>'excerpt',
                        __('Display Neither',  'invio_framework' ) =>'none',
                    )),    
                
                
                array(
                    "name"     => __("Element Title and Excerpt Styling", 'invio_framework' ),
                    "desc"     => __("You can choose the styling for the title and excerpt here", 'invio_framework' ),
                    "id"     => "caption_styling",
                    "type"     => "select",
                    "std"     => "always",
                    "required" => array('caption_elements','not','none'),
                    "subtype" => array(
                        __('Default display (at the bottom of the elements image)',  'invio_framework' ) =>'',
                        __('Display as centered overlay (overlays the image)',  'invio_framework' ) =>'overlay',
                    )),    
                
                
                    
                array(
                    "name"     => __("Element Title and Excerpt display settings", 'invio_framework' ),
                    "desc"     => __("You can choose whether to always display Title and Excerpt or only on hover", 'invio_framework' ),
                    "id"     => "caption_display",
                    "type"     => "select",
                    "std"     => "always",
                    "required" => array('caption_elements','not','none'),
                    "subtype" => array(
                        __('Always Display',  'invio_framework' ) =>'always',
                        __('Display on mouse hover',  'invio_framework' ) =>'on-hover',
                        __('Hide on mouse hover',  'invio_framework' ) =>'on-hover-hide',
                    )),    
                    
                    
                 
                 array(
                            "type"     => "close_div",
                            'nodescription' => true
                        ),
                        
                array(
                        "type"     => "tab",
                        "name"  => __("Element Colors" , 'invio_framework'),
                        'nodescription' => true
                    ),
                    
                array(
                            "name"     => __("Custom Colors", 'invio_framework' ),
                            "desc"     => __("Either use the themes default colors or apply some custom ones", 'invio_framework' ),
                            "id"     => "color",
                            "type"     => "select",
                            "std"     => "",
                            "subtype" => array( __('Default', 'invio_framework' )=>'',
                                                __('Define Custom Colors', 'invio_framework' )=>'custom'),
                                                
                    ),
                    
                    array(    
                            "name"     => __("Custom Background Color", 'invio_framework' ),
                            "desc"     => __("Select a custom background color. Leave empty to use the default", 'invio_framework' ),
                            "id"     => "custom_bg",
                            "type"     => "colorpicker",
                            "std"     => "",
                            //"container_class" => 'invio_third invio_third_first',
                            "required" => array('color','equals','custom')
                        ),    
                        
                
                array(
                        "type"     => "close_div",
                        'nodescription' => true
                    ),
                
                        
                array(
                            "type"     => "close_div",
                            'nodescription' => true
                        ),
                    
                );


                if(current_theme_supports('add_invio_builder_post_type_option'))
                {
                    $element = array(
                        "name"     => __("Select Post Type", 'invio_framework' ),
                        "desc"     => __("Select which post types should be used. Note that your taxonomy will be ignored if you do not select an assign post type.
                                      If yo don't select post type all registered post types will be used", 'invio_framework' ),
                        "id"     => "post_type",
                        "type"     => "select",
                        "multiple"    => 6,
                        "std"     => "",
                        "subtype" => InvioHtmlHelper::get_registered_post_type_array()
                    );

                    array_unshift($this->elements, $element);
                }

            }
            
            /**
             * Editor Element - this function defines the visual appearance of an element on the InvioBuilder Canvas
             * Most common usage is to define some markup in the $params['innerHtml'] which is then inserted into the drag and drop container
             * Less often used: $params['data'] to add data attributes, $params['class'] to modify the className
             *
             *
             * @param array $params this array holds the default values for $content and $args. 
             * @return $params the return array usually holds an innerHtml key that holds item specific markup.
             */
            function editor_element($params)
            {    
                $params['innerHtml'] = "<img src='".$this->config['icon']."' title='".$this->config['name']."' />";
                $params['innerHtml'].= "<div class='invio-element-label'>".$this->config['name']."</div>";
                
                $params['innerHtml'].= "<div class='invio-flex-element'>"; 
                $params['innerHtml'].=         __('This element will stretch across the whole screen by default.','invio_framework')."<br/>";
                $params['innerHtml'].=         __('If you put it inside a color section or column it will only take up the available space','invio_framework');
                $params['innerHtml'].= "    <div class='invio-flex-element-2nd'>".__('Currently:','invio_framework');
                $params['innerHtml'].= "    <span class='invio-flex-element-stretched'>&laquo; ".__('Stretch fullwidth','invio_framework')." &raquo;</span>";
                $params['innerHtml'].= "    <span class='invio-flex-element-content'>| ".__('Adjust to content width','invio_framework')." |</span>";
                $params['innerHtml'].= "</div></div>";
                
                return $params;
            }
            
            /**
             * Editor Sub Element - this function defines the visual appearance of an element that is displayed within a modal window and on click opens its own modal window
             * Works in the same way as Editor Element
             * @param array $params this array holds the default values for $content and $args. 
             * @return $params the return array usually holds an innerHtml key that holds item specific markup.
             */
            function editor_sub_element($params)
            {    
                $img_template         = $this->update_template("img_fakeArg", "{{img_fakeArg}}");
                $template             = $this->update_template("title", "{{title}}");
                $content             = $this->update_template("content", "{{content}}");
                
                $thumbnail = isset($params['args']['id']) ? wp_get_attachment_image($params['args']['id']) : "";
                
        
                $params['innerHtml']  = "";
                $params['innerHtml'] .= "<div class='invio_title_container'>";
                $params['innerHtml'] .= "    <span class='invio_slideshow_image' {$img_template} >{$thumbnail}</span>";
                $params['innerHtml'] .= "    <div class='invio_slideshow_content'>";
                $params['innerHtml'] .= "        <h4 class='invio_title_container_inner' {$template} >".$params['args']['title']."</h4>";
                $params['innerHtml'] .= "        <p class='invio_content_container' {$content}>".stripslashes($params['content'])."</p>";
                $params['innerHtml'] .= "    </div>";
                $params['innerHtml'] .= "</div>";
                
                
                
                return $params;
            }
            
            
            
            /**
             * Frontend Shortcode Handler
             *
             * @param array $atts array of attributes
             * @param string $content text within enclosing form of shortcode element 
             * @param string $shortcodename the shortcode found, when == callback name
             * @return string $output returns the modified html string 
             */
            
            function shortcode_handler($atts, $content = "", $shortcodename = "", $meta = "")
            {
                $output  = "";
                
                $params['class'] = "main_color ".$meta['el_class'];
                $params['open_structure'] = false;
                $params['id'] = !empty($atts['id']) ? InvioHelper::save_string($atts['id'],'-') : "";
                $params['custom_markup'] = $meta['custom_markup'];
                if( ($atts['gap'] == 'no' && $atts['sort'] == "no") || $meta['index'] == 0) $params['class'] .= " invio-no-border-styling";
                
                //we dont need a closing structure if the element is the first one or if a previous fullwidth element was displayed before
                if($meta['index'] == 0) $params['close'] = false;
                if(!empty($meta['siblings']['prev']['tag']) && in_array($meta['siblings']['prev']['tag'], InvioBuilder::$full_el_no_section )) $params['close'] = false;
                
                if($meta['index'] != 0) $params['class'] .= " masonry-not-first";
                if($meta['index'] == 0 && get_post_meta(get_the_ID(), 'header', true) != "no") $params['class'] .= " masonry-not-first";
                
                $masonry  = new invio_masonry($atts);
                $masonry->extract_terms();
                $masonry->query_entries();
                $masonry_html = $masonry->html();
                

                if(!ShortcodeHelper::is_top_level()) return $masonry_html;
                
                
                if( !empty( $atts['color'] ) && !empty( $atts['custom_bg']) )
                {
                    $params['class'] .= " masonry-no-border";
                }
                
                $output .=  invio_new_section($params);
                $output .= $masonry_html;
                $output .= invio_section_after_element_content( $meta , 'after_masonry' );
                
                return $output;
            }
            
    }
}









