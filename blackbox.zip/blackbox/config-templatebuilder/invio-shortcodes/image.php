<?php
/**
 * Textblock
 * Shortcode which creates a text element wrapped in a div
 */

if ( !class_exists( 'invio_sc_image' ) )
{
    class invio_sc_image extends invioShortcodeTemplate
    {
            /**
             * Create the config array for the shortcode button
             */
            function shortcode_insert_button()
            {
                $this->config['name']            = __('Image', 'invio_framework' );
                $this->config['tab']            = __('Media Elements', 'invio_framework' );
                $this->config['icon']            = InvioBuilder::$path['imagesURL']."sc-image.png";
                $this->config['order']            = 100;
                $this->config['target']            = 'invio-target-insert';
                $this->config['shortcode']         = 'invio_image';
                //$this->config['modal_data']     = array('modal_class' => 'mediumscreen');
                $this->config['tooltip']         = __('Inserts an image of your choice', 'invio_framework' );
            }

            /**
             * Popup Elements
             *
             * If this function is defined in a child class the element automatically gets an edit button, that, when pressed
             * opens a modal window that allows to edit the element properties
             *
             * @return void
             */
            function popup_elements()
            {
                $this->elements = array(
                    
                    array(
                            "type"     => "tab_container", 'nodescription' => true
                        ),
                        
                    array(
                            "type"     => "tab",
                            "name"  => __("Image Settings" , 'invio_framework'),
                            'nodescription' => true
                        ),
                    
                    array(
                            "name"     => __("Choose Image",'invio_framework' ),
                            "desc"     => __("Either upload a new, or choose an existing image from your media library",'invio_framework' ),
                            "id"     => "src",
                            "type"     => "image",
                            "title" => __("Insert Image",'invio_framework' ),
                            "button" => __("Insert",'invio_framework' ),
                            "std"     => InvioBuilder::$path['imagesURL']."placeholder.jpg"),



                    array(
                            "name"     => __("Image Alignment", 'invio_framework' ),
                            "desc"     => __("Choose here, how to align your image", 'invio_framework' ),
                            "id"     => "align",
                            "type"     => "select",
                            "std"     => "center",
                            "subtype" => array(
                                                __('Center',  'invio_framework' ) =>'center',
                                                __('Right',  'invio_framework' ) =>'right',
                                                __('Left',  'invio_framework' ) =>'left',
                                                __('No special alignment', 'invio_framework' ) =>'',
                                                )
                            ),
                    
                    array(
                            "name"     => __("Image Styling", 'invio_framework' ),
                            "desc"     => __("Chose a styling variaton", 'invio_framework' ),
                            "id"     => "styling",
                            "type"     => "select",
                            "std"     => "",
                            "subtype" => array(
                                                __('Default',  'invio_framework' )     =>'',
                                                __('Circle (image height and width must be equal)',  'invio_framework' )     =>'circle',
                                                __('No Styling (no border, no border radius etc)',  'invio_framework' ) =>'no-styling',
                                                )
                            ),
                    
                    array(
                            "name"     => __("Image Hover effect", 'invio_framework' ),
                            "desc"     => __("Add a mouse hover effect to the image", 'invio_framework' ),
                            "id"     => "hover",
                            "type"     => "select",
                            "std"     => "",
                            "subtype" => array(
                                                __('No',  'invio_framework' )     =>'',
                                                __('Yes, slightly increase the image size',  'invio_framework' )     =>'invio-hover-grow',
                                                )
                            ),
                            
                    array(
                            "type"     => "close_div",
                            'nodescription' => true
                        ),
                    
                    array(
                            "type"     => "tab",
                            "name"    => __("Link Settings",'invio_framework' ),
                            'nodescription' => true
                        ),
                    
                     array(
                            "name"     => __("Image Link?", 'invio_framework' ),
                            "desc"     => __("Where should your image link to?", 'invio_framework' ),
                            "id"     => "link",
                            "type"     => "linkpicker",
                            "fetchTMPL"    => true,
                            "subtype" => array(
                                                __('No Link', 'invio_framework' ) =>'',
                                                __('Lightbox', 'invio_framework' ) =>'lightbox',
                                                __('Set Manually', 'invio_framework' ) =>'manually',
                                                __('Single Entry', 'invio_framework' ) =>'single',
                                                __('Taxonomy Overview Page',  'invio_framework' )=>'taxonomy',
                                                ),
                            "std"     => ""),

                    array(
                        "name"     => __("Open new tab/window", 'invio_framework' ),
                        "desc"     => __("Do you want to open the link url in a new tab/window?", 'invio_framework' ),
                        "id"     => "target",
                        "type"     => "select",
                        "std"    => "",
                        "required"=> array('link','not_empty_and','lightbox'),
                        "subtype" => InvioHtmlHelper::linking_options()
                        ),
                        
                        
                    
                    
                    array(
                            "type"     => "close_div",
                            'nodescription' => true
                        ),
                    
                    array(
                            "type"     => "tab",
                            "name"    => __("Caption",'invio_framework' ),
                            'nodescription' => true
                        ),
                            
                    array(
                        "name"     => __("Image Caption", 'invio_framework' ),
                        "desc"     => __("Display a caption overlay?", 'invio_framework' ),
                        "id"     => "caption",
                        "type"     => "select",
                        "std"     => "",
                        "subtype" => array(
                                            __('No',  'invio_framework' )     =>'',
                                            __('Yes',  'invio_framework' )     =>'yes',
                                            )
                        ),
                    
                    array(
                        "name"         => __("Caption", 'invio_framework' ),
                        "id"         => "content",
                        "type"         => "textarea",
                        "required"    => array('caption','equals','yes'),
                        "std"         => "",
                        ),
                        
                        
                    array(    "name"     => __("Caption custom font size?", 'invio_framework' ),
                            "desc"     => __("Size of your caption in pixel", 'invio_framework' ),
                            "id"     => "font_size",
                            "type"     => "select",
                            "required"    => array('caption','equals','yes'),
                            "subtype" => InvioHtmlHelper::number_array(10,40,1, array('Default' =>''),'px'),
                            "std" => ""),    
                            
                    array(
                        "name"     => __("Caption Appearance", 'invio_framework' ),
                        "desc"     => __("When to display the caption?", 'invio_framework' ),
                        "id"     => "appearance",
                        "type"     => "select",
                        "std"     => "",
                        "container_class" => 'invio_half invio_half_first',
                        "required"    => array('caption','equals','yes'),
                        "subtype" => array(
                                            __('Always display caption',  'invio_framework' )     =>'',
                                            __('Only display on hover',  'invio_framework' )     =>'on-hover',
                                            )
                        ),
                        
                    array(
                        "name"     => __("Caption Overlay Opacity",'invio_framework' ),
                        "desc"     => __("Set the opacity of your overlay: 0.1 is barely visible, 1.0 is opaque ", 'invio_framework' ),
                        "id"     => "overlay_opacity",
                        "type"     => "select",
                        "std"     => "0.4",
                        "container_class" => 'invio_half',
                        "required"    => array('caption','equals','yes'),
                        "subtype" => array(   __('0.1','invio_framework' )=>'0.1',
                                              __('0.2','invio_framework' )=>'0.2',
                                              __('0.3','invio_framework' )=>'0.3',
                                              __('0.4','invio_framework' )=>'0.4',
                                              __('0.5','invio_framework' )=>'0.5',
                                              __('0.6','invio_framework' )=>'0.6',
                                              __('0.7','invio_framework' )=>'0.7',
                                              __('0.8','invio_framework' )=>'0.8',
                                              __('0.9','invio_framework' )=>'0.9',
                                              __('1.0','invio_framework' )=>'1',
                                              )
                          ),
                          
                      array(
                            "name"     => __("Caption Overlay Background Color", 'invio_framework' ),
                            "desc"     => __("Select a background color for your overlay here.", 'invio_framework' ),
                            "id"     => "overlay_color",
                            "type"     => "colorpicker",
                            "container_class" => 'invio_half invio_half_first',
                            "required"    => array('caption','equals','yes'),
                            "std"     => "#000000",
                        ),    
                    
                    array(    
                            "name"     => __("Caption Font Color", 'invio_framework' ),
                            "desc"     => __("Select a font color for your overlay here.", 'invio_framework' ),
                            "id"     => "overlay_text_color",
                            "type"     => "colorpicker",
                            "std"     => "#ffffff",
                            "container_class" => 'invio_half',
                            "required"    => array('caption','equals','yes'),
                        ),        
                        
                        
                        
                        
                array(
                            "type"     => "close_div",
                            'nodescription' => true
                        ),
                
                array(
                            "type"     => "tab",
                            "name"    => __("Animation",'invio_framework' ),
                            'nodescription' => true
                        ),
                
                
                array(
                            "name"     => __("Image Fade in Animation", 'invio_framework' ),
                            "desc"     => __("Add a small animation to the image when the user first scrolls to the image position. This is only to add some 'spice' to the site and only works in modern browsers", 'invio_framework' ),
                            "id"     => "animation",
                            "type"     => "select",
                            "std"     => "no-animation",
                            "subtype" => array(
                                __('None',  'invio_framework' ) =>'no-animation',
                                
                                __('Fade Animations',  'invio_framework') => array(
                                    __('Fade in',  'invio_framework' ) =>'fade-in',
                                    __('Pop up',  'invio_framework' ) =>'pop-up',
                                ),
                                __('Slide Animations',  'invio_framework') => array(
                                    __('Top to Bottom',  'invio_framework' ) =>'top-to-bottom',
                                    __('Bottom to Top',  'invio_framework' ) =>'bottom-to-top',
                                    __('Left to Right',  'invio_framework' ) =>'left-to-right',
                                    __('Right to Left',  'invio_framework' ) =>'right-to-left',
                                    ),
                                __('Rotate',  'invio_framework') => array(
                                    __('Full rotation',  'invio_framework' ) =>'invio-rotateIn',
                                    __('Bottom left rotation',  'invio_framework' ) =>'invio-rotateInUpLeft',
                                    __('Bottom right rotation',  'invio_framework' ) =>'invio-rotateInUpRight',
                                    )
                                )
                    ),
                
                array(
                            "type"     => "close_div",
                            'nodescription' => true
                        ),
                
                    
                array(
                            "type"     => "close_div",
                            'nodescription' => true
                        ),    
                
                        
                );
                        
                        
                        
                        
            }

            /**
             * Editor Element - this function defines the visual appearance of an element on the InvioBuilder Canvas
             * Most common usage is to define some markup in the $params['innerHtml'] which is then inserted into the drag and drop container
             * Less often used: $params['data'] to add data attributes, $params['class'] to modify the className
             *
             *
             * @param array $params this array holds the default values for $content and $args.
             * @return $params the return array usually holds an innerHtml key that holds item specific markup.
             */
            function editor_element($params)
            {
                $template = $this->update_template("src", "<img src='{{src}}' alt=''/>");
                $img      = "";
                
                if(!empty($params['args']['attachment']) && !empty($params['args']['attachment_size']))
                {
                    $img = wp_get_attachment_image($params['args']['attachment'],$params['args']['attachment_size']);
                }
                else if(isset($params['args']['src']) && is_numeric($params['args']['src']))
                {
                    $img = wp_get_attachment_image($params['args']['src'],'large');
                }
                else if(!empty($params['args']['src']))
                {
                    $img = "<img src='".$params['args']['src']."' alt=''  />";
                }


                $params['innerHtml']  = "<div class='invio_image invio_image_style invio_hidden_bg_box'>";
                $params['innerHtml'] .= "<div ".$this->class_by_arguments('align' ,$params['args']).">";
                $params['innerHtml'] .= "<div class='invio_image_container' {$template}>{$img}</div>";
                $params['innerHtml'] .= "</div>";
                $params['innerHtml'] .= "</div>";
                $params['class'] = "";

                return $params;
            }

            /**
             * Frontend Shortcode Handler
             *
             * @param array $atts array of attributes
             * @param string $content text within enclosing form of shortcode element
             * @param string $shortcodename the shortcode found, when == callback name
             * @return string $output returns the modified html string
             */
            function shortcode_handler($atts, $content = "", $shortcodename = "", $meta = "")
            {
                $output = "";
                $class  = "";
                $alt     = "";
                $title     = "";

                $atts = shortcode_atts(
                        array(    'src'=>'', 
                                'animation'=>'no-animation', 
                                'link'=>'', 
                                'attachment'=>'', 
                                'attachment_size'=>'', 
                                'target'=>'no', 
                                'styling' =>'', 
                                'caption'=>'', 
                                'font_size'=>'', 
                                'appearance'=>'', 
                                'hover'=>'',
                                'align' => 'center',
                                'overlay_opacity'=>'0.4', 
                                'overlay_color'=>'#444444', 
                                'overlay_text_color'=>'#ffffff'
                            ), $atts, $this->config['shortcode']);
                
                extract($atts);
                
            
                if(!empty($attachment))
                {
                    $attachment_entry = get_post( $attachment );
                    
                    if(!empty($attachment_entry))
                    {
                        $alt = get_post_meta($attachment_entry->ID, '_wp_attachment_image_alt', true);
                        $alt = !empty($alt) ? esc_attr($alt) : '';
                        $title = trim($attachment_entry->post_title) ? esc_attr($attachment_entry->post_title) : "";
                        
                        if(!empty($attachment_size))
                        {
                            $src = wp_get_attachment_image_src($attachment_entry->ID, $attachment_size);
                            $src = !empty($src[0]) ? $src[0] : "";
                        }
                    }
                }
                else
                {
                    $attachment = false;
                }

            

                if(!empty($src))
                {
                    $class  = $animation == "no-animation" ? "" :"invio_animated_image invio_animate_when_almost_visible ".$animation;
                    $class .= " invio-styling-".$styling." ".$hover;
                    
                    if(is_numeric($src))
                    {
                        //$output = wp_get_attachment_image($src,'large');
                        $output = wp_get_attachment_image($src,'large',false,array('class' => "invio_image $class " . $this->class_by_arguments('align' ,$atts, true)));
                    }
                    else
                    {
                        $link = invioHelper::get_url($link, $attachment);

                        $blank = (strpos($target, '_blank') !== false || $target == 'yes') ? ' target="_blank" ' : "";
                        $blank .= strpos($target, 'nofollow') !== false ? ' rel="nofollow" ' : "";
                        
                        $overlay = "";
                        $style = "";
                        $style .= InvioHelper::style_string($atts, 'overlay_text_color', 'color');
                        if($font_size)
                        {
                            // $style = "style='font-size: {$font_size}px;'";
                            $style .= InvioHelper::style_string($atts, 'font_size', 'font-size', 'px');
                        }
                        $style  = InvioHelper::style_string($style);
                        
                        
                        if($caption == "yes")
                        {    
                            
                            $caption_style = "";
                            $caption_style .= InvioHelper::style_string($atts, 'overlay_opacity', 'opacity');
                            $caption_style .= InvioHelper::style_string($atts, 'overlay_color', 'background-color');
                            $caption_style  = InvioHelper::style_string($caption_style);
                            $overlay_bg = "<div class='invio-caption-image-overlay-bg' $caption_style></div>";
                            
                            $content = ShortcodeHelper::invio_apply_autop(ShortcodeHelper::invio_remove_autop($content));
                            $overlay = "<div class='invio-image-caption-overlay'>{$overlay_bg}<div class='invio-image-caption-overlay-position'><div class='invio-image-caption-overlay-center' {$style}>{$content}</div></div></div>";
                            $class .= " noHover ";
                            
                            if(empty($appearance)) $appearance = "hover-deactivate";
                            if($appearance) $class .= " invio-overlay-".$appearance;
                        }

                        $markup_url = invio_markup_helper(array('context' => 'image_url','echo'=>false, 'custom_markup'=>$meta['custom_markup']));
                        $markup = invio_markup_helper(array('context' => 'image','echo'=>false, 'custom_markup'=>$meta['custom_markup']));

                        $output .= "<div class='invio-image-container {$class} ".$meta['el_class']." ".$this->class_by_arguments('align' ,$atts, true)."' $markup >";
                        $output .= "<div class='invio-image-container-inner'>";
                        if($link)
                        {
                            $output.= "<a href='{$link}' class='invio_image'  {$blank}>{$overlay}<img class='invio_image ' src='{$src}' alt='{$alt}' title='{$title}' $markup_url /></a>";
                        }
                        else
                        {
                            $output.= "{$overlay}<img class='invio_image ' src='{$src}' alt='{$alt}' title='{$title}'  $markup_url />";
                        }
                        $output .= "</div>";
                        $output .= "</div>";
                    }




                }

                return $output;
            }


    }
}









