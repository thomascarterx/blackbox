<?php

if ( !class_exists( 'invio_sc_headline_rotator' ) )
{
    class invio_sc_headline_rotator extends invioShortcodeTemplate
    {
            var $count;
            /**
             * Create the config array for the shortcode button
             */
            function shortcode_insert_button()
            {
                $this->config['name']        = __('Headline Rotator', 'invio_framework' );
                $this->config['tab']        = __('Content Elements', 'invio_framework' );
                $this->config['icon']        = InvioBuilder::$path['imagesURL']."sc-heading.png";
                $this->config['order']        = 85;
                $this->config['target']        = 'invio-target-insert';
                $this->config['shortcode']     = 'invio_headline_rotator';
                $this->config['shortcode_nested'] = array('invio_rotator_item');
                $this->config['tooltip']     = __('Creates a text rotator for dynamic headings', 'invio_framework' );
            }

            /**
             * Popup Elements
             *
             * If this function is defined in a child class the element automatically gets an edit button, that, when pressed
             * opens a modal window that allows to edit the element properties
             *
             * @return void
             */
            function popup_elements()
            {
                $this->elements = array(
                    array(
                            "type"     => "tab_container", 'nodescription' => true
                        ),
                        
                    array(
                            "type"     => "tab",
                            "name"  => __("Text" , 'invio_framework'),
                            'nodescription' => true
                        ),
                        
                        array(
                                    "name"     => __("Prepended static text", 'invio_framework' ),
                                    "desc"     => __("Enter static text that should be displayed before the rotating text", 'invio_framework' ) ,
                                    "id"     => "before_rotating",
                                    "std"     => __('We are ', 'invio_framework' ),
                                    "type"     => "input"
                            ),
                        
                        array(
                            "name" => __("Add/Edit rotating text", 'invio_framework' ),
                            "desc" => __("Here you can add, remove and edit the rotating text", 'invio_framework' ),
                            "type"             => "modal_group",
                            "id"             => "content",
                            "modal_title"     => __("Edit Text Element", 'invio_framework' ),
                            "std"            => array(

                                                    array('title'=>__('great', 'invio_framework' )),
                                                    array('title'=>__('smart', 'invio_framework' )),
                                                    array('title'=>__('fast', 'invio_framework' )),

                                                    ),


                            'subelements'     => array(

                                    array(
                                    "name"     => __("Rotating Text", 'invio_framework' ),
                                    "desc"     => __("Enter the rotating text here (Better keep it short)", 'invio_framework' ) ,
                                    "id"     => "title",
                                    "std"     => "",
                                    "type"     => "input"),


                                array(
                                    "name"     => __("Text Link?", 'invio_framework' ),
                                    "desc"     => __("Do you want to apply  a link to the title?", 'invio_framework' ),
                                    "id"     => "link",
                                    "type"     => "linkpicker",
                                    "fetchTMPL"    => true,
                                    "std"    => "",
                                    "subtype" => array(
                                        __('No Link', 'invio_framework' ) =>'',
                                        __('Set Manually', 'invio_framework' ) =>'manually',
                                        __('Single Entry', 'invio_framework' ) =>'single',
                                        __('Taxonomy Overview Page',  'invio_framework' )=>'taxonomy',
                                    ),
                                    "std"     => ""),

                                array(
                                    "name"     => __("Open in new window", 'invio_framework' ),
                                    "desc"     => __("Do you want to open the link in a new window", 'invio_framework' ),
                                    "id"     => "linktarget",
                                    "required"     => array('link', 'not', ''),
                                    "type"     => "select",
                                    "std"     => "no",
                                    "subtype" => InvioHtmlHelper::linking_options()),
                                
                                array(    
                                "name"     => __("Custom Font Color", 'invio_framework' ),
                                "desc"     => __("Select a custom font color. Leave empty to use the default", 'invio_framework' ),
                                "id"     => "custom_title",
                                "type"     => "colorpicker",
                                "std"     => "",
                            ),    


                        )
                    ),
                    
                    array(
                                    "name"     => __("Appended static text", 'invio_framework' ),
                                    "desc"     => __("Enter static text that should be displayed after the rotating text", 'invio_framework' ) ,
                                    "id"     => "after_rotating",
                                    "std"     => "",
                                    "type"     => "input"
                            ),
                    
                    array(
                        "name"     => __("Activate Multiline?",'invio_framework' ),
                        "desc"     => __("Check if prepended, rotating and appended text should each be displayed on its own line",'invio_framework' ),
                        "id"     => "multiline",
                        "type"     => "checkbox",
                        "std"     => "",
                        ),
                    
                    
                    array(
                            "type"     => "close_div",
                            'nodescription' => true
                        ),
                    
                    array(
                            "type"     => "tab",
                            "name"    => __("Rotation",'invio_framework' ),
                            'nodescription' => true
                        ),
                        
                    array(    
                        "name"     => __("Autorotation duration",'invio_framework' ),
                        "desc"     => __("Each rotating textblock will be shown the selected amount of seconds.",'invio_framework' ),
                        "id"     => "interval",
                        "type"     => "select",
                        "std"     => "5",
                        "subtype" => 
                        array('2'=>'2','3'=>'3','4'=>'4','5'=>'5','6'=>'6','7'=>'7','8'=>'8','9'=>'9','10'=>'10','15'=>'15','20'=>'20','30'=>'30','40'=>'40','60'=>'60','100'=>'100')),
                    
    
                    array(    
                            "name"     => __("Rotation Animation", 'invio_framework' ),
                            "desc"     => __("Select the rotation animation", 'invio_framework' ),
                            "id"     => "animation",
                            "type"     => "select",
                            "std"     => "",
                            "subtype" => array(
                                                "Top to bottom"=>'',
                                                "Bottom to top"=>'reverse',
                                                "Fade only" => 'fade'
                                                )
                            ), 
                    
                    array(
                            "type"     => "close_div",
                            'nodescription' => true
                        ),
                    
                    array(
                            "type"     => "tab",
                            "name"    => __("Style",'invio_framework' ),
                            'nodescription' => true
                        ),
                    
                    array(    
                            "name"     => __("HTML Markup", 'invio_framework' ),
                            "desc"     => __("Select which kind of HTML markup you want to apply to set the importance of the headline for search engines", 'invio_framework' ),
                            "id"     => "tag",
                            "type"     => "select",
                            "std"     => "h3",
                            "subtype" => array("H1"=>'h1',"H2"=>'h2',"H3"=>'h3',"H4"=>'h4',"H5"=>'h5',"H6"=>'h6', __('Paragraph','invio_framework') => 'p')
                            ), 
                    
                    array(    "name"     => __("Text Size", 'invio_framework' ),
                            "desc"     => __("Size of your Text in Pixel", 'invio_framework' ),
                            "id"     => "size",
                            "type"     => "select",
                            "subtype" => InvioHtmlHelper::number_array(11,150,1, array( __("Default Size", 'invio_framework' )=>'')),
                            "std" => ""),                
                    
                    array(    
                            "name"     => __("Text align", 'invio_framework' ),
                            "desc"     => __("Alignment of the text", 'invio_framework' ),
                            "id"     => "align",
                            "type"     => "select",
                            "std"     => "left",
                            "subtype" => array(    __('Center', 'invio_framework' ) =>'center',
                                                __('Left', 'invio_framework' )  =>'left',
                                                __('Right', 'invio_framework' ) =>'right',
                                                )),
                    
                    array(    
                            "name"     => __("Custom Font Color", 'invio_framework' ),
                            "desc"     => __("Select a custom font color. Leave empty to use the default", 'invio_framework' ),
                            "id"     => "custom_title",
                            "type"     => "colorpicker",
                            "std"     => "",
                        ),    
                        
                    
                    
                            
                    array(
                            "type"     => "close_div",
                            'nodescription' => true
                        ),
                        
                    array(
                            "type"     => "close_div",
                            'nodescription' => true
                        ),

                );


            }

            /**
             * Editor Sub Element - this function defines the visual appearance of an element that is displayed within a modal window and on click opens its own modal window
             * Works in the same way as Editor Element
             * @param array $params this array holds the default values for $content and $args.
             * @return $params the return array usually holds an innerHtml key that holds item specific markup.
             */
            function editor_sub_element($params)
            {
                $template = $this->update_template("title", "{{title}}");

                $params['innerHtml']  = "";
                $params['innerHtml'] .= "<div class='invio_title_container'>";
                $params['innerHtml'] .= "<span {$template} >".$params['args']['title']."</span></div>";

                return $params;
            }



            /**
             * Frontend Shortcode Handler
             *
             * @param array $atts array of attributes
             * @param string $content text within enclosing form of shortcode element
             * @param string $shortcodename the shortcode found, when == callback name
             * @return string $output returns the modified html string
             */
            function shortcode_handler($atts, $content = "", $shortcodename = "", $meta = "")
            {
                extract(shortcode_atts(array(
                
                'align'=>'left', 
                'before_rotating'=>'', 
                'after_rotating'=>'', 
                'interval'=>'5', 
                'tag'=>'h3',
                'size' => "",
                'custom_title' => '',
                'multiline' => 'disabled',
                'animation' => ''
                
                ), $atts, $this->config['shortcode']));
                
                
                
                $this->count = 0;
                $style = "";
                $style .= InvioHelper::style_string($atts, 'align', 'text-align');
                $style .= InvioHelper::style_string($atts, 'custom_title', 'color');
                $style .= InvioHelper::style_string($atts, 'size', 'font-size', 'px');
                $style  = InvioHelper::style_string($style);
                
                $multiline = $multiline == 'disabled' ? "off" : "on";
                
                switch($animation)
                {
                    case 'reverse': $animation = -1; break;
                    case 'fade':     $animation = 0; break;
                    default:         $animation = 1;
                }
                
                $data = "data-interval='{$interval}' data-animation='{$animation}'";
                
                if(empty($after_rotating) && $align == 'center' ) { $data .= " data-fixWidth='1'"; $meta['el_class'] .= " invio-fixed-rotator-width"; } 
                
                
                $output     = "";
                $output .= "<div {$style} class='invio-rotator-container invio-rotation-container-".$atts['align']." ".$meta['el_class']."' {$data}>";
                $output .= "<{$tag} class='invio-rotator-container-inner'>";
                $output .= apply_filters('invio_ampersand', $before_rotating);
                $output .= "<span class='invio-rotator-text invio-rotator-multiline-{$multiline}'>";
                $output .= ShortcodeHelper::invio_remove_autop( $content, true );
                $output .= "</span>";
                $output .= apply_filters('invio_ampersand', $after_rotating);
                $output .= "</{$tag}>";
                $output .= "</div>";


                return $output;
            }

            function invio_rotator_item($atts, $content = "", $shortcodename = "")
            {
                $atts = shortcode_atts(
                array(    
                    'title'         => '',
                    'link'             => '',
                    'linktarget'     => '',
                    'custom_title'     => '',
                ), 
                $atts, 'invio_rotator_item');
                
                extract($atts);
                
                $this->count++;
                
                $style  = InvioHelper::style_string($atts, 'custom_title', 'color');
                $style  = InvioHelper::style_string($style);
                
                $link = InvioHelper::get_url($link);
                $blank = (strpos($linktarget, '_blank') !== false || $linktarget == 'yes') ? ' target="_blank" ' : "";
                $blank .= strpos($linktarget, 'nofollow') !== false ? ' rel="nofollow" ' : "";
           
            
                $tags = !empty($link) ? array("a href='{$link}' {$blank} ",'a') : array('span','span');
                

                $output  = "";
                $output .= "<{$tags[0]} {$style} class='invio-rotator-text-single invio-rotator-text-single-{$this->count}'>";
                $output .= ShortcodeHelper::invio_remove_autop( $title , true );
                $output .= "</{$tags[1]}>";
                return $output;
            }


    }
}
