<?php
/**
 * Display Numbers that count from 0 to the number you entered
 */
 
 if( !class_exists( 'Tribe__Events__Main' ) )
{
    function invio_countdown_events_fallback()
    {
        return "<p>Please install the <a href='https://wordpress.org/plugins/the-events-calendar/'>The Events Calendar</a> or <a href='http://mbsy.co/6cr37'>The Events Calendar Pro</a> Plugin to display the countdown</p>";
    }
    
    add_shortcode('invio_events_countdown', 'invio_countdown_events_fallback');
    return;
}

 
if ( !class_exists( 'invio_sc_events_countdown' ) ) 
{
    
    class invio_sc_events_countdown extends invioShortcodeTemplate
    {
            /**
             * Create the config array for the shortcode button
             */
            function shortcode_insert_button()
            {
                $this->config['name']        = __('Events Countdown', 'invio_framework' );
                $this->config['tab']        = __('Plugin Additions', 'invio_framework' );
                $this->config['icon']        = InvioBuilder::$path['imagesURL']."sc-countdown.png";
                $this->config['order']        = 14;
                $this->config['target']        = 'invio-target-insert';
                $this->config['shortcode']     = 'invio_events_countdown';
                $this->config['tooltip']     = __('Display a countdown to the next upcoming event', 'invio_framework' );
                
                $this->time_array = array(
                                __('Second',      'invio_framework' )     =>'1',
                                __('Minute',      'invio_framework' )     =>'2',    
                                __('Hour',      'invio_framework' )     =>'3',
                                __('Day',          'invio_framework' )     =>'4',
                                __('Week',      'invio_framework' )     =>'5',
                                /*
                                __('Month',      'invio_framework' )     =>'6',
                                __('Year',      'invio_framework' )     =>'7'
                                */
                            );
                            
                
            }
            
            function fetch_upcoming()
            {
                $query         = array('paged'=> false, 'posts_per_page' => 1, 'eventDisplay' => 'list');
                $upcoming     = Tribe__Events__Query::getEvents( $query, true);
                
                return $upcoming;
            }
        
        
            /**
             * Popup Elements
             *
             * If this function is defined in a child class the element automatically gets an edit button, that, when pressed
             * opens a modal window that allows to edit the element properties
             *
             * @return void
             */
            function popup_elements()
            {
                $this->elements = array(
                    array(
                            "type"     => "tab_container", 'nodescription' => true
                        ),
                        
                    array(
                            "type"     => "tab",
                            "name"  => __("Content" , 'invio_framework'),
                            'nodescription' => true
                        ),
                    
                    
                    array(    
                            "name"     => __("Smallest time unit", 'invio_framework' ),
                            "desc"     => __("The smallest unit that will be displayed", 'invio_framework' ),
                            "id"     => "min",
                            "type"     => "select",
                            "std"     => "1",
                            "subtype" => $this->time_array),
                    
                    
                    array(    
                            "name"     => __("Largest time unit", 'invio_framework' ),
                            "desc"     => __("The largest unit that will be displayed", 'invio_framework' ),
                            "id"     => "max",
                            "type"     => "select",
                            "std"     => "5",
                            "subtype" => $this->time_array),
                    
                    
                    
                            
                    array(
                            "name"     => __("Text Alignment", 'invio_framework' ),
                            "desc"     => __("Choose here, how to align your text", 'invio_framework' ),
                            "id"     => "align",
                            "type"     => "select",
                            "std"     => "center",
                            "subtype" => array(
                                                __('Center',  'invio_framework' ) =>'invio-align-center',
                                                __('Right',  'invio_framework' ) =>'invio-align-right',
                                                __('Left',  'invio_framework' ) =>'invio-align-left',
                                                )
                            ),
                            
                    array(    "name"     => __("Number Font Size", 'invio_framework' ),
                            "desc"     => __("Size of your numbers in Pixel", 'invio_framework' ),
                            "id"     => "size",
                            "type"     => "select",
                            "subtype" => InvioHtmlHelper::number_array(20,90,1, array( __("Default Size", 'invio_framework' )=>'')),
                            "std" => ""),
                   
                   array(
                            "name"     => __("Display Event Title?", 'invio_framework' ),
                            "desc"     => __("Choose here, if you want to display the event title", 'invio_framework' ),
                            "id"     => "title",
                            "type"     => "select",
                            "std"     => "",
                            "subtype" => array(
                                                __('No Title, timer only',  'invio_framework' ) =>'',
                                                __('Title on top',  'invio_framework' )     =>'top',
                                                __('Title below',  'invio_framework' )     =>'bottom',
                                                )
                            ),
                   
                   
                   
                            
                   array(
                            "type"     => "close_div",
                            'nodescription' => true
                        ),
                    
                    array(
                            "type"     => "tab",
                            "name"    => __("Colors",'invio_framework' ),
                            'nodescription' => true
                        ),
                                 
                   array(
                            "name"     => __("Colors", 'invio_framework' ),
                            "desc"     => __("Choose the colors here", 'invio_framework' ),
                            "id"     => "style",
                            "type"     => "select",
                            "std"     => "center",
                            "subtype" => array(
                                                __('Default',    'invio_framework' )     =>'invio-default-style',
                                                __('Theme colors',    'invio_framework' )     =>'invio-colored-style',
                                                __('Transparent Light', 'invio_framework' )     =>'invio-trans-light-style',
                                                __('Transparent Dark',  'invio_framework' )  =>'invio-trans-dark-style',
                                                )
                            ),
                    array(
                            "type"     => "close_div",
                            'nodescription' => true
                        ),
                        
                    array(
                            "type"     => "close_div",
                            'nodescription' => true
                        ),
                );

            }
            
            /**
             * Frontend Shortcode Handler
             *
             * @param array $atts array of attributes
             * @param string $content text within enclosing form of shortcode element 
             * @param string $shortcodename the shortcode found, when == callback name
             * @return string $output returns the modified html string 
             */
            function shortcode_handler($atts, $content = "", $shortcodename = "", $meta = "")
            {
                
                $next = $this->fetch_upcoming();
                
                if(empty( $next->posts[0] ) || empty( $next->posts[0]->EventStartDate)) return;
                
                $events_date = explode(" ", $next->posts[0]->EventStartDate );
                
                if(isset($events_date[0]))
                {
                    $atts['date'] = date("m/d/Y", strtotime($events_date[0]));
                }
                
                if(isset($events_date[1]))
                {
                    $events_date = explode(":", $events_date[1] );
                    $atts['hour'] = $events_date[0];
                    $atts['minute'] = $events_date[1];
                }
                
                $atts['link']     = get_permalink( $next->posts[0]->ID );
                $title             = get_the_title( $next->posts[0]->ID );
                
                if(!empty( $atts['title'] ))
                {
                    $atts['title']  = array( $atts['title'] => __("Upcoming",'invio_framework') .": " . $title );
                }
                
                $timer  = new invio_sc_countdown( $this->builder );
                $output = $timer->shortcode_handler( $atts , $content, $shortcodename, $meta);
                
                
                return $output;
            }
    }
}





