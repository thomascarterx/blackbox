<?php
/**
 * COLUMNS
 * Shortcode which creates columns for better content separation
 */

 // Don't load directly
if ( !defined('ABSPATH') ) { die('-1'); }



if ( !class_exists( 'invio_sc_cell' ) )
{
    class invio_sc_cell extends invioShortcodeTemplate{

            static $extraClass = "";
            static $attr = array();

            /**
             * Create the config array for the shortcode button
             */
            function shortcode_insert_button()
            {
                $this->config['invisible'] = true;
                $this->config['name']        = '1/1';
                $this->config['icon']        = InvioBuilder::$path['imagesURL']."sc-full.png";
                $this->config['tab']        = __('Layout Elements', 'invio_framework' );
                $this->config['order']        = 100;
                $this->config['target']        = "invio-section-drop";
                $this->config['shortcode']     = 'invio_cell_one_full';
                $this->config['html_renderer']     = false;
                $this->config['tinyMCE']     = array('disable' => "true");
                $this->config['tooltip']     = __('Creates a single full width column', 'invio_framework' );
                $this->config['drag-level'] = 2;
                $this->config['drop-level'] = 1;
                }


            /**
             * Editor Element - this function defines the visual appearance of an element on the InvioBuilder Canvas
             * Most common usage is to define some markup in the $params['innerHtml'] which is then inserted into the drag and drop container
             * Less often used: $params['data'] to add data attributes, $params['class'] to modify the className
             *
             *
             * @param array $params this array holds the default values for $content and $args.
             * @return $params the return array usually holds an innerHtml key that holds item specific markup.
             */

            function editor_element($params)
            {
                
                extract($params);
                $name         = $this->config['shortcode'];
                $drag         = $this->config['drag-level'];
                $drop         = $this->config['drop-level'];

                $size = array(    'invio_cell_one_full' => '1/1', 
                                'invio_cell_one_half' => '1/2', 
                                'invio_cell_one_third' => '1/3', 
                                'invio_cell_one_fourth' => '1/4', 
                                'invio_cell_one_fifth' => '1/5', 
                                'invio_cell_two_third' => '2/3', 
                                'invio_cell_three_fourth' => '3/4', 
                                'invio_cell_two_fifth' => '2/5', 
                                'invio_cell_three_fifth' => '3/5', 
                                'invio_cell_four_fifth' => '4/5'
                                
                            );
                
                $data['shortcodehandler']     = $this->config['shortcode'];
                $data['modal_title']         = __('Edit Cell','invio_framework' );
                $data['modal_ajax_hook']     = $this->config['shortcode'];
                $data['dragdrop-level']        = $this->config['drag-level'];
                $data['allowed-shortcodes'] = $this->config['shortcode'];
                
                if(!empty($this->config['modal_on_load']))
                {
                    $data['modal_on_load']     = $this->config['modal_on_load'];
                }
    
                $dataString  = InvioHelper::create_data_string($data);
                
            

                $output  = "<div class='invio_layout_column invio_layout_cell invio_pop_class invio-no-visual-updates ".$name." invio_drag' {$dataString} data-width='{$name}'>";
                $output .= "<div class='invio_sorthandle'>";

                $output .= "<span class='invio-col-size'>".$size[$name]."</span>";
                $output .= "<a class='invio-delete'  href='#delete' title='".__('Delete Cell','invio_framework' )."'>x</a>";
                $output .= "<a class='invio-clone'  href='#clone' title='".__('Clone Cell','invio_framework' )."' >".__('Clone Cell','invio_framework' )."</a>";
                
                if(!empty($this->config['popup_editor']))
                {
                    $output .= "    <a class='invio-edit-element'  href='#edit-element' title='".__('Edit Cell','invio_framework' )."'>edit</a>";
                }
                
                $output .= "</div><div class='invio_inner_shortcode invio_connect_sort invio_drop ' data-dragdrop-level='{$drop}'><span class='invio-fake-cellborder'></span>";
                $output .= "<textarea data-name='text-shortcode' cols='20' rows='4'>".ShortcodeHelper::create_shortcode_by_array($name, $content, $args)."</textarea>";
                if($content)
                {
                    $content = $this->builder->do_shortcode_backend($content);
                }
                $output .= $content;
                $output .= "</div></div>";

                return $output;
            }
            
            
            /**
             * Popup Elements
             *
             * If this function is defined in a child class the element automatically gets an edit button, that, when pressed
             * opens a modal window that allows to edit the element properties
             *
             * @return void
             */
            function popup_elements()
            {
                global  $invio_config;

                $this->elements = array(
                    
                    
                    array(
                            "type"     => "tab_container", 'nodescription' => true
                        ),
                    
                     array(
                        "type"     => "tab",
                        "name"  => __("Settings" , 'invio_framework'),
                        'nodescription' => true
                    ),
                
                    
                    array(    
                            "name"     => __("Vertical align", 'invio_framework' ),
                            "desc"     => __("Choose the vertical alignment of your cells content.", 'invio_framework' ),
                            "id"     => "vertical_align",
                            "type"     => "select",
                            "std"     => "top",
                            "subtype" => array(
                                __('Top',   'invio_framework' ) =>'top',
                                __('Middle',  'invio_framework' ) =>'middle',
                                __('Bottom',   'invio_framework' ) =>'bottom',
                            )),    
                    
                    array(    
                            "name"     => __("Cell Padding", 'invio_framework' ),
                            "desc"     => __("Set the distance from the cell content to the border here. Both pixel and &percnt; based values are accepted. eg: 30px, 5&percnt;", 'invio_framework' ),
                            "id"     => "padding",
                            "type"     => "multi_input",
                            "std"     => "30px",
                            "sync"     => true,
                            "multi" => array(    'top'     => __('Padding-Top','invio_framework'), 
                                                'right'    => __('Padding-Right','invio_framework'), 
                                                'bottom'=> __('Padding-Bottom','invio_framework'),
                                                'left'    => __('Padding-Left','invio_framework'), 
                                                )
                        ),
                        
                    
                    
                    array(    
                            "name"     => __("Custom Background Color", 'invio_framework' ),
                            "desc"     => __("Select a custom background color for this cell here. Leave empty for default color", 'invio_framework' ),
                            "id"     => "background_color",
                            "type"     => "colorpicker",
                            "std"     => "",
                        ),
                        
                    array(
                            "name"     => __("Custom Background Image",'invio_framework' ),
                            "desc"     => __("Either upload a new, or choose an existing image from your media library. Leave empty if you don't want to use a background image ",'invio_framework' ),
                            "id"     => "src",
                            "type"     => "image",
                            "title" => __("Insert Image",'invio_framework' ),
                            "button" => __("Insert",'invio_framework' ),
                            "std"     => ""),
                    
                    array(
                        "name"     => __("Background Attachment",'invio_framework' ),
                        "desc"     => __("Background can either scroll with the page or be fixed", 'invio_framework' ),
                        "id"     => "background_attachment",
                        "type"     => "select",
                        "std"     => "scroll",
                        "required" => array('src','not',''),
                        "subtype" => array(
                            __('Scroll','invio_framework' )=>'scroll',
                            __('Fixed','invio_framework' ) =>'fixed',
                            )
                        ),
                    
                    array(
                        "name"     => __("Background Image Position",'invio_framework' ),
                        "id"     => "background_position",
                        "type"     => "select",
                        "std"     => "top left",
                        "required" => array('src','not',''),
                        "subtype" => array(   __('Top Left','invio_framework' )       =>'top left',
                                              __('Top Center','invio_framework' )     =>'top center',
                                              __('Top Right','invio_framework' )      =>'top right',
                                              __('Bottom Left','invio_framework' )    =>'bottom left',
                                              __('Bottom Center','invio_framework' )  =>'bottom center',
                                              __('Bottom Right','invio_framework' )   =>'bottom right',
                                              __('Center Left','invio_framework' )    =>'center left',
                                              __('Center Center','invio_framework' )  =>'center center',
                                              __('Center Right','invio_framework' )   =>'center right'
                                              )
                    ),

                   array(
                        "name"     => __("Background Repeat",'invio_framework' ),
                        "id"     => "background_repeat",
                        "type"     => "select",
                        "std"     => "no-repeat",
                        "required" => array('src','not',''),
                        "subtype" => array(   __('No Repeat','invio_framework' )          =>'no-repeat',
                                              __('Repeat','invio_framework' )             =>'repeat',
                                              __('Tile Horizontally','invio_framework' )  =>'repeat-x',
                                              __('Tile Vertically','invio_framework' )    =>'repeat-y',
                                              __('Stretch to fit (stretches image to cover the element)','invio_framework' )     =>'stretch',
                                              __('Scale to fit (scales image so the whole image is always visible)','invio_framework' )     =>'contain'
                                              )
                  ),
                  
                 array(
                            "type"     => "close_div",
                            'nodescription' => true
                        ), 
                  
                  array(
                        "type"     => "tab",
                        "name"  => __("Mobile" , 'invio_framework'),
                        'nodescription' => true
                    ),
                
                
                array(    
                        "name"     => __("Mobile display", 'invio_framework' ),
                        "desc"     => __("Display settings for this element when viewed on smaller screens", 'invio_framework' ),
                        "id"     => "mobile_display",
                        "type"     => "select",
                        "std"     => "",
                        "subtype" => array(    
                                __('Always display','invio_framework' ) =>'',
                                //__('Hide on tablet and smaller devices',  'invio_framework' ) =>'invio-hide-on-tablet',
                                __('Hide on mobile devices',  'invio_framework' ) =>'invio-hide-on-mobile',
                                    )
                    ),
                
                
                array(
                            "type"     => "close_div",
                            'nodescription' => true
                        ),
                  
                 array(
                            "type"     => "close_div",
                            'nodescription' => true
                        ), 
                    
                    
                    
                );
            }
            
            

            /**
             * Frontend Shortcode Handler
             *
             * @param array $atts array of attributes
             * @param string $content text within enclosing form of shortcode element
             * @param string $shortcodename the shortcode found, when == callback name
             * @return string $output returns the modified html string
             */
            function shortcode_handler($atts, $content = "", $shortcodename = "", $meta = "")
            {
                global $invio_config;
                
                $atts = shortcode_atts(array(
                    'vertical_align'        => '',
                    'padding'                => '',
                    'color'                    => '',
                    'background_color'        => '',
                    'background_position'     => '',
                    'background_repeat'     => '',
                    'background_attachment' => '',
                    'fetch_image'            => '',
                    'attachment_size'        => '',
                    'attachment'            => '',
                    'mobile_display'        => ''
                
                ), $atts, $this->config['shortcode']);
                
                $extraClass     = "";
                $outer_style = "";
                $inner_style = "";
                
                if(!empty(invio_sc_cell::$attr['min_height']))
                {
                    $min = (int) invio_sc_cell::$attr['min_height'];
                    $outer_style = "height:{$min}px; min-height:{$min}px;";
                }
                
                if(!empty($atts['attachment']))
                {
                    $src = wp_get_attachment_image_src($atts['attachment'], $atts['attachment_size']);
                    if(!empty($src[0])) $atts['fetch_image'] = $src[0];
                }
                
                if(!empty($atts['color']))
                {
                    $extraClass .= " invio_inherit_color";
                }
                
                if($atts['background_repeat'] == "stretch")
                {
                    $extraClass .= " invio-full-stretch";
                    $atts['background_repeat'] = "no-repeat";
                }
                
                if($atts['background_repeat'] == "contain")
                {
                    $extraClass .= " invio-full-contain";
                    $atts['background_repeat'] = "no-repeat";
                }

                
                
                $explode_padding = explode(',',$atts['padding']);
                if(count($explode_padding) > 1)
                {
                    $atts['padding'] = "";
                    foreach($explode_padding as $value)
                    {
                        if(empty($value)) $value = "0";
                        $atts['padding'] .= $value ." ";
                    }
                }
                
                if($atts['padding'] == "0px" || $atts['padding'] == "0" || $atts['padding'] == "0%")
                {
                    $extraClass .= " invio-zero-padding";
                }
                
                
                if(!empty($atts['fetch_image']))
                {
                    $outer_style .= InvioHelper::style_string($atts, 'fetch_image', 'background-image');
                    $outer_style .= InvioHelper::style_string($atts, 'background_position', 'background-position');
                    $outer_style .= InvioHelper::style_string($atts, 'background_repeat', 'background-repeat');
                    $outer_style .= InvioHelper::style_string($atts, 'background_attachment', 'background-attachment');
                }
                
                $outer_style .= InvioHelper::style_string($atts, 'vertical_align', 'vertical-align');
                $outer_style .= InvioHelper::style_string($atts, 'padding');
                $outer_style .= InvioHelper::style_string($atts, 'background_color', 'background-color');
                
                
                $shortcodename = str_replace('invio_cell_', 'invio_', $shortcodename);
                
                $invio_config['current_column'] = $shortcodename;
                
                if(!empty($outer_style)) $outer_style = "style='".$outer_style."'";
                if(!empty($inner_style)) $inner_style = "style='".$inner_style."'";
                
                $extraClass .= empty($atts['mobile_display']) ? "" : " ".$atts['mobile_display']." ";
                
                $output   = '<div class="flex_cell no_margin '.$shortcodename.' '.$meta['el_class'].' '.$extraClass.' '.invio_sc_cell::$extraClass.'" '.$outer_style.'>';
                $output  .= "<div class='flex_cell_inner' {$inner_style}>";
                //if the user uses the column shortcode without the layout builder make sure that paragraphs are applied to the text
                $content =  (empty($invio_config['conditionals']['is_builder_template'])) ? ShortcodeHelper::invio_apply_autop(ShortcodeHelper::invio_remove_autop($content)) : ShortcodeHelper::invio_remove_autop($content, true);
        
                $output .= $content.'</div>';
                $output .= '</div>';
                
                unset($invio_config['current_column']);

                return $output;
            }
            
    }
}









if ( !class_exists( 'invio_sc_cell_one_half' ) )
{
    class invio_sc_cell_one_half extends invio_sc_cell{

            function shortcode_insert_button()
            {
                $this->config['invisible'] = true;
                $this->config['name']        = '1/2';
                $this->config['icon']        = InvioBuilder::$path['imagesURL']."sc-half.png";
                $this->config['tab']        = __('Layout Elements', 'invio_framework' );
                $this->config['order']        = 90;
                $this->config['target']        = "invio-section-drop";
                $this->config['shortcode']     = 'invio_cell_one_half';
                $this->config['html_renderer']     = false;
                $this->config['tinyMCE']     = array('disable' => "true");
                $this->config['tooltip']     = __('Creates a single column with 50&percnt; width', 'invio_framework' );
                $this->config['drag-level'] = 2;
                $this->config['drop-level'] = 1;
        }
    }
}


if ( !class_exists( 'invio_sc_cell_one_third' ) )
{
    class invio_sc_cell_one_third extends invio_sc_cell{

            function shortcode_insert_button()
            {
                $this->config['invisible'] = true;
                $this->config['name']        = '1/3';
                $this->config['icon']        = InvioBuilder::$path['imagesURL']."sc-third.png";
                $this->config['tab']        = __('Layout Elements', 'invio_framework' );
                $this->config['order']        = 80;
                $this->config['target']        = "invio-section-drop";
                $this->config['shortcode']     = 'invio_cell_one_third';
                $this->config['html_renderer']     = false;
                $this->config['tooltip']     = __('Creates a single column with 33&percnt; width', 'invio_framework' );
                $this->config['drag-level'] = 2;
                $this->config['drop-level'] = 1;
                $this->config['tinyMCE']     = array('disable' => "true");
            }
    }
}

if ( !class_exists( 'invio_sc_cell_two_third' ) )
{
    class invio_sc_cell_two_third extends invio_sc_cell{

            function shortcode_insert_button()
            {
                $this->config['invisible'] = true;
                $this->config['name']        = '2/3';
                $this->config['icon']        = InvioBuilder::$path['imagesURL']."sc-two_third.png";
                $this->config['tab']        = __('Layout Elements', 'invio_framework' );
                $this->config['order']        = 70;
                $this->config['target']        = "invio-section-drop";
                $this->config['shortcode']     = 'invio_cell_two_third';
                $this->config['html_renderer']     = false;
                $this->config['tooltip']     = __('Creates a single column with 67&percnt; width', 'invio_framework' );
                $this->config['drag-level'] = 2;
                $this->config['drop-level'] = 1;
                $this->config['tinyMCE']     = array('disable' => "true");
            }
    }
}

if ( !class_exists( 'invio_sc_cell_one_fourth' ) )
{
    class invio_sc_cell_one_fourth extends invio_sc_cell{

            function shortcode_insert_button()
            {
                $this->config['invisible'] = true;
                $this->config['name']        = '1/4';
                $this->config['icon']        = InvioBuilder::$path['imagesURL']."sc-fourth.png";
                $this->config['tab']        = __('Layout Elements', 'invio_framework' );
                $this->config['order']        = 60;
                $this->config['target']        = "invio-section-drop";
                $this->config['shortcode']     = 'invio_cell_one_fourth';
                $this->config['tooltip']     = __('Creates a single column with 25&percnt; width', 'invio_framework' );
                $this->config['html_renderer']     = false;
                $this->config['drag-level'] = 2;
                $this->config['drop-level'] = 1;
                $this->config['tinyMCE']     = array('disable' => "true");
            }
    }
}

if ( !class_exists( 'invio_sc_cell_three_fourth' ) )
{
    class invio_sc_cell_three_fourth extends invio_sc_cell{

            function shortcode_insert_button()
            {
                $this->config['invisible'] = true;
                $this->config['name']        = '3/4';
                $this->config['icon']        = InvioBuilder::$path['imagesURL']."sc-three_fourth.png";
                $this->config['tab']        = __('Layout Elements', 'invio_framework' );
                $this->config['order']        = 50;
                $this->config['target']        = "invio-section-drop";
                $this->config['shortcode']     = 'invio_cell_three_fourth';
                $this->config['tooltip']     = __('Creates a single column with 75&percnt; width', 'invio_framework' );
                $this->config['html_renderer']     = false;
                $this->config['drag-level'] = 2;
                $this->config['drop-level'] = 1;
                $this->config['tinyMCE']     = array('disable' => "true");
            }
    }
}

if ( !class_exists( 'invio_sc_cell_one_fifth' ) )
{
    class invio_sc_cell_one_fifth extends invio_sc_cell{

            function shortcode_insert_button()
            {
                $this->config['invisible'] = true;
                $this->config['name']        = '1/5';
                $this->config['icon']        = InvioBuilder::$path['imagesURL']."sc-fifth.png";
                $this->config['tab']        = __('Layout Elements', 'invio_framework' );
                $this->config['order']        = 40;
                $this->config['target']        = "invio-section-drop";
                $this->config['shortcode']     = 'invio_cell_one_fifth';
                $this->config['html_renderer']     = false;
                $this->config['tooltip']     = __('Creates a single column with 20&percnt; width', 'invio_framework' );
                $this->config['drag-level'] = 2;
                $this->config['drop-level'] = 1;
                $this->config['tinyMCE']     = array('disable' => "true");
            }
    }
}

if ( !class_exists( 'invio_sc_cell_two_fifth' ) )
{
    class invio_sc_cell_two_fifth extends invio_sc_cell{

            function shortcode_insert_button()
            {
                $this->config['invisible'] = true;
                $this->config['name']        = '2/5';
                $this->config['icon']        = InvioBuilder::$path['imagesURL']."sc-two_fifth.png";
                $this->config['tab']        = __('Layout Elements', 'invio_framework' );
                $this->config['order']        = 39;
                $this->config['target']        = "invio-section-drop";
                $this->config['shortcode']     = 'invio_cell_two_fifth';
                $this->config['html_renderer']     = false;
                $this->config['tooltip']     = __('Creates a single column with 40&percnt; width', 'invio_framework' );
                $this->config['drag-level'] = 2;
                $this->config['drop-level'] = 1;
                $this->config['tinyMCE']     = array('disable' => "true");
            }
    }
}

if ( !class_exists( 'invio_sc_cell_three_fifth' ) )
{
    class invio_sc_cell_three_fifth extends invio_sc_cell{

            function shortcode_insert_button()
            {
                $this->config['invisible'] = true;
                $this->config['name']        = '3/5';
                $this->config['icon']        = InvioBuilder::$path['imagesURL']."sc-three_fifth.png";
                $this->config['tab']        = __('Layout Elements', 'invio_framework' );
                $this->config['order']        = 38;
                $this->config['target']        = "invio-section-drop";
                $this->config['shortcode']     = 'invio_cell_three_fifth';
                $this->config['html_renderer']     = false;
                $this->config['tooltip']     = __('Creates a single column with 60&percnt; width', 'invio_framework' );
                $this->config['drag-level'] = 2;
                $this->config['drop-level'] = 1;
                $this->config['tinyMCE']     = array('disable' => "true");
            }
    }
}

if ( !class_exists( 'invio_sc_cell_four_fifth' ) )
{
    class invio_sc_cell_four_fifth extends invio_sc_cell{

            function shortcode_insert_button()
            {
                $this->config['invisible'] = true;
                $this->config['name']        = '4/5';
                $this->config['icon']        = InvioBuilder::$path['imagesURL']."sc-four_fifth.png";
                $this->config['tab']        = __('Layout Elements', 'invio_framework' );
                $this->config['order']        = 37;
                $this->config['target']        = "invio-section-drop";
                $this->config['shortcode']     = 'invio_cell_four_fifth';
                $this->config['html_renderer']     = false;
                $this->config['tooltip']     = __('Creates a single column with 80&percnt; width', 'invio_framework' );
                $this->config['drag-level'] = 2;
                $this->config['drop-level'] = 1;
                $this->config['tinyMCE']     = array('disable' => "true");
            }
    }
}


