<?php
/**
 * Post/Page Content
 *
 * Element is in Beta and by default disabled. Todo: test with layerslider elements. currently throws error bc layerslider is only included if layerslider element is detected which is not the case with the post/page element
 */

if( !class_exists( 'woocommerce' ) )
{
    add_shortcode('invio_productslider', 'invio_please_install_woo');
    return;
}


if ( !class_exists( 'invio_sc_productslider' )  && class_exists( 'woocommerce' ) )
{
    class invio_sc_productslider extends invioShortcodeTemplate
    {

        /**
         * Create the config array for the shortcode button
         */
        function shortcode_insert_button()
        {
            $this->config['name']        = __('Product Slider', 'invio_framework' );
            $this->config['tab']        = __('Plugin Additions', 'invio_framework' );
            $this->config['icon']        = InvioBuilder::$path['imagesURL']."sc-postslider.png";
            $this->config['order']        = 30;
            $this->config['target']        = 'invio-target-insert';
            $this->config['shortcode']     = 'invio_productslider';
            $this->config['tooltip']     = __('Display a Slideshow of Product Entries', 'invio_framework' );
            $this->config['drag-level'] = 3;
        }

        /**
         * Popup Elements
         *
         * If this function is defined in a child class the element automatically gets an edit button, that, when pressed
         * opens a modal window that allows to edit the element properties
         *
         * @return void
         */
        function popup_elements()
        {
            $this->elements = array(

                array(
                        "name"     => __("Which Entries?", 'invio_framework' ),
                        "desc"     => __("Select which entries should be displayed by selecting a taxonomy", 'invio_framework' ),
                        "id"     => "categories",
                        "type"     => "select",
                        "taxonomy" => "product_cat",
                        "subtype" => "cat",
                        "multiple"    => 6
                ),

                array(
                        "name"     => __("Columns", 'invio_framework' ),
                        "desc"     => __("How many columns should be displayed?", 'invio_framework' ),
                        "id"     => "columns",
                        "type"     => "select",
                        "std"     => "3",
                        "subtype" => array(    __('2 Columns', 'invio_framework' )=>'2',
                                            __('3 Columns', 'invio_framework' )=>'3',
                                            __('4 Columns', 'invio_framework' )=>'4',
                                            __('5 Columns', 'invio_framework' )=>'5',
                                            )),
                array(
                        "name"     => __("Entry Number", 'invio_framework' ),
                        "desc"     => __("How many items should be displayed?", 'invio_framework' ),
                        "id"     => "items",
                        "type"     => "select",
                        "std"     => "9",
                        "subtype" => InvioHtmlHelper::number_array(1,100,1, array('All'=>'-1'))),

                array(
                    "name"     => __("Offset Number", 'invio_framework' ),
                    "desc"     => __("The offset determines where the query begins pulling products. Useful if you want to remove a certain number of products because you already query them with another product slider. Attention: Use this option only if the product sorting of the product sliders match!", 'invio_framework' ),
                    "id"     => "offset",
                    "type"     => "select",
                    "std"     => "0",
                    "subtype" => InvioHtmlHelper::number_array(1,100,1, array(__('Deactivate offset','invio_framework')=>'0', __('Do not allow duplicate posts on the entire page (set offset automatically)', 'invio_framework' ) =>'no_duplicates'))),


                array(
                        "name"     => __("Sorting Options", 'invio_framework' ),
                        "desc"     => __("Here you can choose how to sort the products", 'invio_framework' ),
                        "id"     => "sort",
                        "type"     => "select",
                        "std"     => "0",
                        "no_first"=>true,
                        "subtype" => array( /*__('Let user pick by displaying a dropdown with sort options (default value is defined at Woocommerce -> Settings -> Catalog)', 'invio_framework' )=>'dropdown', */
                                            __('Use defaut (defined at Woocommerce -> Settings -> Catalog) ', 'invio_framework' ) =>'0',
                                            __('Sort alphabetically', 'invio_framework' ) =>'title',
                                            __('Sort by most recent', 'invio_framework' ) =>'date',
                                            __('Sort by price', 'invio_framework' ) =>'price',
                                            __('Sort by popularity', 'invio_framework' ) =>'popularity')),

                array(
                        "name"     => __("Autorotation active?",'invio_framework' ),
                        "desc"     => __("Check if the slideshow should rotate by default",'invio_framework' ),
                        "id"     => "autoplay",
                        "type"     => "select",
                        "std"     => "no",
                        "subtype" => array(__('Yes','invio_framework' ) =>'yes',__('No','invio_framework' ) =>'no')),

                array(
                    "name"     => __("Slideshow autorotation duration",'invio_framework' ),
                    "desc"     => __("Slideshow will rotate every X seconds",'invio_framework' ),
                    "id"     => "interval",
                    "type"     => "select",
                    "std"     => "5",
                    "required"     => array('autoplay','equals','yes'),
                    "subtype" =>
                    array('3'=>'3','4'=>'4','5'=>'5','6'=>'6','7'=>'7','8'=>'8','9'=>'9','10'=>'10','15'=>'15','20'=>'20','30'=>'30','40'=>'40','60'=>'60','100'=>'100')),


                );
        }

        /**
         * Editor Element - this function defines the visual appearance of an element on the InvioBuilder Canvas
         * Most common usage is to define some markup in the $params['innerHtml'] which is then inserted into the drag and drop container
         * Less often used: $params['data'] to add data attributes, $params['class'] to modify the className
         *
         *
         * @param array $params this array holds the default values for $content and $args.
         * @return $params the return array usually holds an innerHtml key that holds item specific markup.
         */
        function editor_element($params)
        {
            $params['innerHtml'] = "<img src='".$this->config['icon']."' title='".$this->config['name']."' />";
            $params['innerHtml'].= "<div class='invio-element-label'>".$this->config['name']."</div>";
            $params['content']      = NULL; //remove to allow content elements
            return $params;
        }



        /**
         * Frontend Shortcode Handler
         *
         * @param array $atts array of attributes
         * @param string $content text within enclosing form of shortcode element
         * @param string $shortcodename the shortcode found, when == callback name
         * @return string $output returns the modified html string
         */
        function shortcode_handler($atts, $content = "", $shortcodename = "", $meta = "")
        {
            $atts['class'] = $meta['el_class'];
            
            //fix for seo plugins which execute the do_shortcode() function before the WooCommerce plugin is loaded
            global $woocommerce;
            if(!is_object($woocommerce) || !is_object($woocommerce->query)) return;
            
            $slider = new invio_product_slider($atts);
            $slider->query_entries();
            
            return $slider->html();
        }

    }
}


if ( !class_exists( 'invio_product_slider' ) )
{
    class invio_product_slider
    {
        static  $slide = 0;
        protected $atts;
        protected $entries;

        function __construct($atts = array())
        {
            
            $this->atts = shortcode_atts(array(    'type'        => 'slider', // can also be used as grid
                                                'style'        => '', //no_margin
                                                 'columns'     => '4',
                                                 'items'     => '16',
                                                 'taxonomy'  => 'product_cat',
                                                 'post_type' => 'product',
                                                 'contents'     => 'excerpt',
                                                 'autoplay'  => 'no',
                                                'animation' => 'fade',
                                                'paginate'    => 'no',
                                                'interval'  => 5,
                                                'class'        => '',
                                                'sort'        => '',
                                                'offset' => 0,
                                                'link_behavior' => '',
                                                'show_images'    => 'yes',
                                                 'categories'=> array()
                                                 ), $atts, 'invio_productslider');
        }

        public function html()
        {
            global $woocommerce, $woocommerce_loop, $invio_config;
            $output = "";

            invio_post_slider::$slide ++;
            extract($this->atts);

            $extraClass         = 'first';
            $grid                 = 'one_third';
            $image_size         = 'portfolio';
            $post_loop_count     = 1;
            $loop_counter        = 1;
            $autoplay             = $autoplay == "no" ? false : true;
            $total                = $columns % 2 ? "odd" : "even";
            $woocommerce_loop['columns'] = $columns;

            switch($columns)
            {
                case "1": $grid = 'invio_fullwidth';  $image_size = 'large'; break;
                case "2": $grid = 'invio_one_half';   break;
                case "3": $grid = 'invio_one_third';  break;
                case "4": $grid = 'invio_one_fourth'; $image_size = 'portfolio_small'; break;
                case "5": $grid = 'invio_one_fifth';  $image_size = 'portfolio_small'; break;
            }


            $data = InvioHelper::create_data_string(array('autoplay'=>$autoplay, 'interval'=>$interval, 'animation' =>$animation, 'hoverpause'=>1));

                ob_start();

                if ( have_posts() ) :

                echo "<div {$data} class='template-shop invio-content-slider invio-content-{$type}-active invio-content-slider".invio_post_slider::$slide." invio-content-slider-{$total} {$class} shop_columns_{$columns}' >";

                if($sort == "dropdown") invio_woocommerce_frontend_search_params();

                echo     "<div class='invio-content-slider-inner'>";

                            if($type == 'grid') echo '<ul class="products">';

                            while ( have_posts() ) : the_post();
                            if($loop_counter == 1 && $type == 'slider') echo '<ul class="products slide-entry-wrap">';

                                woocommerce_get_template_part( 'content', 'product' );

                            $loop_counter ++;
                            $post_loop_count ++;

                            if($loop_counter > $columns)
                            {
                                $loop_counter = 1;
                            }

                            if($loop_counter == 1 && $type == 'slider')
                            {
                                echo '</ul>';
                            }

                            endwhile; // end of the loop.

                            if($loop_counter != 1 || $type == 'grid')
                            {
                                echo '</ul>';
                            }

                echo     "</div>";

                if($post_loop_count -1 > $columns && $type == 'slider')
                {
                    echo $this->slide_navigation_arrows();
                }

                echo "</div>";

                else :
                
                    if(function_exists('woocommerce_product_subcategories')) :
                    
                        if ( ! woocommerce_product_subcategories( array( 'before' => '<ul class="products">', 'after' => '</ul>' ) ) ) :
    
                            echo "<p>".__( 'No products found which match your selection.', 'woocommerce' )."</p>";
    
                         endif;
                    endif;
                endif;

            echo '<div class="clear"></div>';

            $products = ob_get_clean();
            $output .= $products;

            if($paginate == "yes" && $invio_pagination = invio_pagination('', 'nav')) $output .= "<div class='pagination-wrap pagination-slider'>{$invio_pagination}</div>";

            wp_reset_query();
            return $output;
        }
        
        
        public function html_list()
        {
            global $woocommerce, $invio_config, $wp_query;
            $output = "";

            invio_post_slider::$slide ++;
            extract($this->atts);

            $extraClass         = 'first';
            $grid                 = 'invio_fullwidth';
            $post_loop_count     = 0;
            $loop_counter        = 0;
            $total                = $columns % 2 ? "odd" : "even";
            $posts_per_col        = ceil($wp_query->post_count / $columns);

            switch($columns)
            {
                case "1": $grid = 'invio_fullwidth';  break;
                case "2": $grid = 'invio_one_half';   break;
                case "3": $grid = 'invio_one_third';  break;
                case "4": $grid = 'invio_one_fourth'; break;
                case "5": $grid = 'invio_one_fifth';  break;
            }

                ob_start();

                if ( have_posts() ) :
                
                while ( have_posts() ) : the_post();
                
                $post_loop_count ++;
                $loop_counter ++;
                if($loop_counter === 1)
                {
                    echo "<div class='{$grid} {$extraClass} flex_column invio-catalog-column'>";
                    echo "<div class='invio-catalog-container invio-catalog-container-woo' >";
                    echo "<ul class='invio-catalog-list'>";
                    $extraClass = "";
                }
                
                    global $product;
                    
                    $link     =     $product->add_to_cart_url();
                    $ajax_class = 'add_to_cart_button product_type_simple';
                    $text    = "";
                    $title     =     get_the_title();
                    $content =     get_the_excerpt();
                    $price =     $product->get_price_html();
                    $rel   = "";
                    
                    if(empty($link_behavior))
                    {
                        $cart_url = get_the_permalink();
                        $ajax_class = "";
                    }
                    else
                    {
                        $cart_url = $product->add_to_cart_url();
                        $ajax_class = $product->is_purchasable() ? "add_to_cart_button" : "";
                        $rel = $product->is_purchasable() ? "rel='nofollow'" : "";
                    }
                    
                    $image = get_the_post_thumbnail($product->id, 'square', array('class'=>"invio-catalog-image invio-cart-update-image invio-catalog-image-{$show_images}"));
                    
                    $text .= $image;
                    $text .= "<div class='invio-catalog-item-inner'>";
                    $text .= "<div class='invio-catalog-title-container'><div class='invio-catalog-title invio-cart-update-title'>{$title}</div><div class='invio-catalog-price invio-cart-update-price'>{$price}</div></div>";
                    $text .= "<div class='invio-catalog-content'>{$content}</div>";
                    $text .= "</div>";
                    
                    echo "<li>";
                    
                    //coppied from templates/loop/add-to-cart.php - class and rel attr changed, as well as text
                    
                    echo apply_filters( 'woocommerce_loop_add_to_cart_link',
                        sprintf( '<a %s href="%s" data-product_id="%s" data-product_sku="%s" class="invio-catalog-item %s product_type_%s">%s</a>',
                            $rel,
                            esc_url( $cart_url ),
                            esc_attr( $product->id ),
                            esc_attr( $product->get_sku() ),
                            $ajax_class,
                            esc_attr( $product->product_type ),
                            $text
                        ),
                    $product );
        
                    echo "</li>";
        
                if($loop_counter == $posts_per_col || $post_loop_count == $wp_query->post_count)
                {
                    echo "</ul>";
                    echo "</div>";
                    echo "</div>";
                    $loop_counter = 0;
                }    

                endwhile; // end of the loop.
                
                endif;

            $products = ob_get_clean();
            $output .= $products;

            if($paginate == "yes" && $invio_pagination = invio_pagination('', 'nav')) $output .= "<div class='pagination-wrap pagination-slider'>{$invio_pagination}</div>";

            wp_reset_query();
            return $output;
        }

        

        protected function slide_navigation_arrows()
        {
            $html  = "";
            $html .= "<div class='invio-slideshow-arrows invio-slideshow-controls'>";
            $html .=     "<a href='#prev' class='prev-slide' ".invio_icon_string('prev_big').">".__('Previous','invio_framework' )."</a>";
            $html .=     "<a href='#next' class='next-slide' ".invio_icon_string('next_big').">".__('Next','invio_framework' )."</a>";
            $html .= "</div>";

            return $html;
        }

        //fetch new entries
        public function query_entries($params = array())
        {
            global $woocommerce, $invio_config;

            $query = array();
            if(empty($params)) $params = $this->atts;

            if(!empty($params['categories']))
            {
                //get the product categories
                $terms     = explode(',', $params['categories']);
            }

            $page = get_query_var( 'paged' ) ? get_query_var( 'paged' ) : get_query_var( 'page' );
            if(!$page || $params['type'] == 'slider' || $params['paginate'] == 'no') $page = 1;
            
            
            //if we find no terms for the taxonomy fetch all taxonomy terms
            if(empty($terms[0]) || is_null($terms[0]) || $terms[0] === "null")
            {
                $terms = array();
                $allTax = get_terms( $params['taxonomy']);
                foreach($allTax as $tax)
                {
                    $terms[] = $tax->term_id;
                }
            }


            if($params['sort'] == 'dropdown')
            {
                $invio_config['woocommerce']['default_posts_per_page'] = $params['items'];
                $ordering     = $woocommerce->query->get_catalog_ordering_args();
                $order         = $ordering['order'];
                $orderBY     = $ordering['orderby'];

                if(!empty($invio_config['shop_overview_products_overwritten']))
                    $params['items'] = $invio_config['shop_overview_products'];

            }
            else
            {
                $invio_config['woocommerce']['disable_sorting_options'] = true;

                $order = "DESC";
                if(empty($params['sort']) || $params['sort'] == "0")
                {
                    $ordering     = $woocommerce->query->get_catalog_ordering_args();
                    $order         = $ordering['order'];
                    $orderBY     = $ordering['orderby'];
                }
                else
                {
                    $orderBY = $params['sort'];
                }

                if(!$orderBY) $orderBY = "menu_order";

                if($orderBY == 'price' || $orderBY == 'title'){ $order = "ASC"; }
            }


            if($params['offset'] == 'no_duplicates')
            {
                $params['offset'] = 0;
                $no_duplicates = true;
            }
            
            if( $params['offset'] == 0 )
            {
                $params['offset'] = false;
            }


            // Meta query
            $meta_query = array();
            $meta_query[] = $woocommerce->query->visibility_meta_query();
                $meta_query[] = $woocommerce->query->stock_status_meta_query();
            $meta_query   = array_filter( $meta_query );

            $ordering_args = $woocommerce->query->get_catalog_ordering_args( $orderBY, $order );
            
            
            
            
            $query = array(
                'post_type'        => $params['post_type'],
                'post_status'     => 'publish',
                'ignore_sticky_posts'    => 1,
                'paged'         => $page,
                        'offset'                => $params['offset'],
                        'post__not_in' => (!empty($no_duplicates)) ? $invio_config['posts_on_current_page'] : array(),
                        
                'posts_per_page'     => $params['items'],
                'orderby'         => $ordering_args['orderby'],
                'order'         => $ordering_args['order'],
                'meta_query'         => $meta_query
                                                );
            if(!empty($terms))
            {
                $query['tax_query'] =  array(     array(     'taxonomy'     => $params['taxonomy'],
                                                'field'     => 'id',
                                                'terms'     => $terms,
                                                'operator'     => 'IN')
                                                );
            }


            if ( isset( $ordering_args['meta_key'] ) ) {
                 $query['meta_key'] = $ordering_args['meta_key'];
             }

            $query = apply_filters('invio_product_slide_query', $query, $params);


            query_posts($query);
            
                remove_filter( 'posts_clauses', array( $woocommerce->query, 'order_by_popularity_post_clauses' ) );
            remove_filter( 'posts_clauses', array( $woocommerce->query, 'order_by_rating_post_clauses' ) );

            // store the queried post ids in
            if( have_posts() )
            {
                while( have_posts() )
                {
                    the_post();
                    $invio_config['posts_on_current_page'][] = get_the_ID();
                }
            }
        }
    }
}
