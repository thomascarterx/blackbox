<?php
/**
 * Slider
 * Shortcode that allows to slide some content
 */

if ( !class_exists( 'invio_sc_content_slider' ) )
{
  class invio_sc_content_slider extends invioShortcodeTemplate
  {
            /**
             * Create the config array for the shortcode button
             */
            function shortcode_insert_button()
            {
                $this->config['name']            = __('Content Slider', 'invio_framework' );
                $this->config['tab']            = __('Content Elements', 'invio_framework' );
                $this->config['icon']            = InvioBuilder::$path['imagesURL']."sc-contentslider.png";
                $this->config['order']            = 83;
                $this->config['target']            = 'invio-target-insert';
                $this->config['shortcode']         = 'invio_content_slider';
                $this->config['shortcode_nested'] = array('invio_content_slide');
                $this->config['tooltip']         = __('Display a content slider element', 'invio_framework' );
            }

            /**
             * Popup Elements
             *
             * If this function is defined in a child class the element automatically gets an edit button, that, when pressed
             * opens a modal window that allows to edit the element properties
             *
             * @return void
             */
            function popup_elements()
            {
                $this->elements = array(
                    
                    array(
                            "type"     => "tab_container", 'nodescription' => true
                        ),
                        
                    array(
                            "type"     => "tab",
                            "name"  => __("Content" , 'invio_framework'),
                            'nodescription' => true
                        ),

                    array(
                        "name" => __("Add/Edit Slides", 'invio_framework' ),
                        "desc" => __("Here you can add, remove and edit the slides you want to display.", 'invio_framework' ),
                        "type"             => "modal_group",
                        "id"             => "content",
                        "modal_title"     => __("Edit Form Element", 'invio_framework' ),
                        "std"            => array(
                            array('title'=>__('Slide 1', 'invio_framework' ), 'tags'=>''),
                            array('title'=>__('Slide 2', 'invio_framework' ), 'tags'=>''),

                        ),


                        'subelements'     => array(

                            array(
                                "name"     => __("Slide Title", 'invio_framework' ),
                                "desc"     => __("Enter the slide title here (Better keep it short)", 'invio_framework' ) ,
                                "id"     => "title",
                                "std"     => "Slide Title",
                                "type"     => "input"),


                            array(
                                "name"     => __("Title Link?", 'invio_framework' ),
                                "desc"     => __("Where should your title link to?", 'invio_framework' ),
                                "id"     => "link",
                                "type"     => "linkpicker",
                                "fetchTMPL"    => true,
                                "std"    => "",
                                "subtype" => array(
                                    __('No Link', 'invio_framework' ) =>'',
                                    __('Set Manually', 'invio_framework' ) =>'manually',
                                    __('Single Entry', 'invio_framework' ) =>'single',
                                    __('Taxonomy Overview Page',  'invio_framework' )=>'taxonomy',
                                ),
                                "std"     => ""),

                            array(
                                "name"     => __("Open in new window", 'invio_framework' ),
                                "desc"     => __("Do you want to open the link in a new window", 'invio_framework' ),
                                "id"     => "linktarget",
                                "required"     => array('link', 'not', ''),
                                "type"     => "select",
                                "std"     => "",
                                "subtype" => InvioHtmlHelper::linking_options()),   



                            array(
                                "name"     => __("Slide Content", 'invio_framework' ),
                                "desc"     => __("Enter some content here", 'invio_framework' ) ,
                                "id"     => "content",
                                "type"     => "tiny_mce",
                                "std"     => __("Slide Content goes here", 'invio_framework' ) ,
                            ),

                        )
                    ),

                    array(
                        "name"  => __("Heading", 'invio_framework' ),
                        "desc"  => __("Do you want to display a heading above the images?", 'invio_framework' ),
                        "id"    => "heading",
                        "type"  => "input",
                        "std"   => "",
                    ),

                    array(
                        "name"     => __("Columns", 'invio_framework' ),
                        "desc"     => __("How many Slide columns should be displayed?", 'invio_framework' ),
                        "id"     => "columns",
                        "type"     => "select",
                        "std"     => "1",
                        "subtype" => array(    __('1 Columns', 'invio_framework' )=>'1',
                            __('2 Columns', 'invio_framework' )=>'2',
                            __('3 Columns', 'invio_framework' )=>'3',
                            __('4 Columns', 'invio_framework' )=>'4',
                            __('5 Columns', 'invio_framework' )=>'5',
                            __('6 Columns', 'invio_framework' )=>'6'
                        )),


                    array(
                        "name"     => __("Transition", 'invio_framework' ),
                        "desc"     => __("Choose the transition for your content slider.", 'invio_framework' ),
                        "id"     => "animation",
                        "type"     => "select",
                        "std"     => "slide",
                        "subtype" => array(__('Slide','invio_framework' ) =>'slide',__('Fade','invio_framework' ) =>'fade'),
                    ),

                    array(
                        "name"     => __("Slider controls", 'invio_framework' ),
                        "desc"     => __("Do you want to display slider control buttons?", 'invio_framework' ),
                        "id"     => "navigation",
                        "type"     => "select",
                        "std"     => "arrows",
                        "subtype" => array(
                            __('Yes, display arrow control buttons','invio_framework' ) =>'arrows',
                            __('Yes, display dot control buttons','invio_framework' ) =>'dots',
                            __('No, do not display any control buttons','invio_framework' ) =>'no'),
                    ),


                    array(
                        "name"     => __("Autorotation active?",'invio_framework' ),
                        "desc"     => __("Check if the content slider should rotate by default",'invio_framework' ),
                        "id"     => "autoplay",
                        "type"     => "select",
                        "std"     => "false",
                        "subtype" => array(__('Yes','invio_framework' ) =>'true',__('No','invio_framework' ) =>'false')),

                    array(
                        "name"     => __("Slider autorotation duration",'invio_framework' ),
                        "desc"     => __("Images will be shown the selected amount of seconds.",'invio_framework' ),
                        "id"     => "interval",
                        "type"     => "select",
                        "std"     => "5",
                        "subtype" =>
                        array('3'=>'3','4'=>'4','5'=>'5','6'=>'6','7'=>'7','8'=>'8','9'=>'9','10'=>'10','15'=>'15','20'=>'20','30'=>'30','40'=>'40','60'=>'60','100'=>'100')
                        ),
                        
                    array(
                            "type"     => "close_div",
                            'nodescription' => true
                        ),
                    
                    array(
                            "type"     => "tab",
                            "name"    => __("Colors",'invio_framework' ),
                            'nodescription' => true
                        ),
                    
                    
                    array(
                            "name"     => __("Font Colors", 'invio_framework' ),
                            "desc"     => __("Either use the themes default colors or apply some custom ones", 'invio_framework' ),
                            "id"     => "font_color",
                            "type"     => "select",
                            "std"     => "",
                            "subtype" => array( __('Default', 'invio_framework' )=>'',
                                                __('Define Custom Colors', 'invio_framework' )=>'custom'),
                    ),
                    
                    array(    
                            "name"     => __("Custom Font Color", 'invio_framework' ),
                            "desc"     => __("Select a custom font color. Leave empty to use the default", 'invio_framework' ),
                            "id"     => "color",
                            "type"     => "colorpicker",
                            "std"     => "",
                            "container_class" => 'invio_half invio_half_first',
                            "required" => array('font_color','equals','custom')
                        ),    
                        
                    array(
                            "type"     => "close_div",
                            'nodescription' => true
                        ),
                        
                    array(
                            "type"     => "close_div",
                            'nodescription' => true
                        ),    
                        
                        
                        
                        
                        
                        );

            }

            /**
             * Editor Element - this function defines the visual appearance of an element on the InvioBuilder Canvas
             * Most common usage is to define some markup in the $params['innerHtml'] which is then inserted into the drag and drop container
             * Less often used: $params['data'] to add data attributes, $params['class'] to modify the className
             *
             *
             * @param array $params this array holds the default values for $content and $args.
             * @return $params the return array usually holds an innerHtml key that holds item specific markup.
             */
            function editor_element($params)
            {
                $heading  = "";
                $template = $this->update_template("heading", " - <strong>{{heading}}</strong>");
                if(!empty($params['args']['heading'])) $heading = "- <strong>".$params['args']['heading']."</strong>";

                $params['innerHtml'] = "<img src='".$this->config['icon']."' title='".$this->config['name']."' />";
                $params['innerHtml'].= "<div class='invio-element-label'>".$this->config['name']."</div>";
                $params['innerHtml'].= "<div class='invio-element-label' {$template}>".$heading."</div>";
                return $params;
            }

              /**
               * Editor Sub Element - this function defines the visual appearance of an element that is displayed within a modal window and on click opens its own modal window
               * Works in the same way as Editor Element
               * @param array $params this array holds the default values for $content and $args.
               * @return $params the return array usually holds an innerHtml key that holds item specific markup.
               */
              function editor_sub_element($params)
              {
                  $template = $this->update_template("title", "{{title}}");

                  $params['innerHtml']  = "";
                  $params['innerHtml'] .= "<div class='invio_title_container' {$template}>".$params['args']['title']."</div>";


                  return $params;
              }


            /**
             * Frontend Shortcode Handler
             *
             * @param array $atts array of attributes
             * @param string $content text within enclosing form of shortcode element
             * @param string $shortcodename the shortcode found, when == callback name
             * @return string $output returns the modified html string
             */
            function shortcode_handler($atts, $content = "", $shortcodename = "", $meta = "")
            {
            
                $atts = shortcode_atts(array(
                'type'          => 'slider',
                'autoplay'        => 'false',
                'animation'     => 'fade',
                'interval'        => 5,
                'navigation'    => 'arrows',
                'heading'        => '',
                'columns'       => 3,
                'handle'        => $shortcodename,
                'content'        => ShortcodeHelper::shortcode2array($content, 1),
                'class'            => $meta['el_class'],
                'custom_markup' => $meta['custom_markup'],
                'font_color'     => '',
                'color'         => '',
                'styling'        => ''
                
                ), $atts, $this->config['shortcode']);
                
                
                if($atts['font_color'] == "custom")
                {
                    $atts['class']    .= " invio_inherit_color";
                    $atts['styling']  .= !empty($atts['color']) ? " color:".$atts['color']."; " : "";
                    if($atts['styling']) $atts['styling'] = " style='".$atts['styling']."'" ;
                }
                
                
                $slider  = new invio_content_slider($atts);
                return $slider->html();
            }

    }
}









if ( !class_exists( 'invio_content_slider' ) )
{
    class invio_content_slider
    {
        static  $slider = 0;                 //slider count for the current page
        protected $config;                     //base config set on initialization

        function __construct($config)
        {
            global $invio_config;
            $output = "";

            $this->config = array_merge(array(
                'type'          => 'grid',
                'autoplay'        => 'false',
                'animation'     => 'fade',
                'handle'        => '',
                'heading'        => '',
                'navigation'    => 'arrows',
                'columns'       => 3,
                'interval'        => 5,
                'class'            => "",
                'custom_markup' => "",
                'css_id'        => "",
                'content'        => array(),
                'styling'        => ""
                ), $config);
        }


        public function html()
        {
            $output = "";
            $counter = 0;
            invio_content_slider::$slider++;
            if(empty($this->config['content'])) return $output;

            //$html .= empty($this->subslides) ? $this->default_slide() : $this->advanced_slide();

            extract($this->config);

            $extraClass         = 'first';
            $grid                 = 'one_third';
            $slide_loop_count     = 1;
            $loop_counter        = 1;
            $total                = $columns % 2 ? "odd" : "even";
            $heading             = !empty($this->config['heading']) ? '<h3>'.$this->config['heading'].'</h3>' : "&nbsp;";
            $slide_count = count($content);

            switch($columns)
            {
                case "1": $grid = 'invio_fullwidth'; break;
                case "2": $grid = 'invio_one_half'; break;
                case "3": $grid = 'invio_one_third'; break;
                case "4": $grid = 'invio_one_fourth'; break;
                case "5": $grid = 'invio_one_fifth'; break;
                case "6": $grid = 'invio_one_sixth'; break;
            }

            $data = InvioHelper::create_data_string(array('autoplay'=>$autoplay, 'interval'=>$interval, 'animation' => $animation, 'show_slide_delay'=>30));

            $thumb_fallback = "";
            $output .= "<div {$data} class='invio-content-slider-element-container invio-content-slider-element-{$type} invio-content-slider invio-smallarrow-slider invio-content-{$type}-active invio-content-slider".invio_content_slider::$slider." invio-content-slider-{$total} {$class}' {$styling}>";

                $heading_class = '';
                if($navigation == 'no') $heading_class .= ' no-content-slider-navigation ';
                if($heading == '&nbsp;') $heading_class .= ' no-content-slider-heading ';

                $output .= "<div class='invio-smallarrow-slider-heading $heading_class'>";
                $output .= "<div class='new-special-heading'>".$heading."</div>";



                if($slide_count > $columns && $type == 'slider' && $navigation != 'no')
                {
                    if($navigation == 'dots') $output .= $this->slide_navigation_dots();
                    if($navigation == 'arrows') $output .= $this->slide_navigation_arrows();
                }
                $output .= "</div>";


                $output .= "<div class='invio-content-slider-inner'>";

                foreach($content as $key => $value)
                {
                    $link = $linktarget = "";

                    extract($value['attr']);

                    $link = invioHelper::get_url($link);
                    $blank = (strpos($linktarget, '_blank') !== false || $linktarget == 'yes') ? ' target="_blank" ' : "";
                    $blank .= strpos($linktarget, 'nofollow') !== false ? ' rel="nofollow" ' : "";

                    $parity            = $loop_counter % 2 ? 'odd' : 'even';
                    $last           = $slide_count == $slide_loop_count ? " post-entry-last " : "";
                    $post_class     = "post-entry slide-entry-overview slide-loop-{$slide_loop_count} slide-parity-{$parity} {$last}";

                    if($loop_counter == 1) $output .= "<div class='slide-entry-wrap'>";

                    $markup = invio_markup_helper(array('context' => 'entry','echo'=>false, 'custom_markup'=>$custom_markup));
                    $output .= "<section class='slide-entry flex_column {$post_class} {$grid} {$extraClass}' $markup>";

                    $markup = invio_markup_helper(array('context' => 'entry_title','echo'=>false, 'custom_markup'=>$custom_markup));
                    $output .= !empty($title) ? "<h3 class='slide-entry-title entry-title' $markup>" : '';
                    $output .= (!empty($link) && !empty($title)) ? "<a href='{$link}' $blank title='".esc_attr($title)."'>".$title."</a>" : $title;
                    $output .= !empty($title) ? '</h3>' : '';

                    $markup = invio_markup_helper(array('context' => 'entry_content','echo'=>false, 'custom_markup'=>$custom_markup));
                    $output .= !empty($value['content']) ? "<div class='slide-entry-excerpt entry-content' $markup>".ShortcodeHelper::invio_apply_autop(ShortcodeHelper::invio_remove_autop($value['content']))."</div>" : "";

                    $output .= '</section>';

                    $loop_counter ++;
                    $slide_loop_count ++;
                    $extraClass = "";

                    if($loop_counter > $columns)
                    {
                        $loop_counter = 1;
                        $extraClass = 'first';
                    }

                    if($loop_counter == 1 || !empty($last))
                    {
                        $output .="</div>";
                    }
                }

                $output .= "</div>";

            $output .= "</div>";

            return $output;
        }


        protected function slide_navigation_arrows()
        {
            $html  = "";
            $html .= "<div class='invio-slideshow-arrows invio-slideshow-controls'>";
            $html .=     "<a href='#prev' class='prev-slide' ".invio_icon_string('prev_big').">".__('Previous','invio_framework' )."</a>";
            $html .=     "<a href='#next' class='next-slide' ".invio_icon_string('next_big').">".__('Next','invio_framework' )."</a>";
            $html .= "</div>";

            return $html;
        }


        protected function slide_navigation_dots()
        {
            $html   = "";
            $html  .= "<div class='invio-slideshow-dots invio-slideshow-controls'>";
            $active = "active";

            $entry_count = count($this->config['content']);
            $slidenumber = $entry_count / (int)$this->config['columns'];
            $slidenumber = $entry_count % (int)$this->config['columns'] ? ((int)$slidenumber + 1) : (int)$slidenumber;

            for($i = 1; $i <= $slidenumber; $i++)
            {
                $html .= "<a href='#{$i}' class='goto-slide {$active}' >{$i}</a>";
                $active = "";
            }

            $html .= "</div>";

            return $html;
        }
    }
}


