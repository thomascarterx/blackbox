<?php
/**
 * Textblock
 * Shortcode which creates a text element wrapped in a div
 */

if ( !class_exists( 'invio_sc_social_share' ) )
{
    class invio_sc_social_share extends invioShortcodeTemplate
    {
            /**
             * Create the config array for the shortcode button
             */
            function shortcode_insert_button()
            {
                $this->config['name']            = __('Social Share Buttons', 'invio_framework' );
                $this->config['tab']            = __('Content Elements', 'invio_framework' );
                $this->config['icon']            = InvioBuilder::$path['imagesURL']."sc-social.png";
                $this->config['order']            = 7;
                $this->config['target']            = 'invio-target-insert';
                $this->config['shortcode']         = 'invio_social_share';
                $this->config['tooltip']         = __('Creates one or more social share buttons ', 'invio_framework' );

            }

            /**
             * Popup Elements
             *
             * If this function is defined in a child class the element automatically gets an edit button, that, when pressed
             * opens a modal window that allows to edit the element properties
             *
             * @return void
             */
            function popup_elements()
            {
                $this->elements = array(
                    
                    array(
                            "name"  => __("Small title", 'invio_framework' ),
                            "desc"  => __("A small title above the buttons.", 'invio_framework' ),
                            "id"    => "title",
                            "type"     => "input",
                            "std"     => __("Share this entry",'invio_framework')
                    ),
                    
                    array(
                            "name"     => __("Style", 'invio_framework' ),
                            "desc"     => __("How to display the social sharing bar?", 'invio_framework' ),
                            "id"     => "style",
                            "type"     => "select",
                            "std"     => "",
                            "subtype" => array( __('Default with border', 'invio_framework' )=>'',
                                                __('Minimal', 'invio_framework' )=>'minimal'),
                    ),
                    
                    
                    array(
                            "name"     => __("Social Buttons", 'invio_framework' ),
                            "desc"     => __("Which Social Buttons do you want to display? Defaults are set in ", 'invio_framework' ).
                            "<a href='".admin_url('admin.php?page=invio#goto_blog')."'>".__('Blog Layout','invio_framework').
                            "</a>",
                            "id"     => "buttons",
                            "type"     => "select",
                            "std"     => "",
                            "subtype" => array( __('Use Defaults that are also used for your blog', 'invio_framework' )=>'',
                                                __('Use a custom set', 'invio_framework' )=>'custom'),
                    ),
                                        
                    
                    array(    
                            "name"     => __("Facebook link", 'invio_framework'),
                            "desc"     => __("Check to display", 'invio_framework'),
                            "id"     => "share_facebook",
                            "std"     => "",
                            "container_class" => 'invio_third invio_third_first',
                            "required" => array("buttons",'equals','custom'),
                            "type"     => "checkbox"),
                    
                    array(    
                            "name"     => __("Twitter link", 'invio_framework'),
                            "desc"     => __("Check to display", 'invio_framework'),
                            "id"     => "share_twitter",
                            "std"     => "",
                            "container_class" => 'invio_third ',
                            "required" => array("buttons",'equals','custom'),
                            "type"     => "checkbox"),
                            
                    array(    
                            "name"     => __("Pinterest link", 'invio_framework'),
                            "desc"     => __("Check to display", 'invio_framework'),
                            "id"     => "share_pinterest",
                            "std"     => "",
                            "container_class" => 'invio_third ',
                            "required" => array("buttons",'equals','custom'),
                            "type"     => "checkbox"),
                            
                    array(    
                            "name"     => __("Google Plus link", 'invio_framework'),
                            "desc"     => __("Check to display", 'invio_framework'),
                            "id"     => "share_gplus",
                            "std"     => "",
                            "container_class" => 'invio_third invio_third_first',
                            "required" => array("buttons",'equals','custom'),
                            "type"     => "checkbox"),
                    
                    array(    
                            "name"     => __("Reddit link", 'invio_framework'),
                            "desc"     => __("Check to display", 'invio_framework'),
                            "id"     => "share_reddit",
                            "std"     => "",
                            "container_class" => 'invio_third ',
                            "required" => array("buttons",'equals','custom'),
                            "type"     => "checkbox"),
                            
                    array(    
                            "name"     => __("Linkedin link", 'invio_framework'),
                            "desc"     => __("Check to display", 'invio_framework'),
                            "id"     => "share_linkedin",
                            "std"     => "",
                            "container_class" => 'invio_third ',
                            "required" => array("buttons",'equals','custom'),
                            "type"     => "checkbox"),
                            
                    array(    
                            "name"     => __("Tumblr link", 'invio_framework'),
                            "desc"     => __("Check to display", 'invio_framework'),
                            "id"     => "share_tumblr",
                            "std"     => "",
                            "container_class" => 'invio_third invio_third_first',
                            "required" => array("buttons",'equals','custom'),
                            "type"     => "checkbox"),
                    
                    array(    
                            "name"     => __("VK link", 'invio_framework'),
                            "desc"     => __("Check to display", 'invio_framework'),
                            "id"     => "share_vk",
                            "std"     => "",
                            "container_class" => 'invio_third ',
                            "required" => array("buttons",'equals','custom'),
                            "type"     => "checkbox"),
                            
                    array(    
                            "name"     => __("Email link", 'invio_framework'),
                            "desc"     => __("Check to display", 'invio_framework'),
                            "id"     => "share_mail",
                            "std"     => "",
                            "container_class" => 'invio_third ',
                            "required" => array("buttons",'equals','custom'),
                            "type"     => "checkbox"),
                    
                    
                    
                );

            }


            /**
             * Frontend Shortcode Handler
             *
             * @param array $atts array of attributes
             * @param string $content text within enclosing form of shortcode element
             * @param string $shortcodename the shortcode found, when == callback name
             * @return string $output returns the modified html string
             */
            function shortcode_handler($atts, $content = "", $shortcodename = "", $meta = "")
            {
                $atts = shortcode_atts(array( 
                
                'buttons' => "",
                'share_facebook' => '',
                'share_twitter' => '',
                'share_vk' => '',
                'share_tumblr' => '',
                'share_linkedin' => '',
                'share_pinterest' => '',
                'share_mail' => '',
                'share_gplus' => '',
                'share_reddit' => '',
                'title' => '',
                'style' => ''
                
                ), $atts, $this->config['shortcode']);
                
                extract($atts);
                $custom_class     = !empty($meta['custom_class']) ? $meta['custom_class'] : "";
                $custom_class  .= $meta['el_class'];
                if($style == 'minimal') $custom_class .= " invio-social-sharing-box-minimal";
                
                $output         = '';
                $args            = array();
                $options         = false;
                $echo             = false;
                
                if($buttons == "custom")
                {
                    foreach($atts as &$att)
                    {
                        if(empty($att)) $att = "disabled";
                    }
                    
                    $options = $atts;
                }
                
                
                $output .= "<div class='invio-social-sharing-box {$custom_class}'>";
                $output .= invio_social_share_links($args, $options, $title, $echo);
                $output .= "</div>";

                return $output;
            }

    }
}
