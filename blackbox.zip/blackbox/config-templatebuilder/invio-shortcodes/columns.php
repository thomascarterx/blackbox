<?php
/**
 * COLUMNS
 * Shortcode which creates columns for better content separation
 */

 // Don't load directly
if ( !defined('ABSPATH') ) { die('-1'); }



if ( !class_exists( 'invio_sc_columns' ) )
{
    class invio_sc_columns extends invioShortcodeTemplate{

            static $extraClass         = "";
            static $calculated_size = 0;
            static $first_atts  = array(); 
            static $size_array = array(    'invio_one_full'         => 1, 
                                        'invio_one_half'         => 0.5, 
                                        'invio_one_third'         => 0.33, 
                                        'invio_one_fourth'     => 0.25, 
                                        'invio_one_fifth'         => 0.2, 
                                        'invio_two_third'         => 0.66, 
                                        'invio_three_fourth'     => 0.75, 
                                        'invio_two_fifth'         => 0.4, 
                                        'invio_three_fifth'     => 0.6, 
                                        'invio_four_fifth'     => 0.8
                                    );

            /**
             * Create the config array for the shortcode button
             */
            function shortcode_insert_button()
            {
                $this->config['name']        = '1/1';
                $this->config['icon']        = InvioBuilder::$path['imagesURL']."sc-full.png";
                $this->config['tab']        = __('Layout Elements', 'invio_framework' );
                $this->config['order']        = 100;
                $this->config['target']        = "invio-section-drop";
                $this->config['shortcode']     = 'invio_one_full';
                $this->config['html_renderer']     = false;
                $this->config['tinyMCE']     = array('instantInsert' => "[invio_one_full first]Add Content here[/invio_one_full]");
                $this->config['tooltip']     = __('Creates a single full width column', 'invio_framework' );
                $this->config['drag-level'] = 2;
                $this->config['drop-level'] = 2;

            }
                

            /**
             * Editor Element - this function defines the visual appearance of an element on the InvioBuilder Canvas
             * Most common usage is to define some markup in the $params['innerHtml'] which is then inserted into the drag and drop container
             * Less often used: $params['data'] to add data attributes, $params['class'] to modify the className
             *
             *
             * @param array $params this array holds the default values for $content and $args.
             * @return $params the return array usually holds an innerHtml key that holds item specific markup.
             */

            function editor_element($params)
            {
                extract($params);
                
                $name         = $this->config['shortcode'];
                $drag         = $this->config['drag-level'];
                $drop         = $this->config['drop-level'];
                
                $size = array('invio_one_full' => '1/1', 'invio_one_half' => '1/2', 'invio_one_third' => '1/3', 'invio_one_fourth' => '1/4', 'invio_one_fifth' => '1/5', 'invio_two_third' => '2/3', 'invio_three_fourth' => '3/4', 'invio_two_fifth' => '2/5', 'invio_three_fifth' => '3/5', 'invio_four_fifth' => '4/5');
                
                
                $data['shortcodehandler']     = $this->config['shortcode'];
                $data['modal_title']         = __('Edit Column','invio_framework' );
                $data['modal_ajax_hook']     = $this->config['shortcode'];
                $data['dragdrop-level']        = $this->config['drag-level'];
                $data['allowed-shortcodes'] = $this->config['shortcode'];
                
                if(!empty($this->config['modal_on_load']))
                {
                    $data['modal_on_load']     = $this->config['modal_on_load'];
                }
    
                $dataString  = InvioHelper::create_data_string($data);
                
                
                
                $extraClass = isset($args[0]) ? $args[0] == 'first' ? ' invio-first-col' : "" : "";

                $output  = "<div class='invio_layout_column invio_layout_column_no_cell invio_pop_class invio-no-visual-updates ".$name.$extraClass." invio_drag' {$dataString} data-width='{$name}'>";
                $output .= "<div class='invio_sorthandle menu-item-handle'>";

                $output .= "<a class='invio-smaller invio-change-col-size' href='#smaller' title='".__('Decrease Column Size','invio_framework' )."'>-</a>";
                $output .= "<span class='invio-col-size'>".$size[$name]."</span>";
                $output .= "<a class='invio-bigger invio-change-col-size'  href='#bigger' title='".__('Increase Column Size','invio_framework' )."'>+</a>";
                $output .= "<a class='invio-delete'  href='#delete' title='".__('Delete Column','invio_framework' )."'>x</a>";
                $output .= "<a class='invio-save-element'  href='#save-element' title='".__('Save Element as Template','invio_framework' )."'>+</a>";
                //$output .= "<a class='invio-new-target'  href='#new-target' title='".__('Move Element','invio_framework' )."'>+</a>";
                $output .= "<a class='invio-clone'  href='#clone' title='".__('Clone Column','invio_framework' )."' >".__('Clone Column','invio_framework' )."</a>";
                if(!empty($this->config['popup_editor']))
                {
                    $output .= "    <a class='invio-edit-element'  href='#edit-element' title='".__('Edit Cell','invio_framework' )."'>edit</a>";
                }
                
                $output .= "</div>";
                $output .= "<div class='invio_inner_shortcode invio_connect_sort invio_drop ' data-dragdrop-level='{$drop}'>";
                $output .= "<textarea data-name='text-shortcode' cols='20' rows='4'>".ShortcodeHelper::create_shortcode_by_array($name, $content, $args)."</textarea>";
                if($content)
                {
                    $content = $this->builder->do_shortcode_backend($content);
                }
                $output .= $content;
                $output .= "</div></div>";

                return $output;
            }
            
            
            /**
             * Popup Elements
             *
             * If this function is defined in a child class the element automatically gets an edit button, that, when pressed
             * opens a modal window that allows to edit the element properties
             *
             * @return void
             */
            function popup_elements()
            {
                global  $invio_config;

                $this->elements = array(
                    
                    array( /*stores the "first" variable that removes margin from the first column*/
                    "id"    => 0,
                    "std"   => '',
                    "type"  => "hidden"),
                    
                    array(
                            "type"     => "tab_container", 'nodescription' => true
                        ),
                        
                    array(
                            "type"     => "tab",
                            "name"  => __("Row Settings" , 'invio_framework'),
                            'nodescription' => true,
                            
                        ),
                    
                    array(
                        "name"     => __("Row Settings",'invio_framework' ),
                        "desc"     => __("Row Settings apply to all columns in this row but can only be set in the first column", 'invio_framework' ),
                        "type"     => "heading",
                        "description_class" => "invio-builder-note invio-notice",
                        "required" => array('0','equals',''),
                        ),
                    
                    array(
                        "name"     => __("Row Settings",'invio_framework' ),
                        "desc"     => __("These setting apply to all columns in this row and can only be set in the first column.", 'invio_framework' )
                                 ."<br/><strong>"
                                 . __("Please note:", 'invio_framework' )
                                 ."</strong> "
                                 . __("If you move another column into first position you will need to re-apply these settings.", 'invio_framework' ),
                        "type"     => "heading",
                        "description_class" => "invio-builder-note invio-notice",
                        "required" => array('0','not',''),
                        ),
                    
                    array(
                        "name"     => __("Equal Height Columns",'invio_framework' ),
                        "desc"     => __("Columns in this row can either have a height based on their content or all be of equal height based on the largest column ", 'invio_framework' ),
                        "id"     => "min_height",
                        "type"     => "select",
                        "std"     => "",
                        "required" => array('0','not',''),
                        "subtype" => array(
                            __('Individual height','invio_framework' )=>'',
                            __('Equal height','invio_framework' ) =>'invio-equal-height-column',
                            )
                        ),
                    
                    array(
                        "name"     => __("Vertical Alignment",'invio_framework' ),
                        "desc"     => __("If a column is larger than its content, were do you want to align the content vertically?", 'invio_framework' ),
                        "id"     => "vertical_alignment",
                        "type"     => "select",
                        "std"     => "",
                        "required" => array('min_height','not',''),
                        "subtype" => array(
                            __('Top','invio_framework' )=>'invio-align-top',
                            __('Middle','invio_framework' ) =>'invio-align-middle',
                            __('Bottom','invio_framework' ) =>'invio-align-bottom',
                            )
                        ),
                    
                    array(
                        "name"     => __("Space between columns",'invio_framework' ),
                        "desc"     => __("You can remove the default space between columns here.", 'invio_framework' ),
                        "id"     => "space",
                        "type"     => "select",
                        "std"     => "",
                        "required" => array('0','not',''),
                        "subtype" => array(
                            __('Space between columns','invio_framework' )=>'',
                            __('No space between columns','invio_framework' ) =>'no_margin',
                            )
                        ),
                    
                    array(
                        "name"     => __("Custom top and bottom margin",'invio_framework' ),
                        "desc"     => __("If checked allows you to set a custom top and bottom margin. Otherwise the margin is calculated by the theme based on surrounding elements",'invio_framework' ),
                        "required" => array('0','not',''),
                        "id"     => "custom_margin",
                        "type"     => "checkbox",
                        "std"     => "",
                        ),
                    
                    array(    
                        "name"     => __("Custom top and bottom margin", 'invio_framework' ),
                        "desc"     => __("Set a custom top or bottom margin. Both pixel and &percnt; based values are accepted. eg: 30px, 5&percnt;", 'invio_framework' ),
                        "id"     => "margin",
                        "type"     => "multi_input",
                        "required" => array('custom_margin','not',''),
                        "std"     => "0px",
                        "sync"     => true,
                        "multi" => array(    'top'     => __('Margin-Top','invio_framework'), 
                                            'bottom'=> __('Margin-Bottom','invio_framework'),
                                            )
                        ),
                    
                    
                    array(
                            "type"     => "close_div",
                            'nodescription' => true
                        ),
                    array(
                            "type"     => "tab",
                            "name"  => __("Layout" , 'invio_framework'),
                            'nodescription' => true
                        ),
                    
                    
                    array(    
                            "name"     => __("Inner Padding", 'invio_framework' ),
                            "desc"     => __("Set the distance from the column content to the border here. Both pixel and &percnt; based values are accepted. eg: 30px, 5&percnt;", 'invio_framework' ),
                            "id"     => "padding",
                            "type"     => "multi_input",
                            "std"     => "0px",
                            "sync"     => true,
                            "multi" => array(    'top'     => __('Padding-Top','invio_framework'), 
                                                'right'    => __('Padding-Right','invio_framework'), 
                                                'bottom'=> __('Padding-Bottom','invio_framework'),
                                                'left'    => __('Padding-Left','invio_framework'), 
                                                )
                        ),
                    
                    
                    
                        
                            
                    
                    
                    
                    array(
                            "type"     => "close_div",
                            'nodescription' => true
                        ),
                    
                    array(
                            "type"     => "tab",
                            "name"    => __("Border" , 'invio_framework' ),
                            'nodescription' => true
                        ),
                    
                    
                    
                    array(
                        "name"     => __("Border",'invio_framework' ),
                        "desc"     => __("Set the border of the column here", 'invio_framework' ),
                        "id"     => "border",
                        "type"     => "select",
                        "std"     => "",
                        "subtype" => InvioHtmlHelper::number_array(1,40,1, array( __("None", 'invio_framework' )=>'') , 'px'),
                        ),
                        
                    array(    
                            "name"     => __("Border Color", 'invio_framework' ),
                            "desc"     => __("Set a border color for this column", 'invio_framework' ),
                            "id"     => "border_color",
                            "type"     => "colorpicker",
                            "rgba"     => true,
                            "required" => array('border','not',''),
                            "std"     => "",
                        ),
                        
                    array(    
                            "name"     => __("Border Radius", 'invio_framework' ),
                            "desc"     => __("Set the border radius of the column", 'invio_framework' ),
                            "id"     => "radius",
                            "type"     => "multi_input",
                            "std"     => "0px",
                            "sync"     => true,
                            "multi" => array(    'top'     => __('Top-Left-Radius','invio_framework'), 
                                                'right'    => __('Top-Right-Radius','invio_framework'), 
                                                'bottom'=> __('Bottom-Right-Radius','invio_framework'),
                                                'left'    => __('Bottom-Left-Radius','invio_framework'),
                                                )
                        ),
                    
                    
                    
                    array(
                            "type"     => "close_div",
                            'nodescription' => true
                        ),
                    
                    array(
                            "type"     => "tab",
                            "name"    => __("Colors" , 'invio_framework' ),
                            'nodescription' => true
                        ),
                    
                    
                    array(    
                            "name"     => __("Custom Background Color", 'invio_framework' ),
                            "desc"     => __("Select a custom background color for this cell here. Leave empty for default color", 'invio_framework' ),
                            "id"     => "background_color",
                            "type"     => "colorpicker",
                            "rgba"     => true,
                            "std"     => "",
                        ),
                        
                    array(
                            "name"     => __("Custom Background Image",'invio_framework' ),
                            "desc"     => __("Either upload a new, or choose an existing image from your media library. Leave empty if you don't want to use a background image ",'invio_framework' ),
                            "id"     => "src",
                            "type"     => "image",
                            "title" => __("Insert Image",'invio_framework' ),
                            "button" => __("Insert",'invio_framework' ),
                            "std"     => ""),
                    
                    /*
array(
                        "name"     => __("Background Attachment",'invio_framework' ),
                        "desc"     => __("Background can either scroll with the page or be fixed", 'invio_framework' ),
                        "id"     => "background_attachment",
                        "type"     => "select",
                        "std"     => "scroll",
                        "required" => array('src','not',''),
                        "subtype" => array(
                            __('Scroll','invio_framework' )=>'scroll',
                            __('Fixed','invio_framework' ) =>'fixed',
                            )
                        ),
*/
                    
                    array(
                        "name"     => __("Background Image Position",'invio_framework' ),
                        "id"     => "background_position",
                        "type"     => "select",
                        "std"     => "top left",
                        "required" => array('src','not',''),
                        "subtype" => array(   __('Top Left','invio_framework' )       =>'top left',
                                              __('Top Center','invio_framework' )     =>'top center',
                                              __('Top Right','invio_framework' )      =>'top right',
                                              __('Bottom Left','invio_framework' )    =>'bottom left',
                                              __('Bottom Center','invio_framework' )  =>'bottom center',
                                              __('Bottom Right','invio_framework' )   =>'bottom right',
                                              __('Center Left','invio_framework' )    =>'center left',
                                              __('Center Center','invio_framework' )  =>'center center',
                                              __('Center Right','invio_framework' )   =>'center right'
                                              )
                    ),

                   array(
                        "name"     => __("Background Repeat",'invio_framework' ),
                        "id"     => "background_repeat",
                        "type"     => "select",
                        "std"     => "no-repeat",
                        "required" => array('src','not',''),
                        "subtype" => array(   __('No Repeat','invio_framework' )          =>'no-repeat',
                                              __('Repeat','invio_framework' )             =>'repeat',
                                              __('Tile Horizontally','invio_framework' )  =>'repeat-x',
                                              __('Tile Vertically','invio_framework' )    =>'repeat-y',
                                              __('Stretch to fit (stretches image to cover the element)','invio_framework' )     =>'stretch',
                                              __('Scale to fit (scales image so the whole image is always visible)','invio_framework' )     =>'contain'
                                              )
                  ),
                  
                  
                array(
                            "type"     => "close_div",
                            'nodescription' => true
                ),
                    
                
                array(
                            "type"     => "tab",
                            "name"    => __("Animation" , 'invio_framework' ),
                            'nodescription' => true
                        ),
                        
                array(
                        "name"     => __("Animation",'invio_framework' ),
                            "desc"     => __("Set an animation for this element. The animation will be shown once the element appears first on screen. Animations only work in modern browsers and only on desktop computers to keep page rendering as fast as possible.",'invio_framework' ),
                        "id"     => "animation",
                        "type"     => "select",
                        "std"     => "",
                        "subtype" => array(
                            __('None',  'invio_framework' ) =>'',
                            
                            __('Fade Animations',  'invio_framework') => array(
                                __('Fade in',  'invio_framework' ) =>'fade-in',
                                __('Pop up',  'invio_framework' ) =>'pop-up',
                            ),
                            __('Slide Animations',  'invio_framework') => array(
                                __('Top to Bottom',  'invio_framework' ) =>'top-to-bottom',
                                __('Bottom to Top',  'invio_framework' ) =>'bottom-to-top',
                                __('Left to Right',  'invio_framework' ) =>'left-to-right',
                                __('Right to Left',  'invio_framework' ) =>'right-to-left',
                                ),
                            __('Rotate',  'invio_framework') => array(
                                __('Full rotation',  'invio_framework' ) =>'invio-rotateIn',
                                __('Bottom left rotation',  'invio_framework' ) =>'invio-rotateInUpLeft',
                                __('Bottom right rotation',  'invio_framework' ) =>'invio-rotateInUpRight',
                                )    
                                
                                
                                
                            )
                  ),        
                
                
                
                array(
                            "type"     => "close_div",
                            'nodescription' => true
                ),
                
                
                
                
                array(
                        "type"     => "tab",
                        "name"  => __("Mobile" , 'invio_framework'),
                        'nodescription' => true
                    ),
                
                
                array(    
                        "name"     => __("Mobile display", 'invio_framework' ),
                        "desc"     => __("Display settings for this element when viewed on smaller screens", 'invio_framework' ),
                        "id"     => "mobile_display",
                        "type"     => "select",
                        "std"     => "",
                        "subtype" => array(    
                                __('Always display','invio_framework' ) =>'',
                                //__('Hide on tablet and smaller devices',  'invio_framework' ) =>'invio-hide-on-tablet',
                                __('Hide on mobile devices',  'invio_framework' ) =>'invio-hide-on-mobile',
                                    )
                    ),
                
                
                array(
                            "type"     => "close_div",
                            'nodescription' => true
                        ),
                    
                array(
                            "type"     => "close_div",
                            'nodescription' => true
                ),
                    
                    
                    
                    
                );
            }
            
            
            
            

            /**
             * Frontend Shortcode Handler
             *
             * @param array $atts array of attributes
             * @param string $content text within enclosing form of shortcode element
             * @param string $shortcodename the shortcode found, when == callback name
             * @return string $output returns the modified html string
             */
            function shortcode_handler($atts, $content = "", $shortcodename = "", $meta = "")
            {
                global $invio_config;

                $invio_config['current_column'] = $shortcodename;


                $first = '';
                if (isset($atts[0]) && trim($atts[0]) == 'first')  $first = 'first';
                
                $atts = shortcode_atts(array(
                    'padding'                => '',
                    'background_color'        => '',
                    'background_position'     => '',
                    'background_repeat'     => '',
                    'background_attachment' => '',
                    'fetch_image'            => '',
                    'attachment_size'        => '',
                    'attachment'            => 'scroll',
                    'radius'                => '',
                    'space'                    => '',
                    'border'                => '',
                    'border_color'            => '',
                    'border_style'            => 'solid',
                    'margin'                => '',
                    'custom_margin'            => '',
                    'min_height'            => '',
                    'vertical_alignment'    => 'invio-align-top',
                    'animation'                => '',
                    'mobile_display'        => ''
                    
                
                ), $atts, $this->config['shortcode']);
                
                
                if($first)
                {
                    invio_sc_columns::$first_atts = $atts;
                }
                
                
                $extraClass     = "";
                $outer_style = "";
                $inner_style = "";
                $margin_style= "";
                $output         = "";
                $anim_class  = empty($atts['animation']) ? "" : " invio-animated-generic ".$atts['animation']." ";
                $extraClass .= $anim_class;
                $extraClass .= empty($atts['mobile_display']) ? "" : " ".$atts['mobile_display']." ";
                
            
                if(!empty($atts['attachment']))
                {
                    $src = wp_get_attachment_image_src($atts['attachment'], $atts['attachment_size']);
                    if(!empty($src[0])) $atts['fetch_image'] = $src[0];
                }
                
                if($atts['background_repeat'] == "stretch")
                {
                    $extraClass .= " invio-full-stretch";
                    $atts['background_repeat'] = "no-repeat";
                }
                
                if($atts['background_repeat'] == "contain")
                {
                    $extraClass .= " invio-full-contain";
                    $atts['background_repeat'] = "no-repeat";
                }
                
                if( !empty( invio_sc_columns::$first_atts['space'] ) )
                {
                    $extraClass .= " ".invio_sc_columns::$first_atts['space'];
                }
                
                if( !empty( invio_sc_columns::$first_atts['min_height'] ) )
                {
                    $extraClass .= " flex_column_table_cell";
                    $extraClass .= " ".invio_sc_columns::$first_atts['min_height']." ".invio_sc_columns::$first_atts['vertical_alignment'];
                }
                else
                {
                    $extraClass .= " flex_column_div";
                }
                
                if( !empty( invio_sc_columns::$first_atts['custom_margin'] ) )
                {
                    $explode_margin = explode(',',invio_sc_columns::$first_atts['margin']);
                    if(count($explode_margin) <= 1)
                    {
                        $explode_margin[1] = $explode_margin[0];
                    }
                    
                    $atts['margin-top'] = $explode_margin[0];
                    $atts['margin-bottom'] = $explode_margin[1];
                    
                    $margins = "";
                    $margins .= InvioHelper::style_string($atts, 'margin-top');
                    $margins .= InvioHelper::style_string($atts, 'margin-bottom');
                    
                    if( !empty( invio_sc_columns::$first_atts['min_height'] ) )
                    {
                        $margin_style = InvioHelper::style_string( $margins );
                    }
                    else
                    {
                        $outer_style .= $margins;
                    }
                }
                
                
                
                $explode_padding = explode(',',$atts['padding']);
                if(count($explode_padding) > 1)
                {
                    $atts['padding'] = "";
                    foreach($explode_padding as $value)
                    {
                        if(empty($value)) $value = "0";
                        $atts['padding'] .= $value ." ";
                    }
                }
                
                if($atts['padding'] == "0px" || $atts['padding'] == "0" || $atts['padding'] == "0%")
                {
                    $extraClass .= " invio-zero-column-padding";
                    $atts['padding'] = "";
                }
                
                
                $explode_radius = explode(',',$atts['radius']);
                if(count($explode_radius) > 1)
                {
                    $atts['radius'] = "";
                    foreach($explode_radius as $value)
                    {
                        if(empty($value)) $value = "0";
                        $atts['radius'] .= $value ." ";
                    }
                }
                
                if($atts['padding'] == "0px" || $atts['padding'] == "0" || $atts['padding'] == "0%")
                {
                    $extraClass .= " invio-zero-column-padding";
                    $atts['padding'] = "";
                }
                
                
                
                
                
                if(!empty($atts['fetch_image']))
                {
                    $outer_style .= InvioHelper::style_string($atts, 'fetch_image', 'background-image');
                    $outer_style .= InvioHelper::style_string($atts, 'background_position', 'background-position');
                    $outer_style .= InvioHelper::style_string($atts, 'background_repeat', 'background-repeat');
                    $outer_style .= InvioHelper::style_string($atts, 'background_attachment', 'background-attachment');
                }
                
                if(!empty($atts['border']))
                {
                    $outer_style .= InvioHelper::style_string($atts, 'border', 'border-width', 'px');
                    $outer_style .= InvioHelper::style_string($atts, 'border_color', 'border-color');
                    $outer_style .= InvioHelper::style_string($atts, 'border_style', 'border-style');
                }
                
                $outer_style .= InvioHelper::style_string($atts, 'padding');
                $outer_style .= InvioHelper::style_string($atts, 'background_color', 'background-color');
                $outer_style .= InvioHelper::style_string($atts, 'radius', 'border-radius');
                $outer_style  = InvioHelper::style_string($outer_style);
                
                
                
                
                if($first)
                {    
                    invio_sc_columns::$calculated_size = 0;
                    
                    if(!empty($meta['siblings']['prev']['tag']) &&
                    in_array($meta['siblings']['prev']['tag'], array('invio_one_full','invio_one_half', 'invio_one_third', 'invio_two_third', 'invio_three_fourth' , 'invio_one_fourth' , 'invio_one_fifth' ,'invio_textblock')))
                    {
                        invio_sc_columns::$extraClass = "column-top-margin";
                    }
                    else
                    {
                        invio_sc_columns::$extraClass = "";
                    }
                }
                
                
                

                if(!empty( invio_sc_columns::$first_atts['min_height'] ) && invio_sc_columns::$calculated_size == 0)
                {
                    $output .= "<div class='flex_column_table ".invio_sc_columns::$first_atts['min_height']."-flextable' {$margin_style}>";
                }    
                
                if(!$first && empty( invio_sc_columns::$first_atts['space'] ) && !empty( invio_sc_columns::$first_atts['min_height'] ))
                {
                    $output .= "<div class='invio-flex-placeholder'></div>";
                }
                
                invio_sc_columns::$calculated_size += invio_sc_columns::$size_array[ $this->config['shortcode'] ];
                
                $output  .= '<div class="flex_column '.$shortcodename.' '.$extraClass.' '.$first.' '.$meta['el_class'].' '.invio_sc_columns::$extraClass.'" '.$outer_style.'>';
            
                //if the user uses the column shortcode without the layout builder make sure that paragraphs are applied to the text
                $content =  (empty($invio_config['conditionals']['is_builder_template'])) ? ShortcodeHelper::invio_apply_autop(ShortcodeHelper::invio_remove_autop($content)) : ShortcodeHelper::invio_remove_autop($content, true);

                $output .= trim($content).'</div>';
                
                
                
                $force_close = false;
                
                if( isset($meta['siblings']) && isset($meta['siblings']['next']) && isset( $meta['siblings']['next']['tag'] ) )
                {
                    if(!array_key_exists($meta['siblings']['next']['tag'], invio_sc_columns::$size_array))
                    {
                        $force_close = true;
                    }
                }
                
                
                if( !empty( invio_sc_columns::$first_atts['min_height']) && (invio_sc_columns::$calculated_size >= 0.95 || $force_close) )
                {
                    $output .= "</div><!--close column table wrapper. Autoclose: {$force_close} -->";
                    invio_sc_columns::$calculated_size = 0;
                }

                unset($invio_config['current_column']);

                return $output;
            }
    }
}









if ( !class_exists( 'invio_sc_columns_one_half' ) )
{
    class invio_sc_columns_one_half extends invio_sc_columns{

            function shortcode_insert_button()
            {
                $this->config['name']        = '1/2';
                $this->config['icon']        = InvioBuilder::$path['imagesURL']."sc-half.png";
                $this->config['tab']        = __('Layout Elements', 'invio_framework' );
                $this->config['order']        = 90;
                $this->config['target']        = "invio-section-drop";
                $this->config['shortcode']     = 'invio_one_half';
                $this->config['html_renderer']     = false;
                $this->config['tinyMCE']     = array('name' => '1/2 + 1/2', 'instantInsert' => "[invio_one_half first]Add Content here[/invio_one_half]\n\n\n[invio_one_half]Add Content here[/invio_one_half]");
                $this->config['tooltip']     = __('Creates a single column with 50&percnt; width', 'invio_framework' );
                $this->config['drag-level'] = 2;
                $this->config['drop-level'] = 2;
        }
    }
}


if ( !class_exists( 'invio_sc_columns_one_third' ) )
{
    class invio_sc_columns_one_third extends invio_sc_columns{

            function shortcode_insert_button()
            {
                $this->config['name']        = '1/3';
                $this->config['icon']        = InvioBuilder::$path['imagesURL']."sc-third.png";
                $this->config['tab']        = __('Layout Elements', 'invio_framework' );
                $this->config['order']        = 80;
                $this->config['target']        = "invio-section-drop";
                $this->config['shortcode']     = 'invio_one_third';
                $this->config['html_renderer']     = false;
                $this->config['tooltip']     = __('Creates a single column with 33&percnt; width', 'invio_framework' );
                $this->config['drag-level'] = 2;
                $this->config['drop-level'] = 2;
                $this->config['tinyMCE']     = array(
                      'name' => '1/3 + 1/3 + 1/3',
                    'instantInsert' => "[invio_one_third first]Add Content here[/invio_one_third]\n\n\n[invio_one_third]Add Content here[/invio_one_third]\n\n\n[invio_one_third]Add Content here[/invio_one_third]"
                                                    );
            }
    }
}

if ( !class_exists( 'invio_sc_columns_two_third' ) )
{
    class invio_sc_columns_two_third extends invio_sc_columns{

            function shortcode_insert_button()
            {
                $this->config['name']        = '2/3';
                $this->config['icon']        = InvioBuilder::$path['imagesURL']."sc-two_third.png";
                $this->config['tab']        = __('Layout Elements', 'invio_framework' );
                $this->config['order']        = 70;
                $this->config['target']        = "invio-section-drop";
                $this->config['shortcode']     = 'invio_two_third';
                $this->config['html_renderer']     = false;
                $this->config['tooltip']     = __('Creates a single column with 67&percnt; width', 'invio_framework' );
                $this->config['drag-level'] = 2;
                $this->config['drop-level'] = 2;
                $this->config['tinyMCE']     = array(
                    'name' => '2/3 + 1/3',
                    'instantInsert' => "[invio_two_third first]Add 2/3 Content here[/invio_two_third]\n\n\n[invio_one_third]Add 1/3 Content here[/invio_one_third]"
                                                    );
            }
    }
}

if ( !class_exists( 'invio_sc_columns_one_fourth' ) )
{
    class invio_sc_columns_one_fourth extends invio_sc_columns{

            function shortcode_insert_button()
            {
                $this->config['name']        = '1/4';
                $this->config['icon']        = InvioBuilder::$path['imagesURL']."sc-fourth.png";
                $this->config['tab']        = __('Layout Elements', 'invio_framework' );
                $this->config['order']        = 60;
                $this->config['target']        = "invio-section-drop";
                $this->config['shortcode']     = 'invio_one_fourth';
                $this->config['tooltip']     = __('Creates a single column with 25&percnt; width', 'invio_framework' );
                $this->config['html_renderer']     = false;
                $this->config['drag-level'] = 2;
                $this->config['drop-level'] = 2;
                $this->config['tinyMCE']     = array(
                    'name' => '1/4 + 1/4 + 1/4 + 1/4',
                    'instantInsert' => "[invio_one_fourth first]Add Content here[/invio_one_fourth]\n\n\n[invio_one_fourth]Add Content here[/invio_one_fourth]\n\n\n[invio_one_fourth]Add Content here[/invio_one_fourth]\n\n\n[invio_one_fourth]Add Content here[/invio_one_fourth]"
                                                    );
            }
    }
}

if ( !class_exists( 'invio_sc_columns_three_fourth' ) )
{
    class invio_sc_columns_three_fourth extends invio_sc_columns{

            function shortcode_insert_button()
            {
                $this->config['name']        = '3/4';
                $this->config['icon']        = InvioBuilder::$path['imagesURL']."sc-three_fourth.png";
                $this->config['tab']        = __('Layout Elements', 'invio_framework' );
                $this->config['order']        = 50;
                $this->config['target']        = "invio-section-drop";
                $this->config['shortcode']     = 'invio_three_fourth';
                $this->config['tooltip']     = __('Creates a single column with 75&percnt; width', 'invio_framework' );
                $this->config['html_renderer']     = false;
                $this->config['drag-level'] = 2;
                $this->config['drop-level'] = 2;
                $this->config['tinyMCE']     = array(
                    'name' => '3/4 + 1/4',
                    'instantInsert' => "[invio_three_fourth first]Add 3/4 Content here[/invio_three_fourth]\n\n\n[invio_one_fourth]Add 1/4 Content here[/invio_one_fourth]"
                                                    );
            }
    }
}

if ( !class_exists( 'invio_sc_columns_one_fifth' ) )
{
    class invio_sc_columns_one_fifth extends invio_sc_columns{

            function shortcode_insert_button()
            {
                $this->config['name']        = '1/5';
                $this->config['icon']        = InvioBuilder::$path['imagesURL']."sc-fifth.png";
                $this->config['tab']        = __('Layout Elements', 'invio_framework' );
                $this->config['order']        = 40;
                $this->config['target']        = "invio-section-drop";
                $this->config['shortcode']     = 'invio_one_fifth';
                $this->config['html_renderer']     = false;
                $this->config['tooltip']     = __('Creates a single column with 20&percnt; width', 'invio_framework' );
                $this->config['drag-level'] = 2;
                $this->config['drop-level'] = 2;
                $this->config['tinyMCE']     = array(
                    'name' => '1/5 + 1/5 + 1/5 + 1/5 + 1/5',
                    'instantInsert' => "[invio_one_fifth first]1/5[/invio_one_fifth]\n\n\n[invio_one_fifth]2/5[/invio_one_fifth]\n\n\n[invio_one_fifth]3/5[/invio_one_fifth]\n\n\n[invio_one_fifth]4/5[/invio_one_fifth]\n\n\n[invio_one_fifth]5/5[/invio_one_fifth]"
                                                    );
            }
    }
}

if ( !class_exists( 'invio_sc_columns_two_fifth' ) )
{
    class invio_sc_columns_two_fifth extends invio_sc_columns{

            function shortcode_insert_button()
            {
                $this->config['name']        = '2/5';
                $this->config['icon']        = InvioBuilder::$path['imagesURL']."sc-two_fifth.png";
                $this->config['tab']        = __('Layout Elements', 'invio_framework' );
                $this->config['order']        = 39;
                $this->config['target']        = "invio-section-drop";
                $this->config['shortcode']     = 'invio_two_fifth';
                $this->config['html_renderer']     = false;
                $this->config['tooltip']     = __('Creates a single column with 40&percnt; width', 'invio_framework' );
                $this->config['drag-level'] = 2;
                $this->config['drop-level'] = 2;
                $this->config['tinyMCE']     = array(
                    'name' => '2/5',
                    'instantInsert' => "[invio_two_fifth first]2/5[/invio_two_fifth]"
                                                    );
            }
    }
}

if ( !class_exists( 'invio_sc_columns_three_fifth' ) )
{
    class invio_sc_columns_three_fifth extends invio_sc_columns{

            function shortcode_insert_button()
            {
                $this->config['name']        = '3/5';
                $this->config['icon']        = InvioBuilder::$path['imagesURL']."sc-three_fifth.png";
                $this->config['tab']        = __('Layout Elements', 'invio_framework' );
                $this->config['order']        = 38;
                $this->config['target']        = "invio-section-drop";
                $this->config['shortcode']     = 'invio_three_fifth';
                $this->config['html_renderer']     = false;
                $this->config['tooltip']     = __('Creates a single column with 60&percnt; width', 'invio_framework' );
                $this->config['drag-level'] = 2;
                $this->config['drop-level'] = 2;
                $this->config['tinyMCE']     = array(
                    'name' => '3/5',
                    'instantInsert' => "[invio_three_fifth first]3/5[/invio_three_fifth]"
                                                    );
            }
    }
}

if ( !class_exists( 'invio_sc_columns_four_fifth' ) )
{
    class invio_sc_columns_four_fifth extends invio_sc_columns{

            function shortcode_insert_button()
            {
                $this->config['name']        = '4/5';
                $this->config['icon']        = InvioBuilder::$path['imagesURL']."sc-four_fifth.png";
                $this->config['tab']        = __('Layout Elements', 'invio_framework' );
                $this->config['order']        = 37;
                $this->config['target']        = "invio-section-drop";
                $this->config['shortcode']     = 'invio_four_fifth';
                $this->config['html_renderer']     = false;
                $this->config['tooltip']     = __('Creates a single column with 80&percnt; width', 'invio_framework' );
                $this->config['drag-level'] = 2;
                $this->config['drop-level'] = 2;
                $this->config['tinyMCE']     = array(
                    'name' => '4/5',
                    'instantInsert' => "[invio_four_fifth first]4/5[/invio_four_fifth]"
                                                    );
            }
    }
}


