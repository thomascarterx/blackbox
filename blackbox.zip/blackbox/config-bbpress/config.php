<?php


function invio_bbpress_enabled()
{
    if (class_exists( 'bbPress' )) { return true; }
    return false;
}

//check if the plugin is enabled, otherwise stop the script
if(!invio_bbpress_enabled()) { return false; }


global $invio_config;


//register my own styles
add_filter('bbp_default_styles', 'invio_bbpress_deregister_default_assets', 10, 1);
function invio_bbpress_deregister_default_assets($styles)
{
    return array();
}

if(!is_admin()){ add_action('bbp_enqueue_scripts', 'invio_bbpress_register_assets',15); }

function invio_bbpress_register_assets()
{
    global $bbp;
    wp_enqueue_style( 'invio-bbpress', INVIO_BASE_URL.'config-bbpress/bbpress-mod.css');
}



//add classnames to topic class for even nicer icon display
add_filter('bbp_get_topic_class', 'invio_bbpress_add_topic_class');
function invio_bbpress_add_topic_class($classes)
{
    $voices = bbp_get_topic_voice_count() > 1 ? "multi" : "single";

    $classes[] = 'topic-voices-'.$voices;
    return $classes;
}



//remove forum and single topic summaries at the top of the page
add_filter('bbp_get_single_forum_description', 'invio_bbpress_filter_form_message',10,2 );
add_filter('bbp_get_single_topic_description', 'invio_bbpress_filter_form_message',10,2 );



add_filter('invio_style_filter', 'invio_bbpress_forum_colors');
/* add some color modifications to the forum table items */
function invio_bbpress_forum_colors($config)
{
    
    return $config;
}


function invio_bbpress_filter_form_message( $retstr, $args )
{
    //removes forum summary, voices count etc
    return false;
}



/*modify default breadcrumb to work better with bb forums*/

if(!function_exists('invio_fetch_bb_trail'))
{
    //fetch bb trail and set the bb breadcrum output to false
    function invio_fetch_bb_trail($trail, $breadcrumbs, $r)
    {
        global $invio_config;
        $invio_config['bbpress_trail'] = $breadcrumbs;
        
        return false;
    }
    
    add_filter('bbp_get_breadcrumb','invio_fetch_bb_trail',10,3);
}

if(!function_exists('invio_bbpress_breadcrumb'))
{
    //if we are viewing a forum page set the invio breadcrumb output to match the forum breadcrumb output
    function invio_bbpress_breadcrumb($trail)
    { 
        global $invio_config;
    
        if((isset($invio_config['currently_viewing']) && $invio_config['currently_viewing'] == 'forum') || get_post_type() === "forum" || get_post_type() === "topic")
        {
            $bc = bbp_get_breadcrumb();
            
            if(isset($invio_config['bbpress_trail'] )) 
            { 
                $trail_zero = $trail[0];
                $trail = $invio_config['bbpress_trail'] ;
                $trail[0] = $trail_zero;
            }
            
            if((bbp_is_single_user_edit() || bbp_is_single_user()))
            {
                $user_info = get_userdata(bbp_get_displayed_user_id());
                $title = __("Profile for User:","invio_framework")." ".$user_info->display_name;
                array_pop($trail);
                $trail[] = $title;
            }
        }            
        return $trail;
    }
    
    
    add_filter('invio_breadcrumbs_trail','invio_bbpress_breadcrumb');
}




    register_sidebar(array(
        'name' => 'Forum',
        'before_widget' => '<div id="%1$s" class="widget clearfix %2$s">', 
        'after_widget' => '<span class="seperator extralight-border"></span></div>', 
        'before_title' => '<h3 class="widgettitle">', 
        'after_title' => '</h3>',
        'id' => 'invio_forum' 
    ));
    
/*
    
    add_filter('bbp_view_widget_title', 'invio_widget_title');
    add_filter('bbp_login_widget_title', 'invio_widget_title');
    add_filter('bbp_forum_widget_title', 'invio_widget_title');
    add_filter('bbp_topic_widget_title', 'invio_widget_title');
    add_filter('bbp_replies_widget_title', 'invio_widget_title');
*/


if(!function_exists('invio_remove_bbpress_post_type_options'))
{
    function invio_remove_bbpress_post_type_options($post_type_option, $args)
    {
        if(!empty($post_type_option))
        {
            foreach($post_type_option as $key => $post_type)
            {
                if($post_type == 'forum' || $post_type == 'topic' || $post_type == 'reply')
                {
                    unset($post_type_option[$key]);
                }
            }
        }
    
        return $post_type_option;
    }
    
    add_filter('infio_filter_registered_post_type_array', 'invio_remove_bbpress_post_type_options', 10, 2);
}


if(!function_exists('invio_remove_bbpress_post_type_from_query'))
{
    function invio_remove_bbpress_post_type_from_query($query, $params)
    {
        if(!empty($query['post_type']) && is_array($query['post_type']))
        {
            foreach($query['post_type'] as $key => $post_type)
            {
                if($post_type == 'forum' || $post_type == 'topic' || $post_type == 'reply')
                {
                    unset($query['post_type'][$key]);
                }
            }
        }
    
        return $query;
    }
    
    add_filter('invio_masonry_entries_query', 'invio_remove_bbpress_post_type_from_query', 10, 2);
    add_filter('invio_post_grid_query', 'invio_remove_bbpress_post_type_from_query', 10, 2);
    add_filter('invio_post_slide_query', 'invio_remove_bbpress_post_type_from_query', 10, 2);
    add_filter('invio_blog_post_query', 'invio_remove_bbpress_post_type_from_query', 10, 2);
    add_filter('infio_filter_magazine_entries_query', 'invio_remove_bbpress_post_type_from_query', 10, 2);
    add_filter('infio_filter_accordion_entries_query', 'invio_remove_bbpress_post_type_from_query', 10, 2);
}


