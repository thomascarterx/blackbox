<?php

/* - WPML compatibility - */
if(defined('ICL_SITEPRESS_VERSION') && defined('ICL_LANGUAGE_CODE'))
{
    add_filter( 'invio_filter_base_data' , 'invio_wpml_options_language' );
    add_filter( 'invio_filter_backend_page_title' , 'invio_wpml_backend_page_title' );
    //add_action( 'init', 'invio_wpml_register_post_type_permalink', 20);
    add_action( 'invio_action_before_framework_init', 'invio_wpml_get_languages');
    //add_filter( 'icl_ls_languages' , 'invio_wpml_url_filter' );
    add_action( 'init', 'invio_wpml_backend_language_switch');
    //add_action( 'invio_wpml_backend_language_switch', 'invio_default_dynamics');
    add_action( 'invio_wpml_backend_language_switch', 'invio_wpml_copy_options');
    add_action( 'wp_enqueue_scripts', 'invio_wpml_register_assets' );
    
    add_filter( 'infio_filter_execute_invio_meta_header', '__return_true', 10, 1);



    /*
    * This function makes it possible that all backend options can be saved several times
    * for different languages. It appends a language string to the key of the options entry
    * that is saved to the wordpress database.
    *
    * Since the Invio Framework only uses a single option array for the whole backend and
    * then serializes that array and saves it to a single database entry this is a very
    * easy and flexible method to setup your site in any way you want with muliple
    * languages, layouts, logos, dynamic templates, etc for each language
    */

    if(!function_exists('invio_wpml_options_language'))
    {
        function invio_wpml_options_language($base_data)
        {
            global $invio_config;
            $wpml_options = $invio_config['wpml']['settings'];

            if((isset($wpml_options['default_language']) && $wpml_options['default_language'] != ICL_LANGUAGE_CODE) && 'all' != ICL_LANGUAGE_CODE && "" != ICL_LANGUAGE_CODE)
            {
                $base_data['prefix_origin'] = $base_data['prefix'];
                $base_data['prefix'] = $base_data['prefix'] . "_" . ICL_LANGUAGE_CODE;
            }

            return $base_data;
        }
    }

    /*check if we are using the default language*/
    if(!function_exists('invio_wpml_is_default_language'))
    {
        function invio_wpml_is_default_language()
        {
            global $invio_config;
            $wpml_options = $invio_config['wpml']['settings'];

            if((isset($wpml_options['default_language']) && $wpml_options['default_language'] != ICL_LANGUAGE_CODE) && 'all' != ICL_LANGUAGE_CODE && "" != ICL_LANGUAGE_CODE)
            {
                return false;
            }
            else
            {
                return true;
            }
        }
    }

    /*fetch some default data necessary for the framework*/
    if(!function_exists('invio_wpml_get_languages'))
    {
        function invio_wpml_get_languages()
        {
            global $sitepress, $invio_config;
            $invio_config['wpml']['lang']         = $sitepress->get_active_languages();
            $invio_config['wpml']['settings']     = get_option('icl_sitepress_settings');
        }
    }

    /*language switch hook for the backend*/
    if(!function_exists('invio_wpml_backend_language_switch'))
    {
        function invio_wpml_backend_language_switch()
        {
            if(isset($_GET['lang']) && is_admin())
            {
                do_action('invio_wpml_backend_language_switch');
            }
        }
    }



    /*
      get an option from the database based on the option key passed.
      other then with the default invio_get_option function this one retrieves all language entries and passes them as array
    */

    if(!function_exists('invio_wpml_get_options'))
    {
        function invio_wpml_get_options($option_key)
        {
            global $invio, $invio_config;

            if(!isset($invio->wpml))
            {
                $key             = isset($invio->base_data['prefix_origin']) ? $invio->base_data['prefix_origin'] : $invio->base_data['prefix'];
                $key             = 'invio_options_'.invio_backend_safe_string( $key );
                $wpml_options     = $invio_config['wpml']['settings'];

                $key_array = array();
                if(is_array($invio_config['wpml']['lang'] ))
                {
                    foreach($invio_config['wpml']['lang'] as $lang => $values)
                    {
                        if($wpml_options['default_language'] != $lang)
                        {
                            $key_array[$lang] = $key ."_".$lang;
                        }
                        else
                        {
                            $key_array[$lang] = $key;
                        }

                        $invio->wpml[$lang] = get_option($key_array[$lang]);
                    }
                }
            }

            $option = array();

            if(isset($invio->wpml))
            {
                foreach($invio->wpml as $language => $option_set)
                {
                    if(isset($option_set['invio']) && isset($option_set['invio'][$option_key]))
                    {
                        $option[$language] = $option_set['invio'][$option_key];
                    }
                    else
                    {
                        $option[$language] = false;
                    }
                }
            }
            return $option;
        }
    }

    /*
    * Filters the menu entry in the backend and displays the language in addition to the theme name
    */
    if(!function_exists('invio_wpml_backend_page_title'))
    {
        function invio_wpml_backend_page_title($title)
        {
            if(ICL_LANGUAGE_CODE == "") return $title;

            $append = "";
            if('all' != ICL_LANGUAGE_CODE)
            {
                $append = " (".strtoupper( ICL_LANGUAGE_CODE ).")";
            }
            else
            {
                global $invio_config;

                $wpml_options     = $invio_config['wpml']['settings'];
                $append         = " (".strtoupper( $wpml_options['default_language'] ).")";
            }
            return $title . $append;
        }
    }

    /*
    * Creates an additional dynamic slug rewrite rule for custom categories
    */
    if(!function_exists('invio_wpml_register_post_type_permalink'))
    {
        function invio_wpml_register_post_type_permalink() {

            global $wp_post_types, $wp_rewrite, $wp, $invio_config;

            if(!isset($invio_config['custom_post'])) return false;

            $slug_array = invio_wpml_get_options('portfolio-slug');

            foreach($invio_config['wpml']['lang'] as $lang => $values)
            {
                foreach($invio_config['custom_post'] as $post_type => $arguments)
                {
                    $args = (object) $arguments['args'];
                    $args->rewrite['slug'] = $slug_array[$lang];
                    $args->permalink_epmask = EP_PERMALINK;
                    $post_type = sanitize_key($post_type);

                    if ( false !== $args->rewrite && ( is_admin() || '' != get_option('permalink_structure') ) )
                    {
                        $wp_rewrite->add_permastruct($post_type."_$lang", "{$args->rewrite['slug']}/%$post_type%", $args->rewrite['with_front'], $args->permalink_epmask);
                    }
                }
            }
        }
    }

    /*
    * Filters the links generated for the language switcher in case a user is viewing a single portfolio entry and changes the portfolio slug if necessary
    */
    if(!function_exists('invio_wpml_url_filter'))
    {
        function invio_wpml_url_filter($lang)
        {
            $post_type    = get_post_type();

            if("portfolio" == $post_type)
            {
                $slug         = invio_wpml_get_options('portfolio-slug');

                $current     = isset($slug[ICL_LANGUAGE_CODE]) ? $slug[ICL_LANGUAGE_CODE] : "";
                foreach ($lang as $key => $options)
                {
                    if(isset($options['url']) && $current != "" && $current != $slug[$key] && "" != $slug[$key])
                    {
                        $lang[$key]['url'] = str_replace("/".$current."/", "/".$slug[$key]."/", $lang[$key]['url']);
                    }
                }
            }
            return $lang;
        }
    }


    /*
    * register css styles
    */
    if(!function_exists('invio_wpml_register_assets'))
    {
        function invio_wpml_register_assets()
        {
            wp_enqueue_style( 'invio-wpml', INVIO_BASE_URL.'config-wpml/wpml-mod.css');
        }
    }

    /*
    * styleswitcher for the invio framework
    */
    if(!function_exists('invio_wpml_language_switch'))
    {
        add_action( 'invio_meta_header', 'invio_wpml_language_switch', 10);
        add_action( 'infio_action_main_header_sidebar', 'invio_wpml_language_switch', 10);

        function invio_wpml_language_switch()
        {
            global $sitepress, $invio_config;
            
            if(empty($invio_config['wpml_language_menu_position'])) $invio_config['wpml_language_menu_position'] = apply_filters('infio_filter_wpml_language_switcher_position', 'sub_menu');
            if($invio_config['wpml_language_menu_position'] != 'sub_menu') return;

            $languages = icl_get_languages('skip_missing=0&orderby=custom');
            $output = "";

            if(is_array($languages))
            {
                $output .= "<ul class='invio_wpml_language_switch invio_wpml_language_switch_extra'>";

                foreach($languages as $lang)
                {
                    $currentlang = (ICL_LANGUAGE_CODE == $lang['language_code']) ? 'invio_current_lang' : '';

                    if(!invio_is_overview() && (is_home() || is_front_page())) $lang['url'] = $sitepress->language_url($lang['language_code']);
                             
                    $output .= "<li class='language_".$lang['language_code']." $currentlang'><a href='".$lang['url']."'>";
                    $output .= "    <span class='language_flag'><img title='".$lang['native_name']."' src='".$lang['country_flag_url']."' alt='".$lang['native_name']."' /></span>";
                    $output .= "    <span class='language_native'>".$lang['native_name']."</span>";
                    $output .= "    <span class='language_translated'>".$lang['translated_name']."</span>";
                    $output .= "    <span class='language_code'>".$lang['language_code']."</span>";
                    $output .= "</a></li>";
                }

                $output .= "</ul>";
            }

            echo $output;
        }
    }

    /*
    * copy the default option set to the current language if no options set for this language is available yet
    */
    if(!function_exists('invio_wpml_copy_options'))
    {
        function invio_wpml_copy_options()
        {
            global $invio, $invio_config;

            $key             = isset($invio->base_data['prefix_origin']) ? $invio->base_data['prefix_origin'] : $invio->base_data['prefix'];
            $original_key     = 'invio_options_'.invio_backend_safe_string( $key );
            $language_key    = 'invio_options_'.invio_backend_safe_string( $invio->base_data['prefix'] );

            if($original_key !== $language_key)
            {
                $lang_set = get_option($language_key);

                if(empty($lang_set))
                {
                    $lang_set = get_option($original_key);
                    update_option($language_key, $lang_set);

                    wp_redirect( $_SERVER['REQUEST_URI'] );
                    exit();
                }
            }
        }
    }




    //Add all the necessary filters. There are a LOT of WordPress functions, and you may need to add more filters for your site.
    if(!function_exists('invio_wpml_correct_domain_in_url'))
    {
        // some installs require this fix: https://wpml.org/errata/blackbox-theme-styles-not-loading-with-different-domains/
        if (!is_admin()) {
        
            add_filter ('home_url', 'invio_wpml_correct_domain_in_url');
            add_filter ('site_url', 'invio_wpml_correct_domain_in_url');
            add_filter ('get_option_siteurl', 'invio_wpml_correct_domain_in_url');
            add_filter ('stylesheet_directory_uri', 'invio_wpml_correct_domain_in_url');
            add_filter ('template_directory_uri', 'invio_wpml_correct_domain_in_url');
            add_filter ('post_thumbnail_html', 'invio_wpml_correct_domain_in_url');
            add_filter ('plugins_url', 'invio_wpml_correct_domain_in_url');
            add_filter ('admin_url', 'invio_wpml_correct_domain_in_url');
            add_filter ('wp_get_attachment_url', 'invio_wpml_correct_domain_in_url');

        }

        /**
        * Changes the domain for a URL so it has the correct domain for the current language
        * Designed to be used by various filters
        *
        * @param string $url
        * @return string
        */
        function invio_wpml_correct_domain_in_url($url)
        {
            if (function_exists('icl_get_home_url'))
            {
                // Use the language switcher object, because that contains WPML settings, and it's available globally
                global $icl_language_switcher, $invio_config;

                // Only make the change if we're using the languages-per-domain option
                if (isset($icl_language_switcher->settings['language_negotiation_type']) && $icl_language_switcher->settings['language_negotiation_type'] == 2)
                {
                    if(!invio_wpml_is_default_language())
                    {
                        return str_replace(untrailingslashit( get_option('home') ), untrailingslashit(icl_get_home_url()), $url);
                    }
                }
            }
            return $url;
        }
    }


    if(!function_exists('invio_append_language_code_to_ajax_url'))
    {
        add_filter ('invio_ajax_url_filter', 'invio_append_language_code_to_ajax_url');

        function invio_append_language_code_to_ajax_url($url)
        {
            //conert url in case we are using different domain
            $url = invio_wpml_correct_domain_in_url($url);

            //after converting the url in case it was necessary also append the language code
            $url .= '?lang='.ICL_LANGUAGE_CODE;

            return $url;
        }
    }






    if(!function_exists('invio_backend_language_switch'))
    {
       add_filter( 'invio_options_page_header', 'invio_backend_language_switch' );

        function invio_backend_language_switch()
        {
            $current_page = basename($_SERVER['SCRIPT_NAME']);
            $query = '?';
            if(!empty($_SERVER['QUERY_STRING']))
            {
                $query .= $_SERVER['QUERY_STRING'] . '&';
            }

            $languages = icl_get_languages('skip_missing=0&orderby=id');
            $output = "";

            if(is_array($languages) && !empty($languages))
            {
                $output .= "<ul class='invio_wpml_language_switch'>";
                $output .= "<li><span class='invio_cur_lang_edit'>".__('Editing:', 'invio_framework')."</span><span class='invio_cur_lang'><img title='".$languages[ICL_LANGUAGE_CODE]['native_name']."' alt='".$languages[ICL_LANGUAGE_CODE]['native_name']."' src='".$languages[ICL_LANGUAGE_CODE]['country_flag_url']."' />";
                $output .= ICL_LANGUAGE_NAME_EN." (".__('Change', 'invio_framework').")</span>";
                unset($languages[ICL_LANGUAGE_CODE]);
                $output .= "<ul class='invio_sublanguages'>";

                foreach($languages as $lang)
                {
                    $linkurl = admin_url($current_page . $query .'lang=' . $lang['language_code']);

                    $output .= "<li class='language_".$lang['language_code']."'><a href='".$linkurl."'>";
                    $output .= "    <span class='language_flag'><img title='".$lang['native_name']."' src='".$lang['country_flag_url']."' alt='".$lang['native_name']."' /></span>";
                    $output .= "    <span class='language_native'>".$lang['native_name']."</span>";
                    $output .= "</a></li>";
                }

                $output .= "</ul></li></ul>";
                $output .="
                <style type='text/css'>
                .invio_wpml_language_switch {
                    z-index: 100;
                    padding: 10px;
                    position: absolute;
                    top: 13px;
                    left: 0;
                    margin:0;

                    }
                .invio_wpml_language_switch ul { display:none;
                    z-index: 100;
                    background-color: white;
                    position: absolute;
                    width: 128px;
                    padding: 57px 10px 10px;
                    left: -2px;
                    border: 1px solid #E1E1E1;
                    border-top: none;
                    margin-top: 0;
                    top:0;
                    }
                .invio_wpml_language_switch li:hover ul{display:block;}
                .invio_wpml_language_switch li a{text-decoration:none;}
                .invio_sublanguages li{
                margin:0;
                padding: 7px 0;
                border-top:1px solid #e1e1e1;
                }
                .invio_cur_lang, .invio_cur_lang_edit{ font-size:11px; padding:3px 0; z-index:300; position:relative; cursor:pointer; color: #5C951E; display:block;}
                .invio_cur_lang_edit{ color: #7D8388;}
                .invio_cur_lang img{margin:0px 4px -1px 0;}
                </style>
                ";


            }

            return $output;
        }
    }



    if(!function_exists('invio_wpml_filter_dropdown_post_query'))
        {
            add_filter( 'infio_filter_dropdown_post_query', 'invio_wpml_filter_dropdown_post_query', 10, 4);

            function invio_wpml_filter_dropdown_post_query($prepare_sql, $table_name, $limit, $element)
            {
                global $wpdb;
                $wpml_lang = ICL_LANGUAGE_CODE;
                $wpml_join = " INNER JOIN {$wpdb->prefix}icl_translations ON {$table_name}.ID = {$wpdb->prefix}icl_translations.element_id ";
                $wpml_where = " {$wpdb->prefix}icl_translations.language_code LIKE '{$wpml_lang}' AND ";

                $prepare_sql = "SELECT distinct ID, post_title FROM {$table_name} {$wpml_join} WHERE {$wpml_where} post_status = 'publish' AND post_type = '".$element['subtype']."' ORDER BY post_title ASC LIMIT {$limit}";
                return $prepare_sql;
            }
        }
        
        
        
        if(!function_exists('invio_change_wpml_home_link'))
    {
        add_filter('WPML_filter_link','invio_change_wpml_home_link', 10, 2);
        function invio_change_wpml_home_link($url, $lang)
        {
            global $sitepress;
            if(is_home() || is_front_page()) $url = $sitepress->language_url($lang['language_code']);
            return $url;
        }
    }


    if(!function_exists('invio_wpml_slideshow_slide_id_check'))
    {
        add_filter( 'infio_filter_invio_builder_slideshow_filter', 'invio_wpml_slideshow_slide_id_check', 10, 1);
        function invio_wpml_slideshow_slide_id_check($slideshow_data)
        {
            $id_array = $slideshow_data['id_array'];
            $slides = $slideshow_data['slides'];
        
            if(empty($id_array) || empty($slides)) return $slideshow_data;
        
            foreach($id_array as $key => $id)
            {
                if(!isset($slides[$id]))
                {
                    $id_of_translated_attachment = icl_object_id($id, "attachment", true);
        
                    if($id_of_translated_attachment && isset($slides[$id_of_translated_attachment]))
                    {
                        $slides[$id] = $slides[$id_of_translated_attachment];
                        unset($slides[$id_of_translated_attachment]);
                    }
                }
            }
        
            $slideshow_data['slides'] = $slides;
            return $slideshow_data;
        }
    }
    
    
    
    if(!function_exists('invio_wpml_author_name_translation'))
    {
        add_filter( 'infio_filter_author_name', 'invio_wpml_author_name_translation', 10, 2);
        function invio_wpml_author_name_translation($name, $author_id)
        {
            if(function_exists('icl_t')) $name = icl_t('Authors', 'display_name_'.$author_id, $name);
            return $name;
        }
    }



    if(!function_exists('invio_wpml_author_nickname_translation'))
    {
        add_filter( 'infio_filter_author_nickname', 'invio_wpml_author_nickname_translation', 10, 2);
        function invio_wpml_author_nickname_translation($name, $author_id)
        {
            if(function_exists('icl_t')) $name = icl_t('Authors', 'nickname_'.$author_id, $name);
            return $name;
        }
    }



    if(!function_exists('invio_append_lang_flags'))
    {
        //first append search item to main menu
        add_filter( 'wp_nav_menu_items', 'invio_append_lang_flags', 9998, 2 );
        add_filter( 'infio_filter_fallback_menu_items', 'invio_append_lang_flags', 9998, 2 );
        
        function invio_append_lang_flags( $items, $args )
        {
            if ((is_object($args) && $args->theme_location == 'invio'))
            {
                global $invio_config, $sitepress;

                if(empty($invio_config['wpml_language_menu_position'])) $invio_config['wpml_language_menu_position'] = apply_filters('infio_filter_wpml_language_switcher_position', 'main_menu');
                if($invio_config['wpml_language_menu_position'] != 'main_menu') return $items;
        
                $languages = icl_get_languages('skip_missing=0&orderby=custom');
        
                if(is_array($languages))
                {
                    foreach($languages as $lang)
                    {
                        $currentlang = (ICL_LANGUAGE_CODE == $lang['language_code']) ? 'invio_current_lang' : '';
        
                        if(is_home() || is_front_page()) $lang['url'] = $sitepress->language_url($lang['language_code']);
        
                        $items .= "<li class='invio-language-switch-item language_".$lang['language_code']." $currentlang'><a href='".$lang['url']."'>";
                        $items .= "    <span class='language_flag'><img title='".$lang['native_name']."' src='".$lang['country_flag_url']."' /></span>";
                        $items .= "</a></li>";
                    }
                }
            }
            return $items;
        }
    }
    
    
    

    if(!function_exists('invio_wpml_translate_date_format'))
    {
        function invio_wpml_translate_date_format($format)
        {
            if (function_exists('icl_translate')) $format = icl_translate('Formats', $format, $format);
            return $format;
        }
    
        add_filter('option_date_format', 'invio_wpml_translate_date_format');
    }
    
    


    if(!function_exists('invio_wpml_translate_all_search_results_url'))
    {
        function invio_wpml_translate_all_search_results_url($search_messages, $search_query)
        {
            $search_messages['all_results_link'] =  icl_get_home_url() . '?' . $search_messages['all_results_query'];
            return $search_messages;
        }
    
        add_filter('infio_filter_ajax_search_messages', 'invio_wpml_translate_all_search_results_url', 10, 2);
    }
    
    


    if(!function_exists('invio_translate_ids_from_query'))
    {
        function invio_translate_ids_from_query($query, $params)
        {
            $res = array();
            
            if(!empty($query['tax_query'][0]['terms']) && !empty($query['tax_query'][0]['taxonomy']))
            {
                foreach ($query['tax_query'][0]['terms'] as $id)
                {
                    $xlat = @icl_object_id($id, $query['tax_query'][0]['taxonomy'], true);
                    if(!is_null($xlat)) $res[] = $xlat;
                }
            
                if(!empty($res)) $query['tax_query'][0]['terms'] = $res;
            }
            else if(!empty($query['post__in']) && !empty($query['post_type']))
            {
                foreach($query['post__in'] as $id)
                {
                    $xlat = @icl_object_id($id, $query['post_type'], true);
                    if(!is_null($xlat)) $res[] = $xlat;
                }
                
                if(!empty($res)) $query['post__in'] = $res;
            }
        
            return $query;
        }
        
        add_filter('invio_masonry_entries_query', 'invio_translate_ids_from_query', 10, 2);
        add_filter('invio_post_grid_query', 'invio_translate_ids_from_query', 10, 2);
        add_filter('invio_post_slide_query', 'invio_translate_ids_from_query', 10, 2);
        add_filter('invio_blog_post_query', 'invio_translate_ids_from_query', 10, 2);
    }
    
    
    
    if(!function_exists('invio_translate_check_by_tag_values'))
    {
        function invio_translate_check_by_tag_values($value)
        {
            if(!empty($value) && is_array($value))
            {
                foreach($value as $key => $data)
                {
                    $orig_term = get_term_by('slug', $data, 'post_tag');
                    
                    if( false === $orig_term ) 
                    {
                        continue;
                    }
                        
                    $translated_id = icl_object_id( $orig_term->term_id, 'post_tag', true );
                    if( is_null( $translated_id ) || ( false === $translated_id ) )
                    {
                        continue;
                    }
                    
                    $translated_term = icl_object_id( $translated_id->term_id, 'post_tag', true );
                    if( is_null( $translated_term ) || ( false === $translated_term ) )
                    {
                        continue;
                    }
                    $value[$key] = $translated_term->slug;                    
                }
            }
            return $value;
        }
    
        add_filter('infio_filter_ratio_check_by_tag_values', 'invio_translate_check_by_tag_values', 10, 1);
    }




}

/*fix for: https://wpml.org/errata/translation-editor-support-invio-layout-builder-blackbox/*/
if(!function_exists('invio_wpml_sync_invio_layout_builder'))
{
    add_action( 'wpml_translation_job_saved', 'invio_wpml_sync_invio_layout_builder', 10, 3 );
    
    function invio_wpml_sync_invio_layout_builder( $new_post_id, $fields, $job ) {
        if ( isset( $fields['body']['data'] ) ) {
            if ( 'active' === get_post_meta( $new_post_id, '_invioLayoutBuilder_active', true ) ) {
                update_post_meta(
                    $new_post_id,
                    '_invioLayoutBuilderCleanData',
                    $fields['body']['data']
                );
            }
        }
    }
    
}



/*compatibility function for the portfolio problems*/
if(!function_exists('invio_portfolio_compat') && defined('ICL_SITEPRESS_VERSION') && defined('ICL_LANGUAGE_CODE'))
{
    add_action( 'invio_action_before_framework_init', 'invio_portfolio_compat', 30);
    function invio_portfolio_compat()
    {
        global $invio_config;
        if(empty($invio_config['wpml']['settings']['custom_posts_sync_option']) || empty($invio_config['wpml']['settings']['custom_posts_sync_option']['portfolio']))
        {
            $settings = get_option('icl_sitepress_settings');
            $settings['custom_posts_sync_option']['portfolio'] = 1;
            $settings['taxonomies_sync_option']['portfolio_entries'] = 1;
            update_option('icl_sitepress_settings', $settings);
        }
    }
}


