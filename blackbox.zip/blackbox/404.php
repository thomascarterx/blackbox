<?php
    if ( !defined('ABSPATH') ){ die(); }
    
    global $invio_config;

    /*
     * get_header is a basic wordpress function, used to retrieve the header.php file in your theme directory.
     */
     get_header();


     echo invio_title(array('title' => __('Error 404 - page not found', 'invio_framework')));
     
     do_action( 'infio_action_after_main_title' );
    ?>


        <div class='container_wrap container_wrap_first main_color <?php invio_layout_class( 'main' ); ?>'>
            
            <?php 
                do_action('invio_404_extra'); // allows user to hook into 404 page fr extra functionallity. eg: send mail that page is missing, output additional information
            ?>
            
            <div class='container'>

                <main class='template-page content <?php invio_layout_class( 'content' ); ?> units' <?php invio_markup_helper(array('context' => 'content'));?>>


                    <div class="entry entry-content-wrapper clearfix" id='search-fail'>
                    <?php

                    get_template_part('includes/error404');

                    ?>
                    </div>

                <!--end content-->
                </main>

                <?php

                //get the sidebar
                $invio_config['currently_viewing'] = 'page';
                get_sidebar();

                ?>

            </div><!--end container-->

        </div><!-- close default .container_wrap element -->




<?php get_footer(); ?>
