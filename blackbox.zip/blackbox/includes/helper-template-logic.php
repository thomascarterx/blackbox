<?php

if(!function_exists('invio_modify_front'))
{
    /**
    *
    * This function checks what to display on the frontpage
    * Its a new and much simpler function to redirect front and blog pages, by simply filtering the settings->readings options and replacing them with the invio theme options
    */

    add_action('init', 'invio_modify_front', 10);
    function invio_modify_front($wp_query)
    {
        if(!is_admin())
        {
            if(invio_get_option('frontpage'))
            {
                add_filter('pre_option_show_on_front', 'invio_show_on_front_filter');
                add_filter('pre_option_page_on_front', 'invio_page_on_front_filter');
                
                if(invio_get_option('blogpage'))
                {
                    add_filter('pre_option_page_for_posts', 'invio_page_for_posts_filter');
                }
            }
        }
    }

    function invio_show_on_front_filter($val) { return 'page'; }
    function invio_page_on_front_filter($val) { return invio_get_option('frontpage'); }
    function invio_page_for_posts_filter($val){ return invio_get_option('blog_style') !== 'custom' ? invio_get_option('blogpage') : ""; } //use the layout editor to build a blog?
}


/*
* Function that makes sure that empty searches are sent to the search page as well
*/

if(!function_exists('invio_search_query_filter'))
{
    function invio_search_query_filter($query)
    {
        //don't check query on admin page - otherwise we'll break the sort/filter options on the Pages > All Pages screen, etc.
        if(is_admin()) return;
        
           // If 's' request variable is set but empty
        if (isset($_GET['s']) && empty($_GET['s']) && empty($_GET['adv_search']) && $query->is_main_query() && empty($query->queried_object))
        {
            //set all query conditional to false to prevent php notices
            foreach($query as $key => &$query_attr)
            {
                if(strpos($key, 'is_') === 0) $query_attr = false;
            }

            $query->is_search     = true;
            $query->set( 'post_type', 'fake_search_no_results' );
       }

       return $query;

    }
    add_filter('pre_get_posts', 'invio_search_query_filter');
}

/*
*  Function that modifies the breadcrumb navigation of single portfolio entries and single blog entries
*/


if(!function_exists('invio_modify_breadcrumb'))
{
    function invio_modify_breadcrumb($trail)
    {
        $parent = get_post_meta(invio_get_the_ID(), 'breadcrumb_parent', true);

        if(get_post_type() === "portfolio")
        {
            $page     = "";
            $front     = invio_get_option('frontpage');

            if(empty($parent) && !current_theme_supports('invio_no_session_support') && session_id() && !empty($_SESSION['invio_portfolio']))
            {
                $page = $_SESSION['invio_portfolio'];
            }
            else
            {
                $page = $parent;
            }

            if(!$page || $page == $front)
            {
                $args = array( 'post_type' => 'page', 'meta_query' => array(
                        array( 'key' => '_invio_builder_shortcode_tree', 'value' => 'invio_portfolio', 'compare' => 'LIKE' ) ) );

                $query = new WP_Query( $args );

                if($query->post_count == 1)
                {
                    $page = $query->posts[0]->ID;
                }
                else if($query->post_count > 1)
                {
                    foreach($query->posts as $entry)
                    {
                        if ($front != $entry->ID)
                        {
                            $page = $entry->ID;
                            break;
                        }
                    }
                }
            }

            if($page)
            {
                if($page == $front)
                {
                    $newtrail[0] = $trail[0];
                    $newtrail['trail_end'] = $trail['trail_end'];
                    $trail = $newtrail;
                }
                else
                {
                    $newtrail = invio_breadcrumbs_get_parents( $page, '' );
                    array_unshift($newtrail, $trail[0]);
                    $newtrail['trail_end'] = $trail['trail_end'];
                    $trail = $newtrail;
                }
            }
        }
        else if(get_post_type() === "post" && (is_category() || is_archive() || is_tag()))
        {

            $front = invio_get_option('frontpage');
            $blog = !empty($parent) ? $parent : invio_get_option('blogpage');

            if($front && $blog && $front != $blog)
            {
                $blog = '<a href="' . get_permalink( $blog ) . '" title="' . esc_attr( get_the_title( $blog ) ) . '">' . get_the_title( $blog ) . '</a>';
                array_splice($trail, 1, 0, array($blog));
            }
        }
        else if(get_post_type() === "post")
        {
            $front             = invio_get_option('frontpage');
            $blog             = invio_get_option('blogpage');
            $custom_blog     = invio_get_option('blog_style') === 'custom' ? true : false;
            
            if(!$custom_blog)
            {
                if($blog == $front)
                {
                    unset($trail[1]);
                }
            }
            else
            {
                if($blog != $front)
                {
                    $blog = '<a href="' . get_permalink( $blog ) . '" title="' . esc_attr( get_the_title( $blog ) ) . '">' . get_the_title( $blog ) . '</a>';
                    array_splice($trail, 1, 0, array($blog));
                }
            }
        }
        
        return $trail;
    }


    add_filter('invio_breadcrumbs_trail','invio_modify_breadcrumb');
}




if(!function_exists('invio_layout_class'))
{

/*
* support function that checks if the current page
* should have a post or page layout and returns the
* string so invio_template_set_page_layout can check it
*
* the function is called for each main layout div
* and then delivers the grid classes defined in functions.php
*/

    function invio_layout_class($key, $echo = true)
    {
        global $invio_config;

        if(!isset($invio_config['layout']['current']['main'])) { invio_set_layout_array(); }

        $return = $invio_config['layout']['current'][$key];

        if( $echo == true )
        {
            echo $return;
        }
        else
        {
            return $return;
        }
    }
}

if(!function_exists('invio_offset_class'))
{

/*
* retrieves the offset length of an element based on the current page layout
*/
    function invio_offset_class($key, $echo = true)
    {
        $alpha  = "";
        $offset = invio_layout_class($key, false);
        if(strpos($offset, 'alpha') !== false)
        {
            $offset = str_replace('alpha',"",$offset);
            $alpha = " alpha";
        }

        $offset = 'offset-by-'.trim($offset).$alpha;
        if( $echo == true ){ echo $offset; } else { return $offset; }
    }
}



if(!function_exists('invio_set_layout_array'))
{

    /*
    * The function checks which layout is applied to the template (eg: fullwidth, right_sidebar, left_sidebar)
    * If no layout is applied it checks for the default layout, set in the general options
    *
    * The final value is then stored in $invio_config['layout']['current'] where it can be accessed by the invio_layout function
    */


    function invio_set_layout_array($post_type = false, $post_id = false)
    {
        global $invio_config;

        //check which string to use
        $result = false;
        $layout = 'blog_layout';
        
        if(empty($post_id)) $post_id = invio_get_the_ID();
        
        if(is_page() || is_search() || is_404() || is_attachment()) $layout = 'page_layout';
        if(is_archive()) $layout = 'archive_layout';
        if(is_single()) $layout = 'single_layout';

        //on a single page check if the layout is overwritten
        if(is_singular())
        {
            $result = get_post_meta($post_id, 'layout', true);
        }

        //if we got no result from the previous get_pst_meta query or we are not on a single post get the setting defined on the option page
        if(!$result)
        {
            $result = invio_get_option($layout);
        }

        //if we stil got no result, probably because no option page was saved
        if(!$result)
        {
            $result = 'sidebar_right';
        }
        
        if($result)
        {
            $invio_config['layout']['current'] = $invio_config['layout'][$result];
            $invio_config['layout']['current']['main'] = $result;
        }
        
        $invio_config['layout'] = apply_filters('invio_layout_filter', $invio_config['layout'], $post_id);
    }
}


if(!function_exists('invio_has_sidebar'))
{
    function invio_has_sidebar()
    {
        global $invio_config;

        return strpos($invio_config['layout']['current']['main'], 'sidebar') !== false ? true : false;
    }
}
