<?php
$weight     = array(__('Default','invio_framework') => '' , __('Normal','invio_framework') =>'normal', __('Bold','invio_framework')=>'bold', __('Light','invio_framework')=>'lighter');
$transform     = array(__('Default','invio_framework') => '' , __('None'  ,'invio_framework') =>'none', __('Uppercase','invio_framework')=>'uppercase', __('Lowercase','invio_framework')=>'lowercase');
$align     = array(__('Default','invio_framework') => '' , __('Left'  ,'invio_framework') =>'left', __('Center','invio_framework')=>'center', __('Right','invio_framework')=>'right');
$decoration = array(__('Default','invio_framework') => '' , __('None','invio_framework')=>'none !important' , __('Underline'  ,'invio_framework') =>'underline !important', __('Overline','invio_framework')=>'overline !important', __('Line Trough','invio_framework')=>'line-through !important');
$display     = array(__('Default','invio_framework') => '' , __('Inline','invio_framework') =>'inline', __('Inline Block','invio_framework')=>'inline-block', __('Block','invio_framework')=>'block');


$advanced = array();


$advanced['body'] = array(
    "id"            => "body", //needs to match array key
    "name"            => "&lt;body&gt;",
    "group"         => __("HTML Tags",'invio_framework'),
    "description"    => __("Change the styling for the &lt;body&gt; tag.",'invio_framework'),
    "selector"        => array("body#top" => ""),
    "sections"        => false,
    "hover"            => false,
    "edit"            => array(    
                            'font_size'         => array('type' => 'size', 'range' => '10-80', 'name'=> __("Font Size",'invio_framework')),
                            'line_height'        => array('type' => 'size', 'range' => '0.7-2', 'increment' => 0.1, 'unit' => 'em',  'name'=> __("Line Height",'invio_framework')),
                            'font_weight'         => array('type' => 'select', 'name'=> __("Font Weight",'invio_framework'), 'options' => $weight),
                            'font_family'         => array('type' => 'font', 'name'=> __("Font Family",'invio_framework'), 'options' => $google_fonts),
                            )
);

$advanced['paragraph'] = array(
    "id"            => "paragraph", //needs to match array key
    "name"            => "&lt;p&gt;",
    "group"         => __("HTML Tags",'invio_framework'),
    "description"    => __("Change the styling for all &lt;p&gt; tags",'invio_framework'),
    "selector"        => array("#top [sections] p" => array( 
                                                            "font_size" => "font-size: %font_size%;", 
                                                            "line_height" => "line-height: %line_height%;", 
                                                            "font_weight" => "font-weight: %font_weight%;", 
                                                            "margin" => "margin: %margin% 0;")
                                                            ),
    "sections"        => true,
    "hover"            => false,
    "edit"            => array(    
                            'font_size'         => array('type' => 'size', 'range' => '10-80', 'name'=> __("Font Size",'invio_framework')),
                            'line_height'=> array('type' => 'size', 'range' => '0.7-2', 'increment' => 0.1, 'unit' => 'em',  'name'=> __("Line Height",'invio_framework')),
                            'font_weight'         => array('type' => 'select', 'name'=> __("Font Weight",'invio_framework'), 'options' => $weight),
                            'margin'             => array('type' => 'size', 'range' => '0.5-3', 'increment' => 0.1, 'unit' => 'em',  'name'=> __("Top &amp; Bottom margin",'invio_framework')),
                            )
);

$advanced['strong'] = array(
    "id"            => "strong", //needs to match array key
    "name"            => "&lt;strong&gt;",
    "group"         => __("HTML Tags",'invio_framework'),
    "description"    => __("Change the styling for all &lt;strong&gt; tags",'invio_framework'),
    "selector"        => array("#top [sections] strong" => ""),
    "sections"        => true,
    "hover"            => false,
    "edit"            => array(    'color'             => array('type' => 'colorpicker', 'name'=> __("Font Color",'invio_framework')), 
                                'background_color'     => array('type' => 'colorpicker', 'name'=> __("Background Color",'invio_framework')),
                                'font_family'         => array('type' => 'font', 'name'=> __("Font Family",'invio_framework'), 'options' => $google_fonts),
                            )
);

$advanced['blockquote'] = array(
    "id"            => "blockquote", //needs to match array key
    "name"            => "&lt;blockquote&gt;",
    "group"         => __("HTML Tags",'invio_framework'),
    "description"    => __("Change the styling for all &lt;blockquote&gt; tags",'invio_framework'),
    "selector"        => array("#top [sections] blockquote"=> ""),
    "sections"        => true,
    "hover"            => false,
    "edit"            => array(    'color'             => array('type' => 'colorpicker', 'name'=> __("Font Color",'invio_framework')), 
                                'border_color'         => array('type' => 'colorpicker', 'name'=> __("Border Color",'invio_framework')),
                                'font_size'         => array('type' => 'size', 'range' => '10-80', 'name'=> __("Font Size",'invio_framework')),
                                'line_height'         => array('type' => 'size', 'range' => '0.7-2', 'increment' => 0.1, 'unit' => 'em',  'name'=> __("Line Height",'invio_framework')),
                            )
);

$advanced['underline'] = array(
    "id"            => "underline", //needs to match array key
    "name"            => "&lt;u&gt;",
    "group"         => __("HTML Tags",'invio_framework'),
    "description"    => __("Change the styling for all &lt;u&gt; (underline) tags",'invio_framework'),
    "selector"        => array("#top [sections] u, #top [sections] span[style*='text-decoration: underline;'], #top [sections] span[style*='text-decoration:underline;']"=> ""),
    "sections"        => true,
    "hover"            => false,
    "edit"            => array(    'color'             => array('type' => 'colorpicker', 'name'=> __("Font Color",'invio_framework')), 
                                'background_color'     => array('type' => 'colorpicker', 'name'=> __("Background Color",'invio_framework')),
                                'font_size'         => array('type' => 'size', 'range' => '10-80', 'name'=> __("Font Size",'invio_framework')),
                                'font_weight'         => array('type' => 'select', 'name'=> __("Font Weight",'invio_framework'), 'options' => $weight),
                                'line_height'         => array('type' => 'size', 'range' => '0.7-2', 'increment' => 0.1, 'unit' => 'em',  'name'=> __("Line Height",'invio_framework')),
                                'font_family'         => array('type' => 'font', 'name'=> __("Font Family",'invio_framework'), 'options' => $google_fonts),
                                'text_decoration'     => array('type' => 'select', 'name'=> __("Text Decoration",'invio_framework'), 'options' => $decoration),
                                'display'             => array('type' => 'select', 'name'=> __("Display",'invio_framework'), 'options' => $display),
                            )
);


$advanced['mark'] = array(
    "id"            => "mark", //needs to match array key
    "name"            => "&lt;mark&gt;",
    "group"         => __("HTML Tags",'invio_framework'),
    "description"    => __("Change the styling for all &lt;mark&gt; tags",'invio_framework'),
    "selector"        => array("#top [sections] mark"=> ""),
    "sections"        => true,
    "hover"            => false,
    "edit"            => array(    'color'             => array('type' => 'colorpicker', 'name'=> __("Font Color",'invio_framework')), 
                                'background_color'     => array('type' => 'colorpicker', 'name'=> __("Background Color",'invio_framework')),
                                'font_size'         => array('type' => 'size', 'range' => '10-80', 'name'=> __("Font Size",'invio_framework')),
                                'font_weight'         => array('type' => 'select', 'name'=> __("Font Weight",'invio_framework'), 'options' => $weight),
                                'line_height'         => array('type' => 'size', 'range' => '0.7-2', 'increment' => 0.1, 'unit' => 'em',  'name'=> __("Line Height",'invio_framework')),
                                'font_family'         => array('type' => 'font', 'name'=> __("Font Family",'invio_framework'), 'options' => $google_fonts),
                                'text_decoration'     => array('type' => 'select', 'name'=> __("Text Decoration",'invio_framework'), 'options' => $decoration),
                                'display'             => array('type' => 'select', 'name'=> __("Display",'invio_framework'), 'options' => $display),
                            )
);





$advanced['headings_all'] = array(
    "id"            => "headings_all", //needs to match array key
    "name"            => "All Headings (H1-H6)",
    "group"         => __("Headings",'invio_framework'),
    "description"    => __("Change the styling for all Heading tags",'invio_framework'),
    "selector"        => array("#top #wrap_all [sections] h1, #top #wrap_all [sections] h2, #top #wrap_all [sections] h3, #top #wrap_all [sections] h4, #top #wrap_all [sections] h5, #top #wrap_all [sections] h6"=> ""),
    "sections"        => true,
    "hover"            => false,
    "edit"            => array(    'color'             => array('type' => 'colorpicker', 'name'=> __("Font Color",'invio_framework')), 
                                'background_color'     => array('type' => 'colorpicker', 'name'=> __("Background Color",'invio_framework')),
                                'font_family'         => array('type' => 'font', 'name'=> __("Font Family",'invio_framework'), 'options' => $google_fonts),
                                'font_weight'         => array('type' => 'select', 'name'=> __("Font Weight",'invio_framework'), 'options' => $weight),
                                'text_transform'     => array('type' => 'select', 'name'=> __("Text Transform",'invio_framework'), 'options' => $transform ),                            
                                )

);

$advanced['h1'] = array(
    "id"            => "h1", //needs to match array key
    "name"            => "H1",
    "group"         => __("Headings",'invio_framework'),
    "description"    => __("Change the styling for your H1 Tag",'invio_framework'),
    "selector"        => array("#top #wrap_all [sections] h1"=> ""),
    "sections"        => true,
    "hover"            => false,
    "edit"            => array(    'color'             => array('type' => 'colorpicker', 'name'=> __("Font Color",'invio_framework')), 
                                'background_color'     => array('type' => 'colorpicker', 'name'=> __("Background Color",'invio_framework')),
                                'font_size'         => array('type' => 'size', 'range' => '10-80', 'name'=> __("Font Size",'invio_framework')),
                                'line_height'         => array('type' => 'size', 'range' => '0.7-2', 'increment' => 0.1, 'unit' => 'em',  'name'=> __("Line Height",'invio_framework')),
                                'font_family'         => array('type' => 'font', 'name'=> __("Font Family",'invio_framework'), 'options' => $google_fonts),
                                'font_weight'         => array('type' => 'select', 'name'=> __("Font Weight",'invio_framework'), 'options' => $weight),
                                'text_transform'     => array('type' => 'select', 'name'=> __("Text Transform",'invio_framework'), 'options' => $transform ),
                            )

);





$advanced['h2'] = array(
    "id"            => "h2", //needs to match array key
    "name"            => "H2",
    "group"         => __("Headings",'invio_framework'),
    "description"    => __("Change the styling for your H2 Tag",'invio_framework'),
    "selector"        => array("#top #wrap_all [sections] h2"=> ""),
    "sections"        => true,
    "hover"            => false,
    "edit"            => array(    'color'             => array('type' => 'colorpicker', 'name'=> __("Font Color",'invio_framework')), 
                                'background_color'     => array('type' => 'colorpicker', 'name'=> __("Background Color",'invio_framework')),
                                'font_size'         => array('type' => 'size', 'range' => '10-80', 'name'=> __("Font Size",'invio_framework')),
                                'line_height'         => array('type' => 'size', 'range' => '0.7-2', 'increment' => 0.1, 'unit' => 'em',  'name'=> __("Line Height",'invio_framework')),
                                'font_family'         => array('type' => 'font', 'name'=> __("Font Family",'invio_framework'), 'options' => $google_fonts),
                                'font_weight'         => array('type' => 'select', 'name'=> __("Font Weight",'invio_framework'), 'options' => $weight),
                                'text_transform'     => array('type' => 'select', 'name'=> __("Text Transform",'invio_framework'), 'options' => $transform ),        
                                )
);

$advanced['h3'] = array(
    "id"            => "h3", //needs to match array key
    "name"            => "H3",
    "group"         => __("Headings",'invio_framework'),
    "description"    => __("Change the styling for your H3 Tag",'invio_framework'),
    "selector"        => array("#top #wrap_all [sections] h3"=> ""),
    "sections"        => true,
    "hover"            => false,
    "edit"            => array(    'color'             => array('type' => 'colorpicker', 'name'=> __("Font Color",'invio_framework')), 
                                'background_color'     => array('type' => 'colorpicker', 'name'=> __("Background Color",'invio_framework')),
                                'font_size'         => array('type' => 'size', 'range' => '10-80', 'name'=> __("Font Size",'invio_framework')),
                                'line_height'         => array('type' => 'size', 'range' => '0.7-2', 'increment' => 0.1, 'unit' => 'em',  'name'=> __("Line Height",'invio_framework')),
                                'font_family'         => array('type' => 'font', 'name'=> __("Font Family",'invio_framework'), 'options' => $google_fonts),
                                'font_weight'         => array('type' => 'select', 'name'=> __("Font Weight",'invio_framework'), 'options' => $weight),
                                'text_transform'     => array('type' => 'select', 'name'=> __("Text Transform",'invio_framework'), 'options' => $transform ),        
                            )
);

$advanced['h4'] = array(
    "id"            => "h4", //needs to match array key
    "name"            => "H4",
    "group"         => __("Headings",'invio_framework'),
    "description"    => __("Change the styling for your H4 Tag",'invio_framework'),
    "selector"        => array("#top #wrap_all [sections] h4"=> ""),
    "sections"        => true,
    "hover"            => false,
    "edit"            => array(    'color'             => array('type' => 'colorpicker', 'name'=> __("Font Color",'invio_framework')), 
                                'background_color'     => array('type' => 'colorpicker', 'name'=> __("Background Color",'invio_framework')),
                                'font_size'         => array('type' => 'size', 'range' => '10-80', 'name'=> __("Font Size",'invio_framework')),
                                'line_height'         => array('type' => 'size', 'range' => '0.7-2', 'increment' => 0.1, 'unit' => 'em',  'name'=> __("Line Height",'invio_framework')),
                                'font_family'         => array('type' => 'font', 'name'=> __("Font Family",'invio_framework'), 'options' => $google_fonts),
                                'font_weight'         => array('type' => 'select', 'name'=> __("Font Weight",'invio_framework'), 'options' => $weight),
                                'text_transform'     => array('type' => 'select', 'name'=> __("Text Transform",'invio_framework'), 'options' => $transform ),        
                            )
);

$advanced['h5'] = array(
    "id"            => "h5", //needs to match array key
    "name"            => "H5",
    "group"         => __("Headings",'invio_framework'),
    "description"    => __("Change the styling for your H5 Tag",'invio_framework'),
    "selector"        => array("#top #wrap_all [sections] h5"=> ""),
    "sections"        => true,
    "hover"            => false,
    "edit"            => array(    'color'             => array('type' => 'colorpicker', 'name'=> __("Font Color",'invio_framework')), 
                                'background_color'     => array('type' => 'colorpicker', 'name'=> __("Background Color",'invio_framework')),
                                'font_size'         => array('type' => 'size', 'range' => '10-80', 'name'=> __("Font Size",'invio_framework')),
                                'line_height'         => array('type' => 'size', 'range' => '0.7-2', 'increment' => 0.1, 'unit' => 'em',  'name'=> __("Line Height",'invio_framework')),
                                'font_family'         => array('type' => 'font', 'name'=> __("Font Family",'invio_framework'), 'options' => $google_fonts),
                                'font_weight'         => array('type' => 'select', 'name'=> __("Font Weight",'invio_framework'), 'options' => $weight),
                                'text_transform'     => array('type' => 'select', 'name'=> __("Text Transform",'invio_framework'), 'options' => $transform ),        
                            )
);

$advanced['h6'] = array(
    "id"            => "h6", //needs to match array key
    "name"            => "H6",
    "group"         => __("Headings",'invio_framework'),
    "description"    => __("Change the styling for your H6 Tag",'invio_framework'),
    "selector"        => array("#top #wrap_all [sections] h6"=> ""),
    "sections"        => true,
    "hover"            => false,
    "edit"            => array(    'color'             => array('type' => 'colorpicker', 'name'=> __("Font Color",'invio_framework')), 
                                'background_color'     => array('type' => 'colorpicker', 'name'=> __("Background Color",'invio_framework')),
                                'font_size'         => array('type' => 'size', 'range' => '10-80', 'name'=> __("Font Size",'invio_framework')),
                                'line_height'         => array('type' => 'size', 'range' => '0.7-2', 'increment' => 0.1, 'unit' => 'em',  'name'=> __("Line Height",'invio_framework')),
                                'font_family'         => array('type' => 'font', 'name'=> __("Font Family",'invio_framework'), 'options' => $google_fonts),
                                'font_weight'         => array('type' => 'select', 'name'=> __("Font Weight",'invio_framework'), 'options' => $weight),
                                'text_transform'     => array('type' => 'select', 'name'=> __("Text Transform",'invio_framework'), 'options' => $transform ),        
                            )
);



$advanced['main_menu'] = array(
    "id"            => "main_menu", //needs to match array key
    "name"            => __("Main Menu Links",'invio_framework'),
    "group"         => __("Main Menu",'invio_framework'),
    "description"    => __("Change the styling for your main menu links",'invio_framework'),
    "selector"        => array(
        /*trick: hover is used inside the selector to prevent it from beeing applied when :hover is checked*/
        "#top #header[hover]_main_alternate" => array(  "background_color" => "background-color: %background_color%;" ),
        "#top #header .invio-main-nav > li[hover] " => array(  "font_family" => "font-family: %font_family%;" ),
        "#top #header .invio-main-nav > li[hover] > a" => "",
        ".invio_seperator_small_border .invio-main-nav > li[hover] > a > .invio-menu-text,
        #top #wrap_all #header #menu-item-search[hover]>a
        
        "=> array(  "border_color" => "border-color: %border_color%;" ),
        "#top #header .invio-main-nav > li[hover] > a .invio-menu-text, #top #header .invio-main-nav > li[hover] > a .invio-menu-subtext"=> array(  "color" => "color: %color%;" )
    ),
    "sections"        => false,
    "hover"            => true,
    "edit"            => array(    'color'             => array('type' => 'colorpicker', 'name'=> __("Font Color",'invio_framework')), 
                                'background_color'     => array('type' => 'colorpicker', 'name'=> __("Background Color",'invio_framework')),
                                'border_color'         => array('type' => 'colorpicker', 'name'=> __("Border Color",'invio_framework')),
                                'font_size'         => array('type' => 'size', 'range' => '10-30', 'name'=> __("Font Size",'invio_framework')),
                                'font_family'         => array('type' => 'font', 'name'=> __("Font Family",'invio_framework'), 'options' => $google_fonts),
                            )                        
);


$advanced['main_menu_dropdown'] = array(
    "id"            => "main_menu_dropdown", //needs to match array key
    "name"            => __("Main Menu sublevel Links",'invio_framework'),
    "group"         => __("Main Menu",'invio_framework'),
    "description"    => __("Change the styling for your main menu dropdown links",'invio_framework'),
    "selector"        => array("#top #wrap_all .invio-main-nav ul > li[hover] > a, #top #wrap_all .invio_mega_div, #top #wrap_all .invio_mega_div ul, #top #wrap_all .invio-main-nav ul ul"=> ""),
    "sections"        => false,
    "hover"            => true,
    "edit"            => array(    'color'             => array('type' => 'colorpicker', 'name'=> __("Font Color",'invio_framework')), 
                                'background_color'     => array('type' => 'colorpicker', 'name'=> __("Background Color",'invio_framework')),
                                'border_color'         => array('type' => 'colorpicker', 'name'=> __("Border Color",'invio_framework')),
                                'font_size'         => array('type' => 'size', 'range' => '10-30', 'name'=> __("Font Size",'invio_framework')),
                                'line_height'         => array('type' => 'size', 'range' => '0.7-3', 'increment' => 0.1, 'unit' => 'em',  'name'=> __("Line Height",'invio_framework')),
                            )                        
);

$advanced['top_bar'] = array(
    "id"            => "top_bar", //needs to match array key
    "name"            => __("Small bar above Main Menu",'invio_framework'),
    "group"         => __("Main Menu",'invio_framework'),
    "description"    => __("Change the styling for the small bar above the main menu which can contain social icons, a second menu and a phone number ",'invio_framework'),
    "selector"        => array(
                                 "#top #header_meta, #top #header_meta nav ul ul li, #top #header_meta nav ul ul a, #top #header_meta nav ul ul" => array("background_color" => "background-color: %background_color%;"), 
                                 "#top #header_meta a, #top #header_meta li, #top #header_meta .phone-info" => array( "border_color" => "border-color: %border_color%;", "color" => "color: %color%;"),
                                 "#top #header_meta" => array("font_family" => "font-family: %font_family%;"), 
                                 
                             ),
    "sections"        => false,
    "hover"            => false,
    "edit"            => array(    'color'             => array('type' => 'colorpicker', 'name'=> __("Font Color",'invio_framework')), 
                                'background_color'     => array('type' => 'colorpicker', 'name'=> __("Background Color",'invio_framework')),
                                'border_color'         => array('type' => 'colorpicker', 'name'=> __("Border Color",'invio_framework')),
                                'font_family'         => array('type' => 'font', 'name'=> __("Font Family",'invio_framework'), 'options' => $google_fonts),
                            )                        
);




$advanced['main_menu_icon'] = array(
    "id"            => "main_menu_icon", //needs to match array key
    "name"            => __("Menu Links in overlay",'invio_framework'),
    "group"         => __("Main Menu (Icon)",'invio_framework'),
    "description"    => __("Change the styling for your main menu links once they are displayed in the page overlay",'invio_framework'),
    "selector"        => array(
        "#top #wrap_all #invio-burger-menu-ul li a" => array(
                                'color'         => "color:%color%;",
                                "font_family"     => "font-family: %font_family% ,'Helvetica Neue', Helvetica, Arial, sans-serif;", 
                                "font_weight"     => "font-weight: %font_weight%;",
                                "letter_spacing" => "letter-spacing: %letter_spacing%;",
                                "text_transform" => "text-transform: %text_transform%;",
                                ),
        "#top #wrap_all #invio-burger-menu-ul li" => array(
                                'font_size'     => "font-size:%font_size%;",
                                "line_height"     => "line-height: %line_height% !important;",
                                ),
        ".invio-burger-overlay-active #top .invio-hamburger-inner, .invio-burger-overlay-active #top .invio-hamburger-inner::before, .invio-burger-overlay-active #top .invio-hamburger-inner::after" => array(
            'color'=> "background-color:%color%;",
        ),
        "div.invio-burger-overlay-bg" => array(
            'background_color' => "background-color:%background_color%;",
        ),
        ".invio-burger-overlay-active #top #wrap_all #menu-item-search a, .invio-burger-overlay-active #top #wrap_all #menu-item-search a:hover" => array(
            'color' => "color:%color%;",
        ),
        
    
    ),
    "sections"        => false,
    "hover"            => false,
    "edit"            => array(    'color'             => array('type' => 'colorpicker', 'name'=> __("Font Color",'invio_framework')), 
                                'font_size'         => array('type' => 'size', 'range' => '10-120', 'name'=> __("Font Size",'invio_framework')),
                                'line_height'         => array('type' => 'size', 'range' => '0.7-3', 'increment' => 0.1, 'unit' => 'em',  'name'=> __("Line Height",'invio_framework')),
                                'font_family'         => array('type' => 'font', 'name'=> __("Font Family",'invio_framework'), 'options' => $google_fonts),
                                'font_weight'         => array('type' => 'select', 'name'=> __("Font Weight",'invio_framework'), 'options' => $weight),
                                'letter_spacing'     => array('type' => 'size', 'range' => array(-10,20), 'increment' => 1, 'unit' => 'px',  'name'=> __("Letter Spacing",'invio_framework')),
                                'text_transform'     => array('type' => 'select', 'name'=> __("Text Transform",'invio_framework'), 'options' => $transform ),
                                'background_color'     => array('type' => 'colorpicker', 'name'=> __("Overlay Color",'invio_framework')), 
                            )
                                                    
);














$advanced['hover_overlay'] = array(
    "id"            => "hover_overlay", //needs to match array key
    "name"            => __("Linked Image Overlay",'invio_framework'),
    "group"         => __("Misc",'invio_framework'),
    "description"    => __("Change the styling for the overlay that appears when you place your mouse cursor above a linked image",'invio_framework'),
    "selector"        => array(  
                                "#top [sections] .image-overlay-inside" => array("overlay_style" => array( "none" , "display: none;") ),
                                "#top [sections] .image-overlay"         => array("background_color" => "background-color: %background_color%;", "overlay_style" => array( "hide" , "visibility: hidden;")),   
                                "#top [sections] .image-overlay .image-overlay-inside:before" => array( "icon_color" => "background-color: %icon_color%;", "color" => "color: %color%;" )
                            ),
                            
                            
    "sections"        => true,
    "hover"            => false,
    "edit"            => array(    'overlay_style'     => array('type' => 'select', 'name'=> __("Overlay Style",'invio_framework'), 'options' => array(__('Default','invio_framework') => '' , __('Minimal Overlay (No Icon)','invio_framework') =>'none' , __('Disable Overlay','invio_framework') =>'hide' )) ,        
                                'color'             => array('type' => 'colorpicker', 'name'=> __("Icon Color",'invio_framework')), 
                                'icon_color'         => array('type' => 'colorpicker', 'name'=> __("Icon background",'invio_framework')),
                                'background_color'     => array('type' => 'colorpicker', 'name'=> __("Overlay Color",'invio_framework')),
                            )                        
);


$advanced['buttons'] = array(
    "id"            => "buttons", //needs to match array key
    "name"            => "Buttons",
    "group"         => __("Misc",'invio_framework'),
    "description"    => __("Change the styling of your buttons",'invio_framework'),
    "selector"        => array(
    "#top #wrap_all .invio-slideshow-button, #top .invio-button, .html_elegant-blog .more-link, .invio-slideshow-arrows a:before, #top .invio-menu-button > a .invio-menu-text"=> array('border_radius' => "border-radius: %border_radius%;"),
    "#top #wrap_all .invio-button.invio-color-light, #top #wrap_all .invio-button.invio-color-dark" => array('border_width' => 'border-width:%border_width%;'),
    "#top #wrap_all .invio-button.invio-color-light" => array('opacity' => 'color:#fff; border-color:#fff; background:transparent;'),
    "#top #wrap_all .invio-button.invio-color-dark" => array('opacity' => 'color:#000; border-color:#000; background:transparent;'),
    
    ),
    
    "sections"        => false,
    "hover"            => false,
    "edit"            => array(    
                                'border_radius' => array('type' => 'size', 'range' => '0-100', 'name'=> __("Border Radius",'invio_framework')),
                                'border_width'     => array('type' => 'size', 'range' => array(1,10), 'increment' => 1, 'unit' => 'px',  'name'=> __("Border width and",'invio_framework')),
                                'opacity'     => array('type' => 'select', 'name'=> __("opacity for transparent buttons",'invio_framework'), 
                                'options' => array(__('Semi-transparent','invio_framework') => '' , __('Full-transparent','invio_framework') => 'off' )),
                            )
);


$advanced['widget_title'] = array(
    "id"            => "widget_title", //needs to match array key
    "name"            => "Widget title",
    "group"         => __("Misc",'invio_framework'),
    "description"    => __("Change the styling of your widget title",'invio_framework'),
    "selector"        => array(
                        "#top [sections] .widgettitle" => array("style" => array( "border" , "border-style:solid; border-width:1px; padding:10px; text-align:center; margin-bottom:15px") ),
                        "html #top [sections] .widgettitle" => array("style" => array( "border-tp" , "border-style:solid; border-width:1px; padding:10px 0; border-left:none; border-right:none; margin-bottom:15px") ),
                        "body#top [sections] .widgettitle" => array( "border_color" => "border-color: %border_color%;", "background_color" => "background-color: %background_color%;", "color" => "color: %color%;", "text_align" => "text-align: %text_align%;"),
                        
                            ),
    "sections"        => true,
    "hover"            => false,
    "edit"            => array(    
                                'style'     => array(
                                                    'type' => 'select', 
                                                    'name'=> __("Overlay Style",'invio_framework'), 
                                                    'options' => array(
                                                        __('No Border','invio_framework') => '' , 
                                                        __('Border on top and bottom','invio_framework') =>'border-tp' , 
                                                        __('Border around the widget title','invio_framework') =>'border' , 
                                                    )
                                                ) ,
                                'border_color' => array('type' => 'colorpicker', 'name'=> __("Border Color",'invio_framework') ),
                                'background_color' => array('type' => 'colorpicker', 'name'=> __("Background Color",'invio_framework') ),
                                'color' => array('type' => 'colorpicker', 'name'=> __("Font Color",'invio_framework') ),
                                'text_align'     => array('type' => 'select', 'name'=> __("Text Align",'invio_framework'), 'options' => $align ),                            
                            )
);

$advanced['slideshow_titles'] = array(
    "id"            => "slideshow_titles", //needs to match array key
    "name"            => "Slideshow titles",
    "group"         => __("Misc",'invio_framework'),
    "description"    => __("Change the styling for your fullscreen, fullwidth and easy slider title",'invio_framework'),
    "selector"        => array("#top #wrap_all .slideshow_caption h2.invio-caption-title, #top #wrap_all .invio-slideshow-caption h2.invio-caption-title"=> ""),
    "sections"        => false,
    "hover"            => false,
    "edit"            => array(    
                                'font_family'         => array('type' => 'font', 'name'=> __("Font Family",'invio_framework'), 'options' => $google_fonts),
                                'font_weight'         => array('type' => 'select', 'name'=> __("Font Weight",'invio_framework'), 'options' => $weight),
                                'line_height'         => array('type' => 'size', 'range' => '0.7-2', 'increment' => 0.1, 'unit' => 'em',  'name'=> __("Line Height",'invio_framework')),
                                'letter_spacing'     => array('type' => 'size', 'range' => array(-10,20), 'increment' => 1, 'unit' => 'px',  'name'=> __("Letter Spacing",'invio_framework')),
                                'text_transform'     => array('type' => 'select', 'name'=> __("Text Transform",'invio_framework'), 'options' => $transform ),
                            )
);


$advanced['slideshow_caption'] = array(
    "id"            => "slideshow_caption", //needs to match array key
    "name"            => "Slideshow caption",
    "group"         => __("Misc",'invio_framework'),
    "description"    => __("Change the styling for your fullscreen, fullwidth and easy slider caption",'invio_framework'),
    "selector"        => array(

        "#top #wrap_all .invio-caption-content p" => array( 
                                                            "font_family"     => "font-family: %font_family% ,'Helvetica Neue', Helvetica, Arial, sans-serif;", 
                                                            "font_weight"     => "font-weight: %font_weight%;",
                                                            "line_height"     => "line-height: %line_height%;",
                                                            "letter_spacing" => "letter-spacing: %letter_spacing%;",
                                                            "text_transform" => "text-transform: %text_transform%;",
                                                             ),
        "#top .slideshow_caption" => array( "width" => "width: %width%;"),
    ),
    "sections"        => false,
    "hover"            => false,
    "edit"            => array(    
                                
                                'font_family'         => array('type' => 'font', 'name'=> __("Font Family",'invio_framework'), 'options' => $google_fonts),
                                'font_weight'         => array('type' => 'select', 'name'=> __("Font Weight",'invio_framework'), 'options' => $weight),
                                'line_height'         => array('type' => 'size', 'range' => '0.7-2', 'increment' => 0.1, 'unit' => 'em',  'name'=> __("Line Height",'invio_framework')),
                                'letter_spacing'     => array('type' => 'size', 'range' => array(-10,20), 'increment' => 1, 'unit' => 'px',  'name'=> __("Letter Spacing",'invio_framework')),
                                'text_transform'     => array('type' => 'select', 'name'=> __("Text Transform",'invio_framework'), 'options' => $transform ),
                                'width'             => array('type' => 'size', 'range' => array(40,100), 'increment' => 10, 'unit' => '%',  'name'=> __("Container Width",'invio_framework')),
                            )
);

$advanced['slideshow_button'] = array(
    "id"            => "slideshow_button", //needs to match array key
    "name"            => "Slideshow button",
    "group"         => __("Misc",'invio_framework'),
    "description"    => __("Change the styling for your fullscreen, fullwidth and easy slider buttons",'invio_framework'),
    "selector"        => array("#top #wrap_all .invio-slideshow-button"=> ""),
    "sections"        => false,
    "hover"            => false,
    "edit"            => array(    
                                'font_size'         => array('type' => 'size', 'range' => '10-80', 'name'=> __("Font Size",'invio_framework')),
                                'font_weight'         => array('type' => 'select', 'name'=> __("Font Weight",'invio_framework'), 'options' => $weight),
                                'line_height'         => array('type' => 'size', 'range' => '0.7-2', 'increment' => 0.1, 'unit' => 'em',  'name'=> __("Line Height",'invio_framework')),
                                'letter_spacing'     => array('type' => 'size', 'range' => array(-10,20), 'increment' => 1, 'unit' => 'px',  'name'=> __("Letter Spacing",'invio_framework')),
                                'text_transform'     => array('type' => 'select', 'name'=> __("Text Transform",'invio_framework'), 'options' => $transform ),
                            )
);


//body font size
//dropdown menu
//icon colors
//hover states
//links
// all sections/specific section