<?php
/**
 * INVIO Framework
 *
 * A flexible Wordpress Framework, created by Thomas Carter
 *
 * This file includes the superobject class and loads the parameters neccessary for the backend pages.
 * A new $invio superobject is then created that holds all data necessary for either front or backend, depending what page you are browsing
 *
 * @author        Thomas Carter
 * @copyright    Copyright (c) Thomas Carter
 * @link        http://thomascarter.net
 * @link        http://thomascarter.net/invio-framework
 * @since        Version 1.0
 * @package     InvioFramework
 * @version     1.0
*/ 
define( 'INVIO_FRAMEWORK_VERSION', "1.0" ); 



/**
 *  
 * Action for plugins and functions that should be executed before any of the framework loads
 * 
 */
do_action( 'invio_action_before_framework_init' );
 
 
 
/**
 *  Config File
 *  Load the autoconfig file that will set some 
 *  constants based on the installation type (plugin or theme)
 * 
 */
 
 require( 'php/inc-autoconfig.php' );



/**
 *  Superobject Class
 *  Load the super object class, but only if it hasn't been
 *  already loaded by an invio plugin with newer version
 * 
 */
 
if( ! defined('INVIO_PLUGIN_FW') || ! defined('INVIO_THEME_FW') || ( version_compare(INVIO_THEME_FW, INVIO_PLUGIN_FW, '>=') ) )
{ 
    require( INVIO_PHP.'class-superobject.php' );
}


/**
 *  Include Backend default Function set
 *  Loads the autoincluder function to be able to retrieve the 
 *  predefined page options and to be able to include
 *  files based on option arrays
 * 
 */
 
require( INVIO_PHP.'function-set-invio-backend.php' );


/*
 * ------------------------------------------------------
 *  Load the options array with manually passed functions
 *  in functions.php for theme or plugin specific scripts
 * ------------------------------------------------------
 */
 
 if(isset($invio_autoload) && is_array($invio_autoload)) invio_backend_load_scripts_by_option($invio_autoload);



/*
 * ------------------------------------------------------
 *  Filter the base data array that is passed
 *  upon creation of the superobject
 * ------------------------------------------------------
 */
 
$invio_base_data = apply_filters( 'invio_filter_base_data', $invio_base_data );



/**
 * ------------------------------------------------------
 *  create a new superobject, pass the options name that
 *  should be used to save and retrieve database entries
 * ------------------------------------------------------
 */
 
 $invio = new invio_superobject($invio_base_data);


// ------------------------------------------------------------------------

