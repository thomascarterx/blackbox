/**
 * This file holds the main javascript functions needed to edit dynamic option pages on the fly and also add elements to these dynamic option pages
 *
 * @author        Thomas Carter
 * @copyright    Copyright ( c ) Thomas Carter
 * @link        http://thomascarter.net
 * @link        http://thomascarter.net/invio-framework
 * @since        Version 1.1
 * @package     InvioFramework
 */



jQuery(function($) { $('.invio_sortable').invio_edit_dynamic_templates(); });



(function($) {
    invio_framework_globals.invio_ajax_action = false;

    $.fn.invio_edit_dynamic_templates = function(variables) {
        return this.each(function() {
            //gather form data
            var container = $(this);
            if (container.length != 1) return;

            container.sortable({

                handle: '.invio-row-portlet-header',
                cancel: 'a',
                items: '.invio_row',
                update: function(event, ui) {
                    $('.invio_button_inactive').removeClass('invio_button_inactive');
                }

            });

            //disable text selection in the header    
            $(".invio-row-portlet-header").disableSelection();

            $('.invio-item-edit', container).live('click', function() {
                var edit_link = $(this),
                    container = edit_link.parents('.invio_row:eq(0)'),
                    content = $('.invio-portlet-content', container);

                if (content.is(':visible')) {
                    content.slideUp(200);
                } else {
                    content.slideDown(200);
                }

                return false;

            });



        });
    }

})(jQuery);
