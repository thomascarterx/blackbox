/**
 * This file holds the main javascript functions needed for invio-media uploads
 *
 * @author        Thomas Carter
 * @copyright    Copyright ( c ) Thomas Carter
 * @link        http://thomascarter.net
 * @link        http://thomascarter.net/invio-framework
 * @since        Version 1.0
 * @package     InvioFramework
 */

(function($) {
    var invio_media = {

        invioUseCustomEditor: false,
        invioPostID: false,
        insertContainer: false,

        // bind the click event to all elements with the class invio_uploader 
        bind_click: function() {
            $('.invio_uploader').live('click', function() {
                var title = this.title,
                    idBased = "";
                this.title = "";



                invio_media.invioPostID = this.hash.substring(1);
                invio_media.invioUseCustomEditor = true;
                invio_media.insertContainer = $(this).parents('.invio_upload_container');

                //
                if (invio_media.insertContainer.is('.invio_advanced_upload')) {
                    idBased = "&amp;invio_idbased=" + $('.invio_upload_input', invio_media.insertContainer).attr('name');
                }

                var label = $(this).parents('.invio_upload_container').find('.invio_upload_insert_label').trigger('change').val();
                var gallery_mode = $(this).parents('.invio_upload_container').find('.invio_gallery_mode');
                var gallery_mode_val = "";

                if (gallery_mode.length) {
                    gallery_mode_val = '&amp;invio_gallery_mode=' + gallery_mode.trigger('change').val();
                }

                tb_show(title, 'media-upload.php?post_id=' + invio_media.invioPostID + idBased + gallery_mode_val + '&amp;invio_label=' + encodeURI(label) + "&amp;TB_iframe=true");


                return false;
            });
        },

        // bind the click event of the remove image links to the removing function
        bind_remove: function() {
            $('.invio_remove_image').live('click', function() {
                var container = $(this).parents('.invio_upload_container');

                container.find('.invio_upload_input').val('').trigger('change');
                container.find('.invio_preview_pic').hide(400, function() { $(this).html("").css({ display: "block" }); });

                return false;
            });
        },

        bind_blur: function() {
            $('.invio_upload_input').live('blur change', function() {
                var input = $(this),
                    value = input.val(),
                    image = '<img src ="' + value + '" alt="" />',
                    div = input.parents('.invio_upload_container:eq(0)').find('.invio_preview_pic');

                if (value != "") {
                    div.html('<a href="#" class="invio_remove_image">×</a>' + image);
                } else {
                    div.html("");
                }
            });
        },

        //changes the label of the "insert into post" button to better reflect the current action and hides the use as post-thumb button
        change_label: function() {
            invio_media.idBasedUpload();

            var newlabel = $('.invio_insert_button_label').val();

            if (newlabel != "" && typeof newlabel == 'string') {
                var savesendContainer = $(".savesend");

                if (savesendContainer.length > 0) {
                    $(".button", savesendContainer).val(newlabel);
                    $(".wp-post-thumbnail", savesendContainer).css('display', 'none');
                }
            }
        },

        //hijack the original uploader and replace it if a user clicks on one an invio_uploader
        hijack_uploader: function() {
            window.original_send_to_editor = window.send_to_editor;
            window.send_to_editor = function(html) {
                if (invio_media.invioUseCustomEditor) {
                    var container = invio_media.insertContainer,
                        returned = $(html),
                        img = returned.attr('src') || returned.find('img').attr('src') || returned.attr('href'),
                        visualInsert = '';

                    container.find('.invio_upload_input').val(img).trigger('change');

                    if (img.match(/.jpg$|.jpeg$|.png$|.gif$/)) {
                        visualInsert = '<a href="#" class="invio_remove_image">×</a><img src="' + img + '" alt="" />';
                    } else {
                        visualInsert = '<a href="#" class="invio_remove_image">×</a><img src="' + invio_framework_globals.frameworkUrl + 'images/icons/video.png" alt="" />';
                    }

                    container.find('.invio_preview_pic').html(visualInsert);

                    tb_remove();
                    invio_media.reset_uploader();
                } else {
                    window.original_send_to_editor(html);
                }
            };
        },

        //id based advanced upload
        idBasedUpload: function() {
            var idbased = $('.invio_idbased');

            if (idbased.length > 0) {
                idbased = idbased.val();

                var savesendContainer = $(".savesend"),
                    insertInto = $(".button", savesendContainer).not('.del-attachment .button'),
                    target = $("input[name=" + idbased + "]", parent.document),
                    imageTarget = target.parents('.invio_advanced_upload:eq(0)').find('.invio_preview_pic'),
                    filter = $("#filter"),
                    label = $(".invio_insert_button_label"),
                    gallery_mode = $(".invio_gallery_mode_active");


                var gallery_form = $("#gallery-form, #file-form");
                if (gallery_form.length) {
                    var ref_url = gallery_form.find("input[name=_wp_http_referer]").val(),
                        form_url = gallery_form.attr('action'),
                        new_url = "";

                    ref_url = ref_url.replace(/.+media-upload\.php?/, '');
                    form_url = form_url.replace(/media-upload\.php?.+/, '');
                    new_url = form_url + "media-upload.php" + ref_url;

                    gallery_form.attr('action', new_url);
                }

                if (gallery_mode.length) {
                    gallery_mode = true;

                    if ($('#invio_update_gallery').length) {
                        update_gal = $('#invio_update_gallery');
                    } else {
                        var save_all = $('#save-all, #save').not('.hidden'),
                            save_single = $('#save'),
                            update_gal = $('<input type="submit" name="invio_update_gallery" id="invio_update_gallery" class="button savebutton" value="...then close the window and update gallery preview" />');
                        update_gal.insertAfter(save_all);

                        //update_gal.insertAfter(save_single);
                    }

                    $('.savesend .button').not('.del-attachment .button').remove();
                    insertInto = $('.savesend .button, #insert-gallery, #invio_update_gallery').not('.del-attachment .button').attr('onmousedown', "");

                    $('#gallery-settings').css({ display: 'none' });


                } else {
                    gallery_mode = false;
                }

                //add the id based and the insert name field as a form input so it gets sent in case the user uses the search or filter functions
                if (filter.length) {
                    //duplication check
                    var filterInsert = filter.find("input[name=invio_idbased]"),
                        labelInsert = filter.find("input[name=invio_label]"),
                        galleryInsert = filter.find("input[name=invio_gallery_mode]");

                    if (!filterInsert.length) {
                        filter.prepend("<input type='hidden' name='invio_idbased' value='" + idbased + "'/>");
                    }

                    if (label.length && !labelInsert.length) {
                        filter.prepend("<input type='hidden' name='invio_label' value='" + label.val() + "'/>");
                    }

                    if (gallery_mode && !galleryInsert.length) {
                        filter.prepend("<input type='hidden' name='invio_gallery_mode' value='true'/>");
                    }

                }

                if (gallery_mode) {
                    insertInto.unbind('click').bind('click', function() {

                        var attachment_id = post_id,
                            newTarget = target.parents('.invio_control:eq(0)').find('.invio_thumbnail_container');

                        $.ajax({
                            type: "POST",
                            url: window.ajaxurl,
                            data: "action=invio_ajax_get_gallery&attachment_id=" + attachment_id,
                            success: function(msg) {
                                newTarget.html(msg);
                                parent.tb_remove();
                                invio_media.reset_uploader();
                            }
                        });

                        return false;
                    });
                } else {
                    insertInto.unbind('click').bind('click', function() {
                        var attachment_id = this.name.replace(/send\[/, "").replace(/\]/, "");

                        $.ajax({
                            type: "POST",
                            url: window.ajaxurl,
                            data: "action=invio_ajax_get_image&attachment_id=" + attachment_id,
                            success: function(msg) {
                                msg = $.trim(msg);
                                if (msg.match(/^<img/)) //image insert
                                {
                                    target.val(attachment_id);
                                    imageTarget.html('<a href="#" class="invio_remove_image">×</a>' + msg);
                                } else //video insert
                                {
                                    target.val(msg);
                                    visualInsert = '<a href="#" class="invio_remove_image">×</a><img src="' + invio_framework_globals.frameworkUrl + 'images/icons/video.png" alt="" />';
                                    imageTarget.html(visualInsert);
                                }

                                parent.tb_remove();
                                invio_media.reset_uploader();
                            }
                        });

                        return false;
                    });

                }


            }
        },



        //reset values for the next upload
        reset_uploader: function() {
            invio_media.invioUseCustomEditor = false;
            invio_media.invioPostID = false;
            invio_media.insertContainer = false;
        }


    };



    $(function() {
        $('#media-buttons a').click(invio_media.reset_uploader);
        invio_media.bind_click();
        invio_media.bind_blur();
        invio_media.bind_remove();
        invio_media.idBasedUpload();
        invio_media.hijack_uploader();
        invio_media.change_label();
        $(".slidetoggle").live('mouseenter', invio_media.change_label);
    });


})(jQuery);
