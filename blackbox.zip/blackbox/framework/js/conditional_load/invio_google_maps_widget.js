/**
 * This file holds the main javascript functions needed for the google maps widget (get coordinates from address, etc.)
 *
 * @author      Thomas Carter
 * @copyright   Copyright ( c ) Thomas Carter
 * @link        http://thomascarter.net
 * @link        http://thomascarter.net/invio-framework
 * @since       Version 1.1
 * @package     InvioFramework
 */
(function($) {
    "use strict";

    /*
     * global var which contains the current widget container. Required for callback function
     */
    var invio_google_maps_widget_container = '';

    $(document).ready(function() {
        $('body').invio_google_maps_options();

        $(document).ajaxSuccess(function(e, xhr, settings) {

            var widget_id_base = 'invio_google_maps';

            if (typeof(settings.data) !== 'undefined' && settings.data.search('action=save-widget') != -1 && settings.data.search('id_base=' + widget_id_base) != -1) {
                $('body').invio_google_maps_options();
            }
        });
    });

    $.fn.invio_google_maps_options = function() {
        $('.invio-find-coordinates-wrapper,.invio-loading-coordinates').hide();

        $(".invio-coordinates-help-link").on('click', function() {
            event.preventDefault();

            invio_google_maps_widget_container = jQuery(this).parents('.widget-content');
            invio_google_maps_widget_container.find(".invio-coordinates-help-link").hide();
            invio_google_maps_widget_container.find(".invio-coordinates-wrapper").hide();
            invio_google_maps_widget_container.find(".invio-find-coordinates-wrapper").show();
        });

        $(".invio-populate-coordinates").click(function() {
            event.preventDefault();

            invio_google_maps_widget_container = jQuery(this).parents('.widget-content');
            var streetAddress = invio_google_maps_widget_container.find(".invio-map-street-address").val(),
                city = invio_google_maps_widget_container.find(".invio-map-city").val(),
                state = invio_google_maps_widget_container.find(".invio-map-state").val(),
                postcode = invio_google_maps_widget_container.find(".invio-map-postcode").val(),
                country = invio_google_maps_widget_container.find(".invio-map-country").val();

            invio_google_maps_widget_container.find(".invio-loading-coordinates").show();

            var addressGeo = streetAddress + " " + city + " " + state + " " + postcode + " " + country;
            invio_fetch_coordinates(addressGeo);
        });

        function invio_fetch_coordinates(addressGeo) {
            var geocoder = new google.maps.Geocoder();

            geocoder.geocode({ 'address': addressGeo }, function(results, status) {
                var errormessage = '';

                if (status == google.maps.GeocoderStatus.OK) {
                    /*console.log(results);
                     console.log(results[0].geometry.location.lat() );
                     console.log(results[0].geometry.location.lng() );*/
                    var latitude = results[0].geometry.location.lat();
                    var longitude = results[0].geometry.location.lng();

                    invio_print_coordinates(latitude, longitude);
                } else if (status == google.maps.GeocoderStatus.ZERO_RESULTS) {
                    if (!addressGeo.replace(/\s/g, '').length) {
                        errormessage = InvioMapTranslation.insertaddress;
                    } else {
                        errormessage = InvioMapTranslation.latitude + ' ' + addressGeo + ' ' + InvioMapTranslation.notfound;
                    }
                } else if (status == google.maps.GeocoderStatus.OVER_QUERY_LIMIT) {
                    errormessage = InvioMapTranslation.toomanyrequests;
                }

                if (errormessage != '') alert(errormessage);

                invio_google_maps_widget_container.find(".invio-coordinates-help-link").show();
                invio_google_maps_widget_container.find(".invio-find-coordinates-wrapper").fadeOut("fast");
                invio_google_maps_widget_container.find(".invio-loading-coordinates").hide();
                invio_google_maps_widget_container.find(".invio-coordinates-wrapper").show();
            });
        }

        function invio_print_coordinates(latitude, longitude) {
            invio_google_maps_widget_container.find(".invio-map-lat").val(latitude);
            invio_google_maps_widget_container.find(".invio-map-lng").val(longitude);
        }
    }
})(jQuery);
