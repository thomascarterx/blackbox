/**
 * This file holds the main javascript functions which is required for the conditional mega menu
 *
 * @author      Thomas Carter
 * @copyright   Copyright ( c ) Thomas Carter
 * @link        http://thomascarter.net
 * @link        http://thomascarter.net/invio-framework
 * @since       Version 1.1
 * @package     InvioFramework
 */
(function($) {
    "use strict";
    var invio_conditional_logic = {

        recalcTimeout: false,

        // bind the click event to all elements with the class invio_uploader
        input_event: function() {
            $(document).on('click', '.menu-item-invio-enableconditionallogic', function() {
                var checkbox = $(this),
                    container = checkbox.parents('.menu-item:eq(0)');

                if (checkbox.is(':checked')) {
                    container.addClass('invio_conditional_active');
                    container.find('.invio_conditional_logic_field').show();
                } else {
                    container.removeClass('invio_conditional_active');
                    container.find('.invio_conditional_logic_field').hide();
                }

                //check if anything in the dom needs to be changed to reflect the (de)activation of the mega menu
                invio_conditional_logic.recalc();
            });

            $(document).on('change', '.menu-item-invio-conditional', function() {
                var select = $(this),
                    selected = select.find(':selected'),
                    container = select.parents('.menu-item:eq(0)');

                if (selected.hasClass('show_css_field')) {
                    container.find('.menu-item-invio-conditionalcss').show();
                } else {
                    container.find('.menu-item-invio-conditionalcss').hide();
                }

                invio_conditional_logic.recalc();
            });

            $(document).on('change', '.menu-item-invio-conditionalvalue', function() {
                var select = $(this),
                    selected = select.find(':selected'),
                    container = select.parents('.menu-item:eq(0)');

                if (selected.hasClass('show_id_field')) {
                    container.find('.menu-item-invio-conditionalid').show();
                } else {
                    container.find('.menu-item-invio-conditionalid').hide();
                }

                invio_conditional_logic.recalc();
            });

            $(document).on('mouseenter', '.menu-item-bar', function() {
                invio_conditional_logic.recalc();
            });
        },

        recalcInit: function() {
            $(document).on("mouseup", ".menu-item-bar", function(event, ui) {
                if (!$(event.target).is('a')) {
                    clearTimeout(invio_conditional_logic.recalcTimeout);
                    invio_conditional_logic.recalcTimeout = setTimeout(invio_conditional_logic.recalc, 500);
                }
            });
        },


        recalc: function() {
            $('.menu-item').each(function(i) {
                var item = $(this),
                    conditionallogic = item.find('.menu-item-invio-enableconditionallogic');

                if (conditionallogic.is(':checked')) {
                    item.addClass('invio_conditional_active');
                    item.find('.invio_conditional_logic_field').show();
                } else {
                    item.removeClass('invio_conditional_active');
                    item.find('.invio_conditional_logic_field').hide();
                }

                var conditionaltype = item.find('.menu-item-invio-conditional', '.menu-item-invio-conditionalvalue');
                if (conditionaltype.find('option:selected').hasClass('show_css_field')) {
                    item.find('.menu-item-invio-conditionalcss').show();
                } else {
                    item.find('.menu-item-invio-conditionalcss').hide();
                }

                var conditionalvalue = item.find('.menu-item-invio-conditionalvalue');
                if (conditionalvalue.find('option:selected').hasClass('show_id_field')) {
                    item.find('.menu-item-invio-conditionalid').show();
                } else {
                    item.find('.menu-item-invio-conditionalid').hide();
                }


            });

        }

    };


    $(function() {
        invio_conditional_logic.input_event();
        invio_conditional_logic.recalcInit();
        invio_conditional_logic.recalc();
    });


})(jQuery);
