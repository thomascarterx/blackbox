scnShortcodeMeta = {
    attributes: [{
        label: "Table Generator",
        id: "content",
        controlType: "table-control"
    }],
    disablePreview: true,
    customMakeShortcode: function(dataset) {
        var data = dataset.data,
            table = data.table,
            html = data.html;

        var shortcode = '[invio_table]' + html + '[/invio_table]';


        return shortcode;


    }
};
