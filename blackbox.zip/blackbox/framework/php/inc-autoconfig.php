<?php
/**
 * This file first checks if the framework is used as a theme or plugin framework and sets values accordingly
 *
 * @author        Thomas Carter
 * @copyright    Copyright (c) Thomas Carter
 * @link        http://thomascarter.net
 * @link        http://thomascarter.net/invio-framework
 * @since        Version 1.0
 * @package     InvioFramework
 */

/**
 * check if file is a plugin or theme based on its location, then set constant and globals for further use within the framework
 * @todo create plugin version of framework and prevent interfering with theme version
 */
 


/**
* INVIO_BASE contains the root server path of the framework that is loaded
*/
if( ! defined('INVIO_BASE' ) )      {     define( 'INVIO_BASE', get_template_directory() .'/' ); }



/**
* INVIO_BASE_URL contains the http url of the framework that is loaded
*/
if( ! defined('INVIO_BASE_URL' ) ){    define( 'INVIO_BASE_URL', get_template_directory_uri() . '/'); }



// get themedata version wp 3.4+
if(function_exists('wp_get_theme'))
{
    $wp_theme_obj = wp_get_theme();
    $invio_base_data['prefix'] = $invio_base_data['Title'] = $wp_theme_obj->get('Name');
}

// get themedata lower versions
if(!isset($invio_base_data['Title']))
{
    $invio_base_data = get_theme_data( INVIO_BASE . 'style.css' );
    $invio_base_data['prefix'] = $invio_base_data['Title'];
}

/*if we use a beta build remove the beta string so the theme saves all options for the actual release- beta builds use an _invio_beta string at the end of the theme name*/
$invio_base_data['prefix'] = str_replace('_invio_beta','',$invio_base_data['prefix']);


/**
* THEMENAME contains the Name of the currently loaded theme
*/
if( ! defined('THEMENAME' ) ) { define( 'THEMENAME', $invio_base_data['Title'] ); }



if( ! defined('INVIO_FW' ) )
{    
    //define path constants
    
    /**
    * INVIO_FW contains the server path of the framework folder
    */
    define( 'INVIO_FW', INVIO_BASE . 'framework/' ); 
    
    
    /**
    * INVIO_PHP contains the server path of the frameworks php folder
    */
    define( 'INVIO_PHP', INVIO_FW . 'php/' );
    
    
    /**
    * INVIO_JS contains the server path of the frameworks javascript folder
    */
    define( 'INVIO_JS', INVIO_FW . 'js/' );
    
    
    /**
    * INVIO_CSS contains the server path of the frameworks css folder
    */ 
    define( 'INVIO_CSS', INVIO_FW . 'css/' );
    
    
    /**
    * INVIO_OPTIONS contains the server path of the theme_option_pages folder
    */ 
    define( 'INVIO_OPTIONS', INVIO_BASE . 'theme_option_pages' ); 
    
    
    
    
    //define url constants
    
    /**
    * INVIO_FW_URL contains the url of the framework folder
    */ 
    define( 'INVIO_FW_URL', INVIO_BASE_URL . 'framework/' );
    
    /**
    * INVIO_IMG_URL contains the url of the frameworks images folder
    */ 
    define( 'INVIO_IMG_URL', INVIO_FW_URL . 'images/' ); 
    
    
    /**
    * INVIO_PHP_URL contains the url of the frameworks php folder
    */ 
    define( 'INVIO_PHP_URL', INVIO_FW_URL . 'php/' );
    
    
    /**
    * INVIO_JS_URL contains the url of the frameworks javascript folder
    */ 
    define( 'INVIO_JS_URL', INVIO_FW_URL . 'js/' ); 
    
    
    /**
    * INVIO_CSS_URL contains the url of the frameworks css folder
    */ 
    define( 'INVIO_CSS_URL', INVIO_FW_URL . 'css/' ); 
    
    
    /**
    * INVIO_OPTIONS contains the url of the theme_option_pages folder
    */ 
    define( 'INVIO_OPTIONS_URL', INVIO_BASE_URL . 'theme_option_pages' ); 
}



//file includes

/**
* This file holds a function set for commonly used operations done by the frameworks frontend
*/
require( INVIO_PHP.'function-set-invio-frontend.php' );

/**
* This file holds the class that improves the menu with megamenu capabilities
*/
require( INVIO_PHP.'class-megamenu.php' );

/**
* This file holds the function that creates the shortcodes within the backend
*/
require( INVIO_PHP.'invio_shortcodes/shortcodes.php' );

/**
* This file holds the class that creates various styles for the frontend that are set within the backend
*/
require( INVIO_PHP.'class-style-generator.php' );

/**
* This file holds the class that creates forms based on option arrays
*/
require( INVIO_PHP.'class-form-generator.php' );

/**
* This file holds the class that creates several framework specific widgets
*/
require( INVIO_PHP.'class-framework-widgets.php' );

/**
* This file holds the class that creates several framework specific widgets
*/
require( INVIO_PHP.'class-breadcrumb.php' );


/**
* Query filter for post types and other stuff
*/
require( INVIO_PHP.'class-queryfilter.php' );

    
/**
* This file loads the classs necessary for dynamic sidebars
*/
require( INVIO_PHP.'class-sidebar-generator.php' );
    
    
if(is_admin())
{

    // Load script that are needed for the backend

    /**
    * This file holds a function set for ajax operations done by the framework
    */
    require( INVIO_PHP.'function-set-invio-ajax.php' );
    
    /**
    * The adminpage class creates the option page menu items
    */
    require( INVIO_PHP.'class-adminpages.php' );
    
    /**
    * The metabox class creates meta boxes for single posts, pages and other custom post types
    */
    require( INVIO_PHP.'class-metabox.php' );
    
    /**
    * The htmlhelper class is needed to render the options defined in the config files
    */
    require( INVIO_PHP.'class-htmlhelper.php' );
        
    /**
    * This file improves the media uploader so it can be used within the framework
    */
    require( INVIO_PHP.'class-media.php' );
    
    /**
    * This file loads the option set class to create new backend options on the fly
    */
    require( INVIO_PHP.'class-database-option-sets.php' );
    
    /**
    * This file loads the option set class to create new backend options on the fly
    */
    require( INVIO_PHP.'wordpress-importer/invio-export-class.php' );
    
    /**
    * This file loads the class responsible for one click theme updates
    */
    require( INVIO_PHP.'auto-updates/auto-updates.php' );
    
    
    
    /**
    * This file loads the option set class to create new backend options on the fly
    */
    require( INVIO_PHP.'class-update-notifier.php' );
}

if( ! defined('THEMENAMECLEAN' ) ) { define( 'THEMENAMECLEAN', invio_clean_string($invio_base_data['Title']) ); }













